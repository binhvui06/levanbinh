error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$nau= "\e[38;5;94m";
$xnhac = "\033[1;96m";
$den = "\033[1;90m";
$do = "\033[1;91m";
$luc = "\033[1;92m";
$vang = "\033[1;93m";
$xduong = "\033[1;94m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
$thanh_xau= $trang."~".$do."[".$luc."●".$do."] ".$trang."➩ ";
$thanh_dep= $trang."~".$do."[".$luc."✓".$do."] ".$trang."➩ ";
date_default_timezone_set('Asia/Ho_Chi_Minh');
@system('clear');
$useragent ="Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36";
echo chay(10);
echo $luc."Nhập Access_token : $BWhite";
$token = trim(fgets(STDIN));
echo $luc."Nhập Cookie Facebook : $BWhite";
$cookie = trim(fgets(STDIN));
$url = "https://traodoisub.com/api/?fields=profile&access_token=".$token;
$info = get($url);
$user = $info->{'data'}->{'user'};
$xu = $info->{'data'}->{'xu'};
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO TDS COOKIE \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Facebook : $BPurple 100047478314721 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Tài Khoản TDS Của Bạn Là: ".$BWhite.$user."\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Số Xu Hiện Tại Của Bạn Là: ".$BWhite.$xu."\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen LIKE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen FOLLOW\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m3\033[1;31m]$BGreen CẢM XÚC\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m4\033[1;31m]$BGreen COMMENTS\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m5\033[1;31m]$BGreen PAGE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m6\033[1;31m]$BGreen SHARE\n";
echo $BGreen." Ví dụ bạn muốn làm like follow thì điền 1+2 ";sleep(3); echo "\r"."                                                           "."\r";
echo chay(10);
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime  Vui Lòng Nhập chế độ : $BWhite";
$chon_1 =trim(fgets(STDIN));
$chon = "số $chon_1";
echo $thanh_dep.$luc."Nhập Delay : $vang";
$delay = trim(fgets(STDIN));
echo $thanh_dep.$luc."Sau ____ Nhiệm Vụ Thì Kích Hoạt Chống Block.     \r";
echo $thanh_dep.$luc."Sau $vang";
$dungblock = trim(fgets(STDIN));
echo $thanh_dep.$luc."Sau ".$vang.$dungblock.$luc." Nhiệm Vụ Nghỉ Ngơi ____ Giây       \r";
echo $thanh_dep.$luc."Sau ".$vang.$dungblock.$luc." Nhiệm Vụ Nghỉ Ngơi $vang";
$delaybl = trim(fgets(STDIN));
echo chay(10);
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $access = curl_exec($ch);
    curl_close($ch);
    if (explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access)[1])[0]) {
        $access_token = explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access)[1])[0];
        $idfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'id'};
        $tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))->{'name'};
 } else { echo $do." Cookie Die \n"; die; }
//cấu hình
$urlcauhinh = "https://traodoisub.com/api/?fields=run&id=$idfb&access_token=$token";
$cauhinh = get($urlcauhinh);
if ($cauhinh->{'data'}->{'msg'} == "Cấu hình thành công!") {
echo $yellow."Cấu Hình $luc$idfb \n";
echo chay(10);
} else { echo $do." Cấu Hình Thất Bại, Vui Lòng Thêm Nick $tenfb Vào Cấu Hình \r"; 
}
while (true){
// like
if(strpos($chon, '1') != false){
// get job
$url = "https://traodoisub.com/api/?fields=like&access_token=".$token;
$get = getnv($url);
$uid = $get[0];
	$id = $uid->{"id"};
// làm nv fb
$g = like($access_token, $id, $cookie);
// xu
$url = "https://traodoisub.com/api/?fields=profile&access_token=".$token;
$info = get($url);
$xu = $info->{'data'}->{'xu'};
// nhận tiền
$url = "https://traodoisub.com/api/coin/?type=LIKE&id=".$id."&access_token=".$token;
$get = nhan($url);
//print_r($get);
$tc = $get->{'success'};
if($tc == '200'){
	$so++;
	echo $BCyan."[$so]$BRed ★$BGreen ".date("H:i")."$BRed ★$BGreen [LIKE] $BRed ★$BGreen [ĐÃ ẨN ID]$BRed ★$BGreen + 300 $BRed ★$BYellow $xu \n";
if ( $so % $dungblock == 0 ){ delaybl($delaybl); }
			else { delay($delay); }
} //job đúng
} //nv 1
// follow
if(strpos($chon, '2') != false){
// get job
$url = "https://traodoisub.com/api/?fields=follow&access_token=".$token;
$get = getnv($url);
	$uid = $get[0];
	$idfl = $uid->{"id"};
// fb
$g = follow($access_token, $idfl, $cookie);
// xu
$url = "https://traodoisub.com/api/?fields=profile&access_token=".$token;
$info = get($url);
$xu = $info->{'data'}->{'xu'};
// nhận tiền
$url = "https://traodoisub.com/api/coin/?type=FOLLOW&id=".$idfl."&access_token=".$token;
$get = nhan($url);
$tc = $get->{'success'};
if($tc == '200'){
	$so++;
	echo $BCyan."[$so]$BRed ★$BGreen ".date("H:i")."$BRed ★$BGreen [FOLLOW] $BRed ★$BGreen [ĐÃ ẨN ID]$BRed ★$BGreen + 600 $BRed ★$BYellow $xu \n";
if ( $so % $dungblock == 0 ){ delaybl($delaybl); }
			else { delay($delay); }
} //job đúng
}
// cảm xúc
if(strpos($chon, '3') != false){
// get job
$url = "https://traodoisub.com/api/?fields=reaction&access_token=".$token;
$get = getnv($url);
$uid = $get[0];
	$idcx = $uid->{"id"};
        $type = $uid->{"type"};
// fb
$g = camxuc($idcx, $type, $cookie);
// xu
$url = "https://traodoisub.com/api/?fields=profile&access_token=".$token;
$info = get($url);
$xu = $info->{'data'}->{'xu'};
// nhận tiền
$url = "https://traodoisub.com/api/coin/?type=".$type."&id=".$idcx."&access_token=".$token;
$get = nhan($url);
$tc = $get->{'success'};
if($tc == '200'){
	$so++;
	echo $BCyan."[$so]$BRed ★$BGreen ".date("H:i")."$BRed ★$BGreen [$type] $BRed ★$BGreen [ĐÃ ẨN ID]$BRed ★$BGreen + 400 $BRed ★$BYellow $xu \n";
if ( $so % $dungblock == 0 ){ delaybl($delaybl); }
			else { delay($delay); }
} //job đúng
}
// cmt
if(strpos($chon, '4') != false){
// get job
$url = "https://traodoisub.com/api/?fields=comment&access_token=".$token;
$get = getnv($url);
$uid = $get[0];
	$idcmt = $uid->{"id"};
        $msg = $uid->{"msg"};
// fb
$g = cmt($access_token, $idcmt, $cookie, $msg);
// xu
$url = "https://traodoisub.com/api/?fields=profile&access_token=".$token;
$info = get($url);
$xu = $info->{'data'}->{'xu'};
// nhận tiền
$url = "https://traodoisub.com/api/coin/?type=COMMENT&id=".$idcmt."&access_token=".$token;
$get = nhan($url);
$tc = $get->{'success'};
if($tc == '200'){
	$so++;
	echo $BCyan."[$so]$BRed ★$BGreen ".date("H:i")."$BRed ★$BGreen [CMT] $BRed ★$BGreen [ĐÃ ẨN ID]$BRed ★$BGreen + 600 $BRed ★$BYellow $xu \n";
if ( $so % $dungblock == 0 ){ delaybl($delaybl); }
			else { delay($delay); }
} //job đúng
}
// page
if(strpos($chon, '5') != false){
// get job
$url = "https://traodoisub.com/api/?fields=page&access_token=".$token;
$get = getnv($url);
$uid = $get[0];
	$idpage = $uid->{"id"};
// fb
$g = page($idpage, $cookie);
// xu
$url = "https://traodoisub.com/api/?fields=profile&access_token=".$token;
$info = get($url);
$xu = $info->{'data'}->{'xu'};
// nhận tiền
$url = "https://traodoisub.com/api/coin/?type=PAGE&id=".$idpage."&access_token=".$token;
$get = nhan($url);
$tc = $get->{'success'};
if($tc == '200'){
	$so++;
	echo $BCyan."[$so]$BRed ★$BGreen ".date("H:i")."$BRed ★$BGreen [PAGE] $BRed ★$BGreen [ĐÃ ẨN ID]$BRed ★$BGreen + 600 $BRed ★$BYellow $xu \n";
if ( $so % $dungblock == 0 ){ delaybl($delaybl); }
			else { delay($delay); }
} //job đúng
}
// share
if(strpos($chon, '6') != false){
// get job
$url = "https://traodoisub.com/api/?fields=share&access_token=".$token;
$get = getnv($url);
$uid = $get[0];
	$idshare = $uid->{"id"};
// fb
$g = share($access_token,$idshare);
// xu
$url = "https://traodoisub.com/api/?fields=profile&access_token=".$token;
$info = get($url);
$xu = $info->{'data'}->{'xu'};
// nhận tiền
$url = "https://traodoisub.com/api/coin/?type=SHARE&id=".$idshare."&access_token=".$token;
$get = nhan($url);
$tc = $get->{'success'};
if($tc == '200'){
	$so++;
	echo $BCyan."[$so]$BRed ★$BGreen ".date("H:i")."$BRed ★$BGreen [SHARE] $BRed ★$BGreen [ĐÃ ẨN ID]$BRed ★$BGreen + 600 $BRed ★$BYellow $xu \n";
if ( $so % $dungblock == 0 ){ delaybl($delaybl); }
			else { delay($delay); }
} //job đúng
}
// cx cmt
if(strpos($chon, '7') != false){
// get job
$url = "https://traodoisub.com/api/?fields=reactcmt&access_token=".$token;
$get = getnv($url);
$uid = $get[0];
	$idlikecmt = $uid->{"id"};
	$type = $uid->{"type"};

// fb
 if ($type == 'LIKE'){
                    like($access_token, $idcx, $cookie);
                }else{
                    camxuc($idcx, $type, $cookie);
                }
// nhận tiền
$url = "https://traodoisub.com/api/coin/?type=".$type."&id=".$idlikecmt."&access_token=".$token;
$get = nhan($url);
$tc = $get->{'success'};
//xu
$xu = $get->{'data'}->{'xu'};
if($tc == '200'){
	$so++;
	echo $BCyan."[$so]$BRed ★$BGreen ".date("H:i")."$BRed ★$BGreen [CẢM XÚC CMT] $BRed ★$BGreen [ĐÃ ẨN ID]$BRed ★$BGreen + 600 $BRed ★$BYellow $xu \n";
if ( $so % $dungblock == 0 ){ delaybl($delaybl); }
			else { delay($delay); }
} //job đúng
}
} //while nhỏ
function get($url){
	 $head = [
        "Host: traodoisub.com",
        "cache-control: max-age=0",
        "upgrade-insecure-requests: 1",
        "user-agent: Mozilla/5.0 (Linux; Android 9; Mi A1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.110 Mobile Safari/537.36",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site: none",
        "sec-fetch-mode: navigate",
        "sec-fetch-user: ?1",
        "sec-fetch-dest: document",
        "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
    ];
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_SSL_VERIFYPEER => FALSE,
        CURLOPT_RETURNTRANSFER => 1
    ));
        $get = curl_exec($ch);
    curl_close($ch);
    $info =json_decode($get);
	return $info;
	}
function like($access_token, $id, $cookie) {
        $ch=curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/likes');
        $head[] = "Connection: keep-alive";
        $head[] = "Keep-Alive: 300";
        $head[] = "authority: m.facebook.com";
        $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
        $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
        $head[] = "cache-control: max-age=0";
        $head[] = "upgrade-insecure-requests: 1";
        $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
        $head[] = "sec-fetch-site: none";
        $head[] = "sec-fetch-mode: navigate";
        $head[] = "sec-fetch-user: ?1";
        $head[] = "sec-fetch-dest: document";
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
        $data = array('access_token' => $access_token);
        curl_setopt($ch, CURLOPT_POST,count($data));
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        $access = curl_exec($ch);
        curl_close($ch);
        return json_decode($access);
}
function follow($access_token, $idfl, $cookie) {
        $ch=curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$idfl.'/subscribers');
        $head[] = "Connection: keep-alive";
        $head[] = "Keep-Alive: 300";
        $head[] = "authority: m.facebook.com";
        $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
        $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
        $head[] = "cache-control: max-age=0";
        $head[] = "upgrade-insecure-requests: 1";
        $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
        $head[] = "sec-fetch-site: none";
        $head[] = "sec-fetch-mode: navigate";
        $head[] = "sec-fetch-user: ?1";
        $head[] = "sec-fetch-dest: document";
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
        $data = array('access_token' => $access_token);
        curl_setopt($ch, CURLOPT_POST,count($data));
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        $access = curl_exec($ch);
        curl_close($ch);
        return json_decode($access);
}
function cmt($access_token, $idcmt, $cookie, $msg) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$idcmt.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('message' => $msg, 'access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function page($idpage, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$idpage);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
    :'));
    $page = curl_exec($ch);
    if (explode('&amp;refid=', explode('pageSuggestionsOnLiking=1&amp;gfid=', $page)[1])[0]) {
        $get = explode('&amp;refid=', explode('pageSuggestionsOnLiking=1&amp;gfid=', $page)[1])[0];
        $link = 'https://mbasic.facebook.com/a/profile.php?fan&id='.$idpage.'&origin=page_profile&pageSuggestionsOnLiking=1&gfid='.$get.'&refid=17';
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
    }
    curl_close($ch);

}
function camxuc($idcx, $type, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/reactions/picker/?is_permalink=1&ft_id='.$idcx);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
    :'));
    $cx = curl_exec($ch);
    $haha = explode('<a href="', $cx);
    if ($type == 'LOVE') {
        $haha2 = explode('" style="display:block"', $haha[2])[0];
    } else if ($type == 'WOW') {
        $haha2 = explode('" style="display:block"', $haha[5])[0];
    } else if ($type == 'HAHA') {
        $haha2 = explode('" style="display:block"', $haha[4])[0];
    } else if ($type == 'SAD') {
        $haha2 = explode('" style="display:block"', $haha[6])[0];
    } else {
        $haha2 = explode('" style="display:block"', $haha[7])[0];
    }
    $link2 = html_entity_decode($haha2);
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com'.$link2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);
    curl_close($ch);
}
function share($access_token,$idshare) {
 $ch=curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/v2.0/me/feed');
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
$data = array(
'privacy' => '{"value":"EVERYONE"}',
'message' => '',
'link' => 'https://mbasic.facebook.com/'.$idshare.'',
'access_token' => $access_token
);
curl_setopt($ch, CURLOPT_POST,count($data));
curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
$a = json_decode(curl_exec($ch), true);                                    
curl_close($ch);
   return $a;
}
function cxcmt($id,$head_fb, $type){
//cx comment
if($type=="LIKE"){$i=1;
}elseif($type=="LOVE"){$i=2;
}elseif($type=="CARE"){$i=3;
}elseif($type=="HAHA"){$i=4;
}elseif($type=="WOW"){$i=5;
}elseif($type=="SAD"){$i=6;
}elseif($type=="ANGRY"){$i=7;
}
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://mbasic.facebook.com/'.$id);
curl_setopt($mr, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($mr, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($mr, CURLOPT_HTTPHEADER, $head_fb);
$mr1 = curl_exec($mr);
$cxcmt = explode('"',explode('/reactions/picker/?ft_id='.$id,$mr1)[1])[0];
curl_setopt($mr, CURLOPT_URL, 'https://mbasic.facebook.com/reactions/picker/?ft_id='.$id.htmlspecialchars_decode($cxcmt));
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
$mr2 = curl_exec($mr);
$cxcmt2 = explode('"',explode('/ufi/reaction/?',$mr2)[$i])[0];
curl_setopt($mr, CURLOPT_URL, 'https://mbasic.facebook.com/ufi/reaction/?'.htmlspecialchars_decode($cxcmt2));
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
$mr2 = curl_exec($mr); curl_close($mr);
}
function getnv($url){
	 $head = array(
        "Host: traodoisub.com",
        "cache-control: max-age=0",
        "upgrade-insecure-requests: 1",
        "user-agent: Mozilla/5.0 (Linux; Android 9; Mi A1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.110 Mobile Safari/537.36",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site: none",
        "sec-fetch-mode: navigate",
        "sec-fetch-user: ?1",
        "sec-fetch-dest: document",
        "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
    );
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_SSL_VERIFYPEER => FALSE,
        CURLOPT_RETURNTRANSFER => 1
    ));
        $get = curl_exec($ch);
    curl_close($ch);
    $info =json_decode($get);
	return $info;
	}
function nhan($url){
	 $head = array(
        "Host: traodoisub.com",
        "cache-control: max-age=0",
        "upgrade-insecure-requests: 1",
        "user-agent: Mozilla/5.0 (Linux; Android 9; Mi A1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.110 Mobile Safari/537.36",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site: none",
        "sec-fetch-mode: navigate",
        "sec-fetch-user: ?1",
        "sec-fetch-dest: document",
        "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
    );
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_SSL_VERIFYPEER => FALSE,
        CURLOPT_RETURNTRANSFER => 1
    ));
        $get = curl_exec($ch);
    curl_close($ch);
    $info =json_decode($get);
	return $info;
	}
function delay ($delay){
for($tt = $delay ;$tt> -1;$tt--){
        echo "\r\033[1;93m   LVB \033[1;91m ~>       \033[1;92m LO      \033[1;91m | $tt | ";
        usleep(150000);
        echo "\r\033[1;91m   LVB \033[0;33m   ~>     \033[0;37m LOA     \033[0;31m | $tt | ";
        usleep(150000);
        echo "\r\033[1;92m   LVB \033[0;33m     ~>   \033[0;37m LOAD    \033[0;31m | $tt | ";
        usleep(150000);
        echo "\r\033[1;94m   LVB \033[0;33m       ~> \033[0;37m LOADI   \033[0;31m | $tt | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADIN  \033[0;31m | $tt | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADING \033[0;31m | $tt | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADING.\033[0;31m | $tt | ";
        usleep(150000);}
        
        echo "\r\e[1;95m    ⚡LÊ VĂN BÌNH⚡                       \r";
        }
//=====================[ Delay Vòng ]========================
function delaybl($delaybl) {
    for ($time = $delaybl; $time > -0; $time--) {echo "\r"; 
echo "\r\033[1;97m Đang hoạt động chống block sẽ chạy lại sau $time giây"; sleep(1);
echo "\r                                                       \r"; 
}}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}