error_reporting(0);
session_start();
date_default_timezone_set("Asia/Ho_Chi_Minh");
$xnhac = "\033[1;36m";
$den = "\033[1;30m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
$whiteb="\033[1;37m";
$red="\033[0;31m";
$redb="\033[1;31m";
$_SESSION['useragent'] = 'Mozilla/5.0 (Linux; Android 10; CPH1819) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36';
$thanh_xau= $trang."≈ ".$do."[".$luc."🍬".$do."] ".$trang."➩ ";
$thanh_dep= $trang."≈ ".$do."[".$luc."✓".$do."] ".$trang."➩ ";
 @system('clear');
echo $redb."   ▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);
echo"\033[0;45m\e[1;32m✦ NHẬP DỮ LIỆU ✦\e[0m";
echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo"\e[0m\n\n";
usleep(30000);
$khock=[];
unset($a);
while (true){$a++;
echo $do."[".$luc."✓".$do."] ".$trang."=> ".$luc."Nhập Cookie Thứ $a: $vang";
$nhapck = trim(fgets(STDIN));
if($nhapck == ''){break;}
$access_token = laytoken($nhapck);
if ( $access_token == "2") { echo $do." Cookie Die !!!   \n"; $a--; continue; 
} else { echo $luc." Tài Khoản Đúng \n"; 
	array_push($khock,$nhapck); 
}
}
chay(35);
echo $thanh_dep.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Comment Thường (không ảnh)\n";
echo $thanh_dep.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Comment Ảnh Thường (link)\n";
echo $thanh_dep.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Comment Ảnh Gif (link)\n";
echo $thanh_dep.$luc."Nhập Lựa Chọn: $vang";
$loaicmt = (string)trim(fgets(STDIN));
chay(35);
if($loaicmt == '1'){
$khoCMT=[];
echo $thanh_dep.$luc."Bạn Muốn Nhập Bao Nhiêu Nội Dung: $vang";
	$snd = (string)trim(fgets(STDIN));
while ($b < $snd){$b++;
echo $thanh_dep.$luc."Nhập Nội Dung Thứ $b: $vang";
$nhapcmt = (string)trim(fgets(STDIN));
if($nhapcmt == ''){break;}
array_push($khoCMT,$nhapcmt);
}
} else if($loaicmt == '2'){
$khoCMT=[];
$khoanh =[];
echo $thanh_dep.$luc."Bạn Muốn Nhập Bao Nhiêu Nội Dung: $vang";
	$snd = (string)trim(fgets(STDIN));
while ($b < $snd){$b++;
echo $thanh_dep.$luc."Nhập Nội Dung Thứ $b: $vang";
$nhapcmt = (string)trim(fgets(STDIN));
if($nhapcmt == ''){break;}
echo $thanh_dep.$luc."Nhập Link Ảnh Thứ $xnhac$b: $vang";
	$linkanh = trim(fgets(STDIN));
array_push($khoCMT,$nhapcmt); 
array_push($khoanh,$linkanh); 
}
} else if($loaicmt == '3'){
$khoCMT=[];
$khogif =[];
echo $thanh_dep.$luc."Bạn Muốn Nhập Bao Nhiêu Nội Dung: $vang";
	$snd = (string)trim(fgets(STDIN));
while ($b < $snd){$b++;
echo $thanh_dep.$luc."Nhập Nội Dung Thứ $b: $vang";
$nhapcmt = (string)trim(fgets(STDIN));
if($nhapcmt == ''){break;}
echo $thanh_dep.$luc."Nhập Link Ảnh GIF Thứ $xnhac$b: $vang";
	$linkgif = trim(fgets(STDIN));
array_push($khoCMT,$nhapcmt); 
array_push($khogif, $linkgif);
}
} else {
	exit($do." Lựa Chọn Không Xác Định \n");
}
@system('clear');
chay(35);
$list_cx =[];
echo $thanh_xau.$hong."TOOL NUÔI CLONE ĐA COOKIE \n";
usleep(2000);
echo $thanh_xau.$vang."Bản Quyền:".$xduong." Lê Văn Bình \n";
usleep(2000);
echo $thanh_xau.$do."Donate MoMo-Zalopay: ".$xduong."0357385033\n";
usleep(2000);
chay(35);
echo $thanh_dep."$luc Nhập \033[1;31m[\033[1;32m1\033[1;31m]$luc THƯƠNG THƯƠNG \n";
echo $thanh_dep."$luc Nhập \033[1;31m[\033[1;32m2\033[1;31m]$luc LIKE \n";
echo $thanh_dep."$luc Nhập \033[1;31m[\033[1;32m3\033[1;31m]$luc HAHA \n";
echo $thanh_dep."$luc Nhập \033[1;31m[\033[1;32m4\033[1;31m]$luc PHẪN NỘ \n";
echo $thanh_dep."$luc Nhập \033[1;31m[\033[1;32m5\033[1;31m]$luc WOW \n";
echo $thanh_dep."$luc Nhập \033[1;31m[\033[1;32m6\033[1;31m]$luc BUỒN \n";
echo $thanh_dep."$luc Nhập \033[1;31m[\033[1;32m7\033[1;31m]$luc YÊU THÍCH \n";
echo $luc." Ví dụ bạn muốn làm like haha thì điền 2+3 ";sleep(1); echo "\r"."                                                            "."\r";
echo $thanh_dep.$xnhac."Vui Lòng Nhập chế độ: $vang";
		$nhap = trim(fgets(STDIN));
if (strpos($nhap ,'1') !== false ){ array_push($list_cx,'THUONG');}
if (strpos($nhap ,'2') !== false ){ array_push($list_cx, 'LIKE');}
if (strpos($nhap ,'3') !== false ){ array_push($list_cx,'HAHA');}
if (strpos($nhap ,'4') !== false ){ array_push($list_cx, 'PHANNO');}
if (strpos($nhap ,'5') !== false ){ array_push($list_cx, 'WOW');}
if (strpos($nhap ,'6') !== false ){ array_push($list_cx, 'BUON');}
if (strpos($nhap ,'7') !== false ){ array_push($list_cx, 'LOVE');}
 if (count($list_cx) == 0){exit($do."Vui Lòng Chọn Ít Nhất 1 Nhiệm Vụ.     \n");}
echo "\n";
echo $redb."   ▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);
echo"\033[0;45m\e[1;32m✦ SETTINGS ✦\e[0m";
echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo"\e[0m\n\n";
usleep(30000);
echo $thanh_dep.$luc."Delay: $trang";
$delay=trim(fgets(STDIN));
if (count($khoCMT) >= 1 ){
echo $thanh_dep.$luc."Sau Bao Nhiêu Tương Tác Thì Comment 1 Lần: $vang";
	$lapcmt=trim(fgets(STDIN)); 
}
echo $thanh_dep.$luc."Sau Bao Nhiêu Nhiệm Vụ Thì Chuyển Acc: $vang";
   $yyy=trim(fgets(STDIN));
  echo $thanh_dep.$luc."Sau Bao Nhiêu Tương Tác Thì Dừng Tool: $vang";
	$stop=trim(fgets(STDIN)); 
echo "\n";
echo $redb."   ▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);
echo"\033[0;45m\e[1;32m✦ BẮT ĐẦU ✦\e[0m";
echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo $whiteb."▬";usleep(30000);echo $redb."▬";usleep(30000);echo"\e[0m\n\n";
usleep(30000);
while(true){
if (count($khock) == 0 ){
unset($a);
while (true){$a++;
echo $do."[".$luc."✓".$do."] ".$trang."=> ".$luc."Nhập Cookie Thứ $a: $vang";
$nhapck = trim(fgets(STDIN));
if($nhapck == ''){break;}
array_push($khock,$nhapck); }
$demacc=count($khock);
}
for($xz = 0; $xz < count($khock); $xz++){
	$cookie = $khock[$xz];
	$access_token = laytoken($cookie);
if ( $access_token == "2") { echo $do." Cookie Die !!!                         \n"; }
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
$idfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'id'};
echo $vang."Đang Tool ID: ".$luc.$idfb." ".$vang."Tên FB: ".$luc.$tenfb."".$res."\n";
$spam=0;
while (true){ 
if ($spam == 1) {break; }
  for($w = 0; $w < count($list_cx); $w++){
  	$list = gethome($cookie);
  $link2 = explode('">Bày tỏ cảm xúc',explode('/reactions/picker/?',$list)[1])[0];
  $url = 'https://mbasic.facebook.com/reactions/picker/?'.str_replace('&amp;','&',$link2);
  $id = explode('&origin_uri',explode('?ft_id=',$url)[1])[0];
  if ($id != ''){
  $type = $list_cx[$w];
  $mess = camxuctuongtac($cookie,$url,$type);
$maul=rand(31,37);
$maui="\033[1;".$maul."m";
switch($type) {
	case 'THUONG':
		$loai = "THƯƠNG THƯƠNG";
			break;
	case 'LIKE':
		$loai = "LIKE";
			break;
	case 'HAHA':
		$loai = "HAHA";
			break;
	case 'PHANNO':
		$loai = "PHẪN NỘ";
			break;
	case 'WOW':
		$loai = " WOW ";
			break;
	case 'BUON':
		$loai = " SAD ";
			break;
	default:
		$loai = "LOVE";
		break;
}
  $dem++;
  $kl = "\e[1;32m⌠\e[1;33mLVB\e[1;32m⌡\e[1;35m❯\e[1;36m❯\e[1;31m❯\033[1;34m[\033[1;33m".$dem."\033[1;34m]\033[1;91m 🍬 \033[1;36m".date("h:i:s")."\033[1;31m 🍬 \033[1;38;5;99m".$loai."\033[1;31m 🍬 \033[1;37m".$id."\033[1;31m 🍬 \033[1;32mSUCCESS\n"; $o++;$c++;$ct++;
for($i = 0; $i < strlen($kl); $i++){echo $kl[$i];usleep(2500);}
if($dem % $yyy == 0){$spam = 1; break; }
  delay($delay);
  if ((count($khoCMT) >= 1) and ($dem % $lapcmt == 0)){
  $zz = array_rand($khoCMT, 1);
	$msg = $khoCMT[$zz];
	if($loaicmt == '1'){
		$get = comment($id, $access_token, $msg);
	} else if($loaicmt == '2'){
		$linkanh = $khoanh[$zz];
		$get = comments($id, $access_token, $msg, $linkanh);
	} else if ($loaicmt == '3'){
		$linkgif = $khogif[$zz];
		$get = commentgif($id, $access_token, $msg, $linkgif);
	} 
	if ($get["error"]["code"] == 190) {
                    echo "Cookie Die !!?!                  \n";
                    array_splice($khock,$xz,1);
                    $spam = 1; break; }
    if ($get["error"]["code"] == 368 and $g["error"]["error_subcode"] == 1404078) {
                    echo "\033[1;91m".$get["error"]["message"]."\n";
                    array_splice($khock,$xz,1);
                    $spam = 1; break;
	}
  $kl = "\e[1;34m┌─\e[1;32m ⌠\e[1;33mLVB\e[1;32m⌡\e[1;35m❯\e[1;36m❯\e[1;31m❯ \033[1;36m".date("h:i:s")."\033[1;31m 🍬 \033[1;38;5;99mCOMMENT\033[1;31m 🍬 \033[1;37m".$id."\033[1;31m 🍬 \033[1;32mSUCCESS
\e[1;34m└──╼ \e[1;35m[\e[1;36mTEXT\e[1;35m] ".$msg."\n";
for($i = 0; $i < strlen($kl); $i++){echo $kl[$i];usleep(2500);}
if($dem % $yyy == 0){$spam = 1; break; }
delay($delay);
if ($dem > $stop ){
 echo $thanh_dep.$luc."Bạn Có Muốn Tiếp Tục Không (y/n): $vang";
	$nhap_stop = trim(fgets(STDIN));
if ( strtolower($nhap_stop) == 'y'){
 echo $thanh_dep.$luc."Bạn Muốn Tương Tác Thêm Bao Nhiêu Lần Nữa: $vang";
 	$them = trim(fgets(STDIN));
 	$stop = $stop + $them;
 echo $thanh_dep.$luc."Bạn Muốn Nhập Cookie Mới Không (y/n): $vang";
 	$nhap_ck = trim(fgets(STDIN));
 if (strtolower($nhap_ck) == 'y') { $khock = []; $spam = 1; break; }
} else { 
	exit($do." Cảm Ơn Bạn Đã Sử Dụng Tool Của Mình \n"); 
} 
} 
} 
if ($dem > $stop ){
 echo $thanh_dep.$luc."Bạn Có Muốn Tiếp Tục Không (y/n): $vang";
	$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $thanh_dep.$luc."Bạn Muốn Tương Tác Thêm Bao Nhiêu Lần Nữa: $vang";
			$them = trim(fgets(STDIN));
			$stop = $stop + $them;
		echo $thanh_dep.$luc."Bạn Muốn Nhập Cookie Mới Không (y/n): $vang";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { $khock = []; $spam = 1; break; }
	} else {
		exit($do." Cảm Ơn Bạn Đã Sử Dụng Tool Của Mình \n"); 
	} 
} 
unset($id);
} else { $w--; echo $do." Đang Lướt Tìm Bài Viết                         \r"; continue; }
}
}
}
}
function laytoken($cookie){
$ch=curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
$head[] = "Connection: keep-alive";
$head[] = "Keep-Alive: 300";
$head[] = "authority: m.facebook.com";
$head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
$head[] = "cache-control: max-age=0";
$head[] = "upgrade-insecure-requests: 1";
$head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
$head[] = "sec-fetch-site: none";
$head[] = "sec-fetch-mode: navigate";
$head[] = "sec-fetch-user: ?1";
$head[] = "sec-fetch-dest: document";
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
$access = curl_exec($ch);
curl_close($ch);
if (explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0]){
$access_token = explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0];
return $access_token; }
 else { return "2"; }
}
function camxuctuongtac($cookie,$url,$loai){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	$head[] = "Connection: keep-alive";
	$head[] = "Keep-Alive: 300";
	$head[] = "authority: m.facebook.com";
	$head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
	$head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
	$head[] = "cache-control: max-age=0";
	$head[] = "upgrade-insecure-requests: 1";
	$head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
	$head[] = "sec-fetch-site: none";
	$head[] = "sec-fetch-mode: navigate";
	$head[] = "sec-fetch-user: ?1";
	$head[] = "sec-fetch-dest: document";
	curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$m = curl_exec($ch);
if ($loai == 'LIKE'){ $link2 = explode('" style="display:block"',explode('&amp;reaction_type=1',$m)[1])[0];
  $link4 = '&amp;reaction_type=1'.$link2;
}
if ($loai == 'THUONG'){ $link2 = explode('" style="display:block"',explode('&amp;reaction_type=16',$m)[1])[0];
  $link4 = '&amp;reaction_type=16'.$link2;
}
if ($loai == 'LOVE'){ $link2 = explode('" style="display:block"',explode('&amp;reaction_type=2',$m)[1])[0];
  $link4 = '&amp;reaction_type=2'.$link2;
}
if ($loai == 'WOW' ){$link2 = explode('" style="display:block"',explode('&amp;reaction_type=3',$m)[1])[0];
  $link4 = '&amp;reaction_type=3'.$link2;
}
if ($loai == 'HAHA'){$link2 = explode('" style="display:block"',explode('&amp;reaction_type=4',$m)[1])[0];
  $link4 = '&amp;reaction_type=4'.$link2;
}
if ($loai == 'SAD'){$link2 = explode('" style="display:block"',explode('&amp;reaction_type=7',$m)[1])[0];
  $link4 = '&amp;reaction_type=7'.$link2;
}
if ($loai == ''){$link2= explode('" style="display:block"',explode('&amp;reaction_type=8')[1])[0];
  $link4 = '&amp;reaction_type=8'.$link2;
}
$link3 = explode('&amp;reaction_type=',explode('<a href="/ufi/reaction/?',$m)[1])[0];
$link5 = str_replace('&amp;', '&', $link3.$link4);
curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/ufi/reaction/?".$link5);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $n =	curl_exec($ch);
 curl_close($ch);
 return 
explode('</title><meta',explode('head><title>',$n)[1])[0];}
function gethome($cookie){
$ch = curl_init();
$head= array("Connection: keep-alive","Keep-Alive: 300","authority: m.facebook.com","ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7","accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5","cache-control: max-age=0","upgrade-insecure-requests: 1","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","sec-fetch-site: none","sec-fetch-mode: navigate","sec-fetch-user: ?1","sec-fetch-dest: document");
$ch=curl_init();
	curl_setopt_array($ch , array(
		CURLOPT_URL => 'https://mbasic.facebook.com/home.php',
		CURLOPT_TIMEOUT => 60,
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_CONNECTTIMEOUT => 60,
		CURLOPT_USERAGENT => $_SESSION['useragent'],
		CURLOPT_COOKIE => $cookie,
		CURLOPT_SSL_VERIFYPEER => TRUE,
		CURLOPT_HTTPHEADER => $head
	));
$access = curl_exec($ch);
return $access;
}
function comment($id, $access_token, $msg){
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array(
		'message' => $msg,
		'access_token' => $access_token,
	);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access, true);
}
function comments($id, $access_token, $msg, $linkanh){
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array(
		'message' => $msg,
		'access_token' => $access_token,
		'attachment_url' => $linkanh
	);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access, true);
}
function commentgif($id, $access_token, $msg, $linkgif){
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array(
		'message' => $msg,
		'access_token' => $access_token,
		'attachment_share_url' => $linkgif
	);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function delay($delay){
	for($tt = $delay ;$tt>= 1;$tt--){
        echo "\r\033[1;33m   LVB \033[1;31m ~>       \033[1;32m LO      \033[1;31m | $tt | "; usleep(150000);
        echo "\r\033[1;31m   LVB \033[0;33m   ~>     \033[0;37m LOA     \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;32m   LVB \033[0;33m     ~>   \033[0;37m LOAD    \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;34m   LVB \033[0;33m       ~> \033[0;37m LOADI   \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADIN  \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADING \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADING.\033[0;31m | $tt | ";usleep(150000);} 
echo "\r\e[1;95m    ⚡LÊ VĂN BÌNH⚡                       \r"; }
function chay($t) { for ($x = 0; $x <= $t; $x++) { echo "\033[1;37m= ";usleep(4000); } echo"\n";}                                                                         