error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
$useragent = "Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.1.4472.202 Mobile Safari/537.36";
// login 
echo chay(10);
echo $BGreen."Nhập Cookie TTC : $BWhite";
$cookie = trim(fgets(STDIN));
// home
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://tuongtaccheo.com/home.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr,CURLOPT_COOKIE,$cookie);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$name = explode('<i>', $mr2)[1];
$name = explode('<', $name)[0];

$xu = explode('<li><a>Số dư: <strong style="color: red;" id="soduchinh">', $mr2)[1];
$xu = explode('<', $xu)[0];
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen TOOL AUTO TTC TIKTOK \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen Tài Khoản TTC Của Bạn Là: ".$BWhite.$name."\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen Số Xu Hiện Tại Của Bạn Là: ".$BWhite.$xu."\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen LIKE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen FOLLOW\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Nhập Số Để Chạy Nhiệm Vụ: $BWhite";
$chon =trim(fgets(STDIN));
echo chay(10);
$dem = 0;
while (true){
// like
if($chon == '1'){
$header = array( 
"Host:tuongtaccheo.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"referer:https://tuongtaccheo.com/tiktok/kiemtien/",
"cookie:$cookie",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://tuongtaccheo.com/tiktok/kiemtien/getpost.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$list = explode('idpost":"', $mr2);
$kho = '';
for($i = 1; $i <= count($list); $i++){
$dem++;
$uid = $list[$i];
$id = explode('","', $uid)[0];
$so++;
echo $BCyan."[$so]$BRed 🍬$BGreen ".date("H:i")."$BRed 🍬$BGreen [LIKE] $BRed 🍬$BGreen [$id]  \n";
$link = explode('"}', explode('link":"', $uid)[1])[0];
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
    	    @system('xdg-open '.$link);
    	} else {
        	@system('cmd /c start https://www.tiktok.com/@'.$link);
    	}
sleep (2);
delay(5);
$kho = $kho.$id.",";
if($dem % 5 == 0){
// nhận tiền
$khoid = substr($kho, 0, (strlen($kho) - 1));
$header = array( 
"Host:tuongtaccheo.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://tuongtaccheo.com",
"referer:https://tuongtaccheo.com/tiktok/kiemtien/",
"cookie:$cookie",
);
$data = 'id='.$khoid;
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://tuongtaccheo.com/tiktok/kiemtien/nhantien.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$nhan = explode('mess":"', $mr2)[1];
$nhan = explode('"', $nhan)[0];
$sd = explode('sodu":', $mr2)[1];
$sd = explode('"', $sd)[0];
// xu
$url ="https://tuongtaccheo.com/home.php";
$mr2 = home($url,$cookie);
$xu = explode('<li><a>Số dư: <strong style="color: red;" id="soduchinh">', $mr2)[1];
$xu = explode('<', $xu)[0];

echo $BCyan." $nhan $BRed 🍬$BYellow $xu 💸 \n";
}
}}
// follow
if($chon == '2'){
$header = array( 
"Host:tuongtaccheo.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"referer:https://tuongtaccheo.com/tiktok/kiemtien/subcheo/",
"cookie:$cookie",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://tuongtaccheo.com/tiktok/kiemtien/subcheo/getpost.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$list = explode('idpost":"', $mr2);
//print_r($list); die;
$kho = '';
for($i = 1; $i <= count($list); $i++){
$dem++;
$uid = $list[$i];
$id = explode('","', $uid)[0];
$so++;
echo $BCyan."[$so]$BRed 🍬$BGreen ".date("H:i")."$BRed 🍬$BGreen [FOLLOW] $BRed 🍬$BGreen [$id]  \n";
$link = explode('"}', explode('link":"', $uid)[1])[0];
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
    	    @system('xdg-open https://www.tiktok.com/@'.$link);
    	} else {
        	@system('cmd /c start https://www.tiktok.com/@'.$link);
    	}
sleep (2);
delay(5);
$kho = $kho.$id.",";
if($dem % 3 == 0){
// nhận tiền
$khoid = substr($kho, 0, (strlen($kho) - 1));
$header = array( 
"Host:tuongtaccheo.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://tuongtaccheo.com",
"referer:https://tuongtaccheo.com/tiktok/kiemtien/subcheo/",
"cookie:$cookie",
);
$data = 'id='.$khoid;
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://tuongtaccheo.com/tiktok/kiemtien/subcheo/nhantien.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$nhan = explode('mess":"', $mr2)[1];
$nhan = explode('"', $nhan)[0];
$sd = explode('sodu":', $mr2)[1];
$sd = explode('"', $sd)[0];
// xu
$url ="https://tuongtaccheo.com/home.php";
$mr2 = home($url,$cookie);
$xu = explode('<li><a>Số dư: <strong style="color: red;" id="soduchinh">', $mr2)[1];
$xu = explode('<', $xu)[0];

echo $BCyan." $nhan $BRed 🍬$BYellow $xu 💸 \n";
}
}}
}
function home($url,$cookie){
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, $url);
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr,CURLOPT_COOKIE,$cookie);
curl_setopt($mr, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
$mr2 = curl_exec($mr); 
curl_close($mr);
return $mr2;
}
function delay ($delay){
	for($tt = $delay ;$tt>= 1;$tt--){
        echo "\r\033[1;33m   LVB \033[1;31m ~>       \033[1;32m LO      \033[1;31m | $tt | "; usleep(150000);
        echo "\r\033[1;31m   LVB \033[0;33m   ~>     \033[0;37m LOA     \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;32m   LVB \033[0;33m     ~>   \033[0;37m LOAD    \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;34m   LVB \033[0;33m       ~> \033[0;37m LOADI   \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADIN  \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADING \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADING.\033[0;31m | $tt | ";usleep(150000);} 
echo "\r\e[1;95m    ⚡LÊ VĂN BÌNH⚡                       \r"; 
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}