error_reporting(0);
session_start();
///background 
date_default_timezone_set( 'Asia/Ho_Chi_Minh' );
$fullxduong= "\e[1;47;34m";
$fulldo= "\e[1;47;31m";
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$fullluc= "\e[1;47;32m";
$fullxnhac= "\e[1;47;36m";
$fullden= "\e[1;47;30m";
$fullvang= "\e[1;47;33m";
$fullhong= "\e[1;47;33m";
$xnhac= "\033[1;96m";
$trang="\033[1;97m";
$den="\033[1;90m";
$do="\033[1;91m";
$luc="\033[1;92m";
$vang="\033[1;93m";
$xduong="\033[1;94m";
$hong="\033[1;95m";
$ngay = date('d-m-Y');
$thoigian = date('H:i:s');
$catkhung="\033[0m";
$khungdo="\033[1;4";
$khungden="\033[1;40m";
$khungvang="\033[1;43m";
$khungluc="\033[1;42m";
$khungduong="\033[1;44m";
$khunghong="\033[1;45m";
$khungtrang="\033[1;4";
$khungxam="\033[1;4";
////sever 
system('clear');
sleep(1);
echo chay(10);
    echo $luc."Nhập Cookie Facebook : $BWhite";
    $cookie = trim(fgets(STDIN));
//check cookie
$ch=curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
$head[] = "Connection: keep-alive";
$head[] = "Keep-Alive: 300";
$head[] = "authority: m.facebook.com";
$head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
$head[] = "cache-control: max-age=0";
$head[] = "upgrade-insecure-requests: 1";
$head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
$head[] = "sec-fetch-site: none";
$head[] = "sec-fetch-mode: navigate";
$head[] = "sec-fetch-user: ?1";
$head[] = "sec-fetch-dest: document";
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
$access = curl_exec($ch);
curl_close($ch);
if (explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0]){
$access_token = explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0];
} else { }
if (json_decode(file_get_contents('https://graph.facebook.com/me/?access_token=' . $access_token))->{'id'}) {
			$idfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token=' . $access_token))->{'id'};
			$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token=' . $access_token))->{'name'};
  } else {
			echo $do."Cookie Của Bạn Lỗi, Vui Lòng Nhập Lại.\n"; exit();
		}
$data =  file_get_contents('https://graph.facebook.com/me/friends?fields=id&access_token='.$access_token);
$json = json_decode($data, true);
$banbe0 = count($json["data"]);
system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO CHỌC BẠN BÈ FACEBOOK COOKIE \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen ID Facebook :  $BCyan$idfb \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Tên Facebook : $BGreen$tenfb \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Bạn Bè Hiện Có : $BYellow$banbe0 \n"; usleep(100000);
echo chay(10);
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime Số Lượng Cần Chọc : $BWhite";
$slc = trim(fgets (STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime Thời Gian Mỗi Lần Chọc : $BWhite";
$delay = trim(fgets(STDIN));
echo chay(10);
while (true){
 	        $header = array(
            "Host: mbasic.facebook.com",
            "upgrade-insecure-requests: 1",
            "save-data: on",
            "user-agent:Mozilla/5.0 (Linux; Android 8.1.0; CPH1803) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
            "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*" . "/" . "*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "sec-fetch-site:same-origin",
            "sec-fetch-mode:navigate",
            "sec-fetch-user:?1",
            "sec-fetch-dest:document",
            "accept-language:vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
            "cookie:$cookie",
        );
        $url = "https://mbasic.facebook.com/pokes/?ref_component=mbasic_bookmark&ref_page=XMenuController";
        $mr = curl_init();
        curl_setopt_array($mr, array(
            CURLOPT_PORT => "443",
            CURLOPT_URL => "$url",
            CURLOPT_ENCODING => "",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => $header
        ));
        $mr2 = curl_exec($mr);
        curl_close($mr);
        $json = json_decode($mr2, true);
        $id = explode('/pokes/inline/?', $mr2)[1];
        $id = explode('"', $id)[0];
        $ok = explode('poke_target=', $mr2)[1];
        $ok = explode('&', $ok)[0];
        $url = 'https://mbasic.facebook.com/pokes/inline/?' . htmlspecialchars_decode($id) . '';
        $mr = curl_init();
        curl_setopt_array($mr, array(
            CURLOPT_PORT => "443",
            CURLOPT_URL => "$url",
            CURLOPT_ENCODING => "",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => $header
        ));
        $mr2 = curl_exec($mr);
        curl_close($mr);
        $json = json_decode($mr2, true);
 if ( $id !== "" ){
        $te=json_decode(file_get_contents('https://graph.facebook.com/?ids='.$ok.'&fields=id,name&access_token='.$access_token), true);
		$ten=$te[$ok]["name"];
		$maul=rand(31,37);
		$maui="\033[1;".$maul."m";
        $dem++;
        echo $vang."";
          $t=$BCyan."[".$BCyan.$dem.$BCyan."]".$do." ● ".$xnhac.date("H:i")."".$do." ●".$luc." Chọc Thành Công".$do." ● ".$BGreen.$ok.$do." ● ".$vang.$ten."\n";
			for($i=11;$i<(strlen($t)+1);$i++){echo $t[$i];
			  usleep(3000);
			}
for($countdown = 0;$countdown<($delay+1);$countdown++){
             echo "\r\033[1;93m   ┗(•°_°•)\033[1;91m ~>       \033[1;92m L      \033[1;91m |\033[1;93m ".($delay-$countdown)."\033[1;91m | ";
        usleep(150000);

        echo "\r\033[1;91m   ┗(•°_°•)\033[0;33m   ~>     \033[0;37m LO     \033[0;31m |\033[0;33m ".($delay-$countdown)."\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;92m   ┗(•°_°•)\033[0;33m     ~>   \033[0;37m LOA    \033[0;31m |\033[0;33m ".($delay-$countdown)."\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;94m   ┗(•°_°•)\033[0;33m       ~> \033[0;37m LOAD   \033[0;31m |\033[0;33m ".($delay-$countdown)."\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;95m   ┗(•°_°•)\033[0;33m        ~>\033[0;37m LOAD.  \033[0;31m |\033[0;33m ".($delay-$countdown)."\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;95m   ┗(•°_°•)\033[0;33m        ~>\033[0;37m LOAD.. \033[0;31m |\033[0;33m ".($delay-$countdown)."\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;95m   ┗(•°_°•)\033[0;33m        ~>\033[0;37m LOAD...\033[0;31m |\033[0;33m ".($delay-$countdown)."\033[0;31m | ";
        usleep(100000);
        echo "\r                                          \r";}}
 if ( $dem >= $slc ) { 
echo $luc." Đã Chọc Thành Công \e[1;96m".$dem."\e[1;92m Bạn Bè Của \e[1;96m".$tenfb."\n"; exit();
}
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}