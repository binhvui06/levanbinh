error_reporting(0);
session_start();
date_default_timezone_set("Asia/Ho_Chi_Minh");
$yellow = "\033[0;33m";
$maufullxduong= "\e[1;47;34m";
$maufulldo= "\e[1;47;31m";
$maufullluc= "\e[1;47;32m";
$maufullxnhac= "\e[1;47;36m";
$maufullden= "\e[1;47;30m";
$maufullvang= "\e[1;47;33m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$tim = "\033[1;35m";
$xnhac = "\033[1;36m";
$trang = "\033[1;37m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
$ress = "\033[0;32m";
$res = "\033[0;33m";
$red = "\033[0;31m";
$green = "\033[0;37m";
$nau= "\e[38;5;94m";
$white = "\033[0;33m";
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
$listnv = [];
if (file_exists("IG.txt") == '1'){
  echo  "\033[1;32mBạn có muốn đăng nhập vào tài khoản cũ bấn nút $BCyan \033[1;31menter \033[1;32mđể tiếp tục, Bấm $BCyan \033[1;31mno \033[1;32mđể nhập lại tài khoản mới : $BWhite";
  $nhap =trim(fgets(STDIN));
if ($nhap == 'no'){
  $my = fopen("IG.txt", "w+");
echo chay(10);
  echo "$BGreen Nhập Tài Khoản : $BWhite";
  $user = trim(fgets(STDIN));
  echo "$BGreen Nhập Mật Khẩu : $BWhite";
  $pass = trim(fgets(STDIN));
fwrite($my,json_encode(array('username'=> $user,'password'=> $pass)));
}
}else if(!file_exists("IG.txt")){
  $my = fopen("IG.txt", "w+");
  echo "$BGreen Nhập Tài Khoản :$BGreen  $BWhite";
  $user = trim(fgets(STDIN));
  echo "$BGreen Nhập Mật Khẩu :$BGreen $BWhite";
  $pass = trim(fgets(STDIN));
fwrite($my,json_encode(array('username'=> $user,'password'=> $pass)));
}
$user = json_decode(file_get_contents("IG.txt"))->{'username'};
$pass = json_decode(file_get_contents("IG.txt"))->{'password'};
$source = getcookieig($user,$pass,$useragent);
if ($source == '2'){
  echo '';
}else{
	exit($BRed."ĐĂNG NHẬP THẤT BẠI, SAI TÀI KHOẢN VIPIG  !");
}
echo chay(10);
$c = 0; $thu = 1;
echo "\033[1;33mBạn muốn treo mấy acc instagram : $BWhite";
$treo = trim(fgets(STDIN));
if(!is_numeric($treo)){$treo = 1;}
for($b=1;$b<($treo + 1);$b++){
    echo $BBlue."Điền cookie thứ $BGreen".$thu." : $BWhite";
    $cooki[$c]=trim(fgets(STDIN));
    
    $cookieaofix=$cooki[$c];
    
    $info = laythongtin($cooki[$c],$useragent);
if($info[1]){
  $uidif[$c] = $info[1];
  $header[$c] = $info[0];
echo $BYellow." Tài khoản chính xác \n"; $c++;$thu++;
}else{echo $BRed." COOKIE SAI RỒI!! \n";$b--;}
}
@system('clear');
$cookie = $cooki[0];
$head = $header[0];
$idig = $uidif[0];
$h = datnickig($idig,$useragent);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO VIPIG COOKIE ĐA LUỒNG \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Facebook : $BPurple 100047478314721 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Đang chạy tài khoản:  $BCyan$user\n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Đang chạy đa luồng: $BBlack ".$treo."$BGreen tài khoản \n"; usleep(100000);
$xu = getxuig($useragent); usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Số xu hiện tại: [$BGreen$xu]\n"; usleep(100000);
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen LIKE \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen COMMENTS \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime  Nhập \033[1;31m[\033[1;32m3\033[1;31m]$BGreen FOLLOW \n";
echo $BGreen." Ví dụ bạn muốn làm like follow thì điền 1+3 ";sleep(3); echo "\r"."                                                           "."\r";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime  Vui Lòng Nhập chế độ : ";
$nhap = trim(fgets(STDIN));
if (strstr($nhap, '1')){array_push($listnv, 'like');}
if (strstr($nhap, '2')){array_push($listnv, 'cmt');}
if (strstr($nhap, '3')){array_push($listnv, 'sub');}
 if (count($listnv) == 0){exit($BRed."Vui lòng chọn ít nhất 1 loại NHIỆM VỤ!");}
echo chay(10);
 echo $xanh."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BGreen Nhập thời gian làm nhiệm vụ cmt, follow : $BWhite";
    $giaysub=trim(fgets(STDIN));
    echo $xanh."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BGreen Nhập thời gian làm nhiệm vụ like : $BWhite";
    $giaylike=trim(fgets(STDIN));
if ($treo ==1){echo $xanh."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BGreen Sau bao nhiệm vụ thì sẽ nghỉ ngơi : $BWhite ";}else{
    echo $xanh."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$xanh  \033[1;31m[\033[1;32m✓\033[1;31m]$BGreen Sau bao nhiêu nhiệm vụ đổi nick : $BWhite";}
     $dung=trim(fgets(STDIN));    if (strlen($dung) <= 0){$dung = 10;}
if($treo == 1){echo $xanh."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BGreen Dừng thời gian : $BWhite ";
      $giay=trim(fgets(STDIN));}
      echo chay(10);
 $so = 0; $a = 0;
if($h != 1){
  echo " VÀO WEB ĐẶT CẤU HÌNH RỒI VÀO TOOL ĐỢI 30 GIÂY NHÉ \n";
  $h = datnickig($idig,$useragent);
}  
 echo $BGreen." Đang chạy ID ".$idig."\n";
 while(true){

   $sonv = 0;
   if (in_array('like',$listnv)){
   getcookieig($user,$pass,$useragent);
    $list0 = getnvig('',$useragent);
if(is_array($list0)){
    if(count($list0) > 1){
    $listds['like'] = $list0;
    $sonv = $sonv + count($listds['like']);
    }else{$listds['like'] = null;}}
  }else{$listds['like'] = null;}
  if(in_array('sub',$listnv)){
    $list1 = getnvig('/subcheo',$useragent);
if(is_array($list1)){
    if(count($list1) > 1 ){
    $listds['sub'] = $list1;
     $sonv = $sonv + count($listds['sub']);
    }else{$listds['sub'] = null;}}
  }else{$listds['sub'] = null;}
  if(in_array('cmt',$listnv)){
    $list2 = getnvig('/cmtcheo',$useragent);
if(is_array($list2)){
    if(count($list2) > 1){
    $listds['cmt'] = $list2;
    $sonv = $sonv + count($listds['cmt']);
    }else{$listds['cmt'] = null;}}
  }else{$listds['cmt'] = null;}
  echo "\r";$demdung = 0; $i = 0;
while($sonv > 0){
  if ($listds['like'] and is_array($listds['like'])){$sonv--;
     $i++;if($demdung >= $dung){break;}
     $ranar = array_rand($listds['like'],1);
      $key = $listds['like'][$ranar];
      $link = $key->{'link'};
      $uid = $key->{'idpost'};
      $id = layidlikesub($cookie,'like',$link,$useragent,$head);
$like = http_build_query(array('id'=> $uid));
$g = lamnhiemvu($cookie,$id,$useragent,$head);
	$s = nhantienig('',$like,$useragent);
if ($s == '2'){$xu = $xu + 200;$so++;$demdung++;
			echo echonhanxu(200,'TIM',$uid,$xu,$so);
			echo echodemgiay($giaylike);
					}else{

	if($g == '0' or $g == '1'  ){
	  break;
	}
					}
      unset($listds['like'][$ranar]);
    }
if ($listds['sub'] and is_array($listds['sub'])){$sonv--;
    $i++;if($demdung >= $dung){break;}
    $ranar = array_rand($listds['sub'],1);
      $key = $listds['sub'][$ranar];
      $uid = $key->{'soID'};
      $tid = $key->{'idpost'};
$link = 'https://www.instagram.com/web/friendships/'.$uid.'/follow/';
$g = lamnhiemvu($cookie,$link,$useragent,$head);
   if($g == '0' or $g == '1' ){
     break;
   }
$sub = http_build_query(array('id'=>$uid,'tid'=>$tid));
      $s = nhantienig('/subcheo',$sub,$useragent);
if (isset($s)){$xu = $xu + 600;$so++;$demdung++;
			echo echonhanxu(600,'FOLLOW',$uid,$xu,$so);
			echo echodemgiay($giaysub);
					}else{

					}
      unset($listds['sub'][$ranar]);
    }
     if ($listds['cmt'] and is_array($listds['cmt'])){$sonv--;
      $i++;if($demdung >= $dung){break;}
      $ranar = array_rand($listds['cmt'],1);
    $link = $key->{'link'};
    $uid = $key->{'idpost'};
    $id = layidlikesub($cookie,'cmt',$link,$useragent,$head);
$msg = json_decode($key->{'nd'})[1];
$g = cmtig($cookie,$id,$msg,$useragent,$head);
 if ($g == '0' or $g == '1' ){
        break;}
$cmt = http_build_query(array('id'=> $uid));
$s = nhantienig('/cmtcheo',$cmt,$useragent);
if ($s == '2'){$xu = $xu + 600;$so++;$demdung++;
			echo echonhanxu(600,'CMT',$uid,$xu,$so);
			echo echodemgiay($giaysub);
					}else{

					}
      unset($listds['cmt'][$ranar]);
    }
}
if($treo == '1' and $demdung == $dung){
  echo nghingoi($giay); $demdung = 0; $demdung = 0;
  getcookieig($user,$pass,$useragent);
}
if(($g == '0' or $g == '1') and $treo == 1){

$cookie = $cookieaofix;
$info = laythongtin($cookie,$useragent);
$head = $info[0];
$idig = $info[1];
if(isset($idig)){
getcookieig($user,$pass,$useragent);
$h = datnickig($idig,$useragent);
if($h != '1'){
  echo $BRed."WARNING:$BYellow IDFB ".$idig."$BRed chưa được thêm vào cấu hình trao đổi sub vui lòng thêm vào rồi lại cho vào tool \n";exit;
}
}
}else if(($g == '0' or $g == '1' or $dung <= $demdung) and $treo >= 2){
  $tat = 0;
  $cookie = $cooki[$a];
  $a++;if($a>=$treo){$a=0;} $demdung = 0;
$info = laythongtin($cookie,$useragent);
$head = $info[0];
$idig = $info[1];
if(isset($idig)){
	   echo $BYellow."  Đang chạy nick:  ".$BCyan."  ".$idig."\n";
$h = datnickig($idig,$useragent);
if($h != '1'){
  echo $BRed."WARNING:$BYellow IDFB ".$idig."$BRed chưa được thêm vào cấu hình trao đổi sub vui lòng thêm vào rồi lại cho vào tool \n";exit;
}
}
}
}
function echonhanxu($xu,$loai,$id,$soxu,$so){
  $time = date('H:i:s');
  if(strlen($id) >= 12){
    $id = substr($id,0,12);
  }
if(strlen($loai) == 3){$kc = '   ';}else if(strlen($loai) == 4){$kc = '  ';}else if(strlen($loai) == 5){$kc = ' ';}else{$kc = '';}
$string = "\033[1;36m[$so] \033[1;31m● \033[1;33m[$loai]$kc \033[1;31m●\033[1;35m [$time] \033[1;31m● \033[1;32m$id \033[1;31m●\033[1;32m $xu \033[1;31m● \033[1;33m$soxu \n";
for($i = 0;$i<= strlen($string);$i++){
  echo $string[$i];
  usleep(10000);
}
}
function echodemgiay($giay){
  for ($b = $giay;$b > 0;$b--){
  echo " \033[1;33m (◕︵◕) \033[1;30m~>          "." $b \r";usleep(100000);
  echo " \033[1;34m (◕︵◕)  \033[1;31m~>         "." $b \r";usleep(100000);
  echo " \033[1;35m (◕︵◕)   \033[1;32m~>        "." $b \r";usleep(100000);
  echo " \033[1;36m (◕︵◕)    \033[1;33m~>       "." $b \r";usleep(100000);
  echo " \033[1;37m (◕︵◕)     \033[1;34m~>      "." $b \r";usleep(100000);
  echo " \033[1;33m (◕︵◕)      \033[1;35m~>     "." $b \r";usleep(100000);
  echo " \033[1;34m (◕︵◕)       \033[1;36m~>    "." $b \r";usleep(100000);
  echo " \033[1;35m (◕︵◕)        \033[1;37m~>   "." $b \r";usleep(100000);
  echo " \033[1;36m (◕︵◕)         \033[1;33m~>  "." $b \r";usleep(100000);
  echo " \033[1;37m (◕︵◕)          \033[1;34m~> "." $b \r";usleep(100000);
  }
}
function checklive($token,$useragent,$head){
 $curl = curl_init();
 curl_setopt_array($curl,[
   CURLOPT_URL=>"https://graph.facebook.com/me/?access_token=".$token,
   CURLOPT_RETURNTRANSFER=>TRUE,
   CURLOPT_USERAGENT=>$useragent,
   CURLOPT_HTTPHEADER=>$head,
   ]);
   $m = json_decode(curl_exec($curl),true);
 if($m['id']){
   return '1';
 }else{ 
   return '2';
 }
}
function nghingoi($giay){
   for($v = 0;$v <= $giay;$v++){
   echo "\033[1;32mĐang nghỉ ngơi dưỡng sức \033[1;36m".($giay -$v)."\033[1;35m giây \033[1;37m--> ";sleep(1); echo "         \r";
  }
}
function nhantientds($loai,$id){
  global $useragent;
  global $token_tds;
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://traodoisub.com/api/coin/?type=".strtoupper($loai)."&id=".trim($id)."&access_token=".$token_tds);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
	$xu = json_decode(curl_exec($ch),true);
	curl_close($ch);
if($xu["success"])
{
  return '2';
}else return false;
}
function datnicktds($user,$idfb){
	$ch=curl_init();
	global $useragent;
	global $token_tds;
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
	curl_setopt($ch, CURLOPT_URL, 'https://traodoisub.com/api/?fields=run&id='.$idfb.'&access_token='.$token_tds);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    $json = json_decode(curl_exec($ch),true);
if($json["success"])
{
  return '1';
}else return false;
}
function getnvtds($loai){
 global $useragent;
 global $token_tds;
	$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,"https://traodoisub.com/api/?fields=".strtolower($loai)."&access_token=".$token_tds);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
$list = curl_exec($ch);
curl_close($ch);
return  json_decode($list,true);
}
function cookie($cookie,$useragent,$head){
$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
curl_setopt($ch, CURLOPT_USERAGENT,$useragent );
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
$access = curl_exec($ch);
curl_close($ch);
if (explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0])
{
        return explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0];
}else{
  return false;
}
}
function followtoken($access_token,$id,$useragent,$head){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/subscribers');
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
	$data = array('access_token' => $access_token);
	curl_setopt($ch, CURLOPT_POST,count($data));
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
	$access = curl_exec($ch);
	curl_close($ch);
	return json_decode($access);
}
function liketoken($access_token,$id,$useragent,$head){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/likes');
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
	$data = array('access_token' => $access_token);
	curl_setopt($ch, CURLOPT_POST,count($data));
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
	$access = curl_exec($ch);
	curl_close($ch);
	return json_decode($access);
}
function cmt($access_token,$msg,$id,$useragent,$head){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/comments');
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
	$data = array('message' => $msg,'access_token' => $access_token);
	curl_setopt($ch, CURLOPT_POST,count($data));
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
	$access = curl_exec($ch);
	curl_close($ch);
	return json_decode($access);
}
function gethome($cookie,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'https://mbasic.facebook.com/home.php');
curl_setopt($ch, CURLOPT_TIMEOUT,60);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,60);
curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
curl_setopt($ch, CURLOPT_COOKIE,$cookie);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,TRUE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
curl_setopt($ch, CURLOPT_ENCODING,'');
return  curl_exec($ch);
curl_close($ch);
}
function gettiephome($cookie,$linktiep,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$linktiep);
curl_setopt($ch, CURLOPT_TIMEOUT,60);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,60);
curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
curl_setopt($ch, CURLOPT_COOKIE,$cookie);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,TRUE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
curl_setopt($ch, CURLOPT_ENCODING,'');
return  curl_exec($ch);
curl_close($ch);
}
function thembanbe($cookie,$url,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'https://mbasic.facebook.com/friends/center/mbasic/?fb_ref=tn&sr=1&ref_component=mbasic_home_header&ref_page=MFriendsCenterMBasicController');
curl_setopt($ch, CURLOPT_TIMEOUT,60);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,60);
curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
curl_setopt($ch, CURLOPT_COOKIE,$cookie);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,TRUE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
curl_setopt($ch, CURLOPT_ENCODING,'');
$list = curl_exec($ch);
$link = explode('" class="',explode('/a/mobile/friends/add_friend.php?',$list)[1])[0];
$link2 = 'https://mbasic.facebook.com/a/mobile/friends/add_friend.php?'.str_replace('&amp;','&',$link);
curl_setopt($ch, CURLOPT_URL, $link2);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_exec($ch);
curl_close($ch);
return explode('&hf',explode('id=',$link2)[1])[0];
}
function camxuc($cookie,$id,$useragent,$type,$head){
	$ch = curl_init();
if(!strstr($id,'facebook')){
	if(strpos($id,'_')){
		$uid = explode('_',$id, 2);
		$id2 = 'story.php?story_fbid='.$uid[1].'&id='.$uid[0];
	}else{
		$id2 = $id;
	}
	curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$id2);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_HEADER,true );
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	 
	 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
	:'));
	$page = curl_exec($ch);
if (preg_match('~Location: (.*)~i', $page, $match)) {
   $location = trim($match[1]); 
if(strstr($location,'https://m.facebook.com')){
$link = 'https://mbasic.facebook.com'.explode('facebook.com',$location)[1];
curl_setopt($ch, CURLOPT_URL,$link);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$page = curl_exec($ch);
curl_close($ch);
}
}
	if ($id2 != $id && explode('&amp;origin_uri=',explode('amp;ft_id=',$page,2)[1],2)[0]){
		$get = explode('&amp;origin_uri=',explode('amp;ft_id=',$page,2)[1],2)[0];
	}else{
		$get = $id2;
	}
	$link = 'https://mbasic.facebook.com/reactions/picker/?is_permalink=1&ft_id='.$get;
}else{
  $link = $id;
}
$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_HEADER,true );
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	 
	 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
	:'));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$cx = curl_exec($ch);
	$haha = explode('<a href="',$cx);
	if ($type == 'LIKE'){
	  $haha2 = explode('" style="display:block"',$haha[1])[0];
	}else if ($type == 'LOVE'){
		$haha2 = explode('" style="display:block"',$haha[2])[0];
	}else if ($type == 'WOW'){
		$haha2 = explode('" style="display:block"',$haha[5])[0];
	}else if ($type == 'HAHA'){
		$haha2 = explode('" style="display:block"',$haha[4])[0];
	}else if ($type == 'SAD'){
		$haha2 = explode('" style="display:block"',$haha[6])[0];
	}else if ($type == 'ANGRY'){
		$haha2 = explode('" style="display:block"',$haha[7])[0];
	}else if ($type == 'THUONG'){
	  $haha2 = explode('" style="display:block"',$haha[3])[0];
	}
	$link2 = html_entity_decode($haha2);	
	curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com'.$link2);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$m =	curl_exec($ch);
return $m;
	curl_close($ch);
}
function page($id,$cookie,$useragent,$head){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$id);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	 
	 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
	:'));
	$page = curl_exec($ch);
	if (explode('&amp;refid=',explode('pageSuggestionsOnLiking=1&amp;gfid=',$page)[1])[0]){
		$get = explode('&amp;refid=',explode('pageSuggestionsOnLiking=1&amp;gfid=',$page)[1])[0];
		$link = 'https://mbasic.facebook.com/a/profile.php?fan&id='.$id.'&origin=page_profile&pageSuggestionsOnLiking=1&gfid='.$get.'&refid=17';
		curl_setopt($ch, CURLOPT_URL, $link);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_exec($ch);
	}
	curl_close($ch);
}
function gettt($cookie,$useragent,$head){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/home.php');
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$data = curl_exec($ch);
$haha = explode('<a href="/reactions/picker/?',$data);
$row =[];$i = 1;
$count = count($haha);
while ($count > 0){
  $count--;
$link = explode('">Bày tỏ cảm xúc</a><',$haha[$i])[0];$i++;
$row[] = 'https://mbasic.facebook.com/reactions/picker/?'.html_entity_decode($link);
}
return $row;
}
function huyfollow($cookie,$id,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$id);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	 
	 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$n = curl_exec($ch);
$lin = explode('">Bỏ theo dõi',explode('/a/subscriptions/remove?', $n)[1])[0];
$link = str_replace('&amp;', '&', $lin);
curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/a/subscriptions/remove?".$link);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$n =	curl_exec($ch);
curl_close($ch);
return explode('</title><meta',explode('head><title>',$n)[1])[0];
}
function getidunfl($cookie,$idfb,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/timeline/app_collection/?'.http_build_query(array( 'collection_token'=> $idfb.':2356318349:33', '_rdr'=> '')));
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	 
	 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$n = curl_exec($ch);
$lin = explode('collection',explode('/timeline/app_collection/more/?collection_token', $n)[1])[0];
$link = str_replace('&amp;','&',$lin);
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/timeline/app_collection/more/?collection_token'.$link.'collection');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$m = curl_exec($ch);
curl_close($ch);
$liss = [];
$n = explode('\">\u003Cspan',explode('href=\"\/',$m)[1])[0];
if ($n == ''){$bb = '1'; $liss = '1';}else{$bb = '2';}
while($bb == '2'){$i++;
$uid = explode('\">\u003Cspan',explode('href=\"\/',$m)[($i)])[0];
if (strlen($uid) < 100){
array_push($liss, $uid);}
if ($uid == ''){break;}
}
return $liss;
}
function bolikepage($cookie,$id,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$id);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$n = curl_exec($ch);
$lin = explode('" class="',explode('/a/profile.php?unfan', $n)[1])[0];
$link = html_entity_decode($lin);
curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/a/profile.php?unfan".$link);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $n =	curl_exec($ch);
 curl_close($ch);
return explode('</title><meta',explode('head><title>',$n)[1])[0];
}
function xacnhanbanbe($cookie,$id,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$id);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$n = curl_exec($ch);
$lin = explode('" class="',explode('/a/mobile/friends/profile_add_friend.php?', $n)[1])[0];
$link = html_entity_decode($lin);
curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/a/mobile/friends/profile_add_friend.php?".$link);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $n =	curl_exec($ch);
 curl_close($ch);
return explode('</title><meta',explode('head><title>',$n)[1])[0];
}
function xemlikepage($cookie,$access_token,$useragent,$head){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/me/likes?access_token='.$access_token.'&limit=5000&fields=name,id');
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	$access = curl_exec($ch);
	curl_close($ch);
	return json_decode($access);
}
function follow($cookie,$id,$useragent,$head){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$id);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$n = curl_exec($ch);
$lin = explode('" class="',explode('a/subscribe.php?', $n)[1])[0];
$link = str_replace('&amp;', '&', $lin);

curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/a/subscribe.php?".$link);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $n =	curl_exec($ch);
 curl_close($ch);
return explode('</title><meta',explode('head><title>',$n)[1])[0];
}
function addbanbe($cookie,$useragent,$head,$loai){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/friends/center/requests/#friends_center_main");
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	$access = curl_exec($ch);
	curl_close($ch);
	$data = explode('<a href="/a/notifications.php?'.$loai.'=',$access);
	$i = 1;
	$count = count($data);
	while($count > 1){
	  $count--; 
	$link = explode('" class="',$data[$i])[0];
	$i++;
	$row[] = "https://mbasic.facebook.com//a/notifications.php?$loai=".html_entity_decode($link);
	}
return $row;
}
function chaylinkfb($cookie,$link,$useragent,$head){
  $ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, $link);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	$access = curl_exec($ch);
	curl_close($ch);
	if (strlen($access) > 1000){
	  return '1';
	}else{ return '2'; }
}
function getbaiviet($cookie,$access_token,$useragent,$idfb,$head){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$idfb.'/posts?limit=1000&fields=id,name&access_token='.$access_token);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	$access = curl_exec($ch);
	curl_close($ch);
	return json_decode($access);
}
function demlike($cookie,$access_token,$idpost,$useragent,$head){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/v1.0/'.$idpost.'/likes?access_token='.$access_token.'&pretty=1&limit=5000');
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	$access = curl_exec($ch);
	curl_close($ch);
	return json_decode($access);
}
function getbanbe($access_token,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'https://graph.facebook.com/me/friends/?access_token='.$access_token);
curl_setopt($ch, CURLOPT_TIMEOUT,60);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,60);
curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
curl_setopt($ch, CURLOPT_ENCODING,'');
return json_decode(curl_exec($ch));
curl_close($ch);
}
function xoabanbe($cookie,$id,$useragent,$head){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'https://mbasic.facebook.com/profile.php?id='.$id);
curl_setopt($ch, CURLOPT_TIMEOUT,60);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,60);
curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
curl_setopt($ch, CURLOPT_COOKIE,$cookie);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
curl_setopt($ch, CURLOPT_ENCODING,'');
$list = curl_exec($ch);
$data1 = explode('" autocomplete=',explode('name="fb_dtsg" value="',$list)[1])[0];
$data2= explode('" autocomplete=',explode('name="jazoest" value="',$list)[1])[0];
$data = http_build_query(array('fb_dtsg'=>$data1,'jazoest'=>$data2,'friend_id'=>$id ,'unref'=>'profile_gear','confirm'=>'Xác nhận'));
$head[] = 'content-length: '.strlen($data);
$head[] = 'refer: https://mbasic.facebook.com/removefriend.php?friend_id='.$id.'&unref=profile_gear&refid=17';
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/a/removefriend.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$h = curl_exec($ch);
curl_close($ch);
}
function checktoken($access_token,$useragent,$head){
 $ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"https://graph.facebook.com/me/?access_token=".$access_token);
curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
$token = curl_exec($ch);
curl_close($ch);
return json_decode($token);
}
function getnv($loai,$useragent){
 $ch=curl_init();
 curl_setopt($ch, CURLOPT_URL,'https://tuongtaccheo.com/kiemtien'.$loai.'/getpost.php');
 $head[]='Host: tuongtaccheo.com';
 $head[]='accept: application/json, text/javascript, *'.'/'.'*; q=0.01';
 $head[]='x-requested-with: XMLHttpRequest';
 $head[] = "cookie: _ga=GA1.2.1589399778.".time().";";
$head[] = "cookie: _gat_gtag_UA_88794877_6=1;";
$head[] = "cookie: _gid=GA1.2.667146195.".time()."; ";
 curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
 curl_setopt($ch,CURLOPT_FOLLOWLOCATION, TRUE);
 curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
 curl_setopt($ch,CURLOPT_POST,1);
 curl_setopt($ch,CURLOPT_HTTPGET, true);
 curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
 curl_setopt($ch,CURLOPT_ENCODING, TRUE);
 curl_setopt($ch,CURLOPT_COOKIEFILE, "TTC.txt");
 return json_decode(curl_exec($ch));
 curl_close($ch);
}
function getcookiettc($user,$pass,$useragent){
  $ch=curl_init();
$head[] = 'Host: tuongtaccheo.com';
$head[] = "cookie: _ga=GA1.2.1589399778.".time().";";
$head[] = "cookie: _gat_gtag_UA_88794877_6=1;";
$head[] = "cookie: _gid=GA1.2.667146195.".time()."; ";
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, 'https://tuongtaccheo.com/login.php');
curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
curl_setopt($ch, CURLOPT_COOKIEJAR, "TTC.txt");
curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
$login = array('username' => $user,'password' => $pass,'submit' => ' ĐĂNG NHẬP');
curl_setopt($ch, CURLOPT_POST,count($login));
curl_setopt($ch, CURLOPT_POSTFIELDS,$login);
return curl_exec($ch);
curl_close($ch);
}
function nhantien($loai,$id,$useragent){
  $ch= curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://tuongtaccheo.com/kiemtien'.$loai.'/nhantien.php');
  $data = http_build_query(array('id'=> $id));
  $head[]='Host: tuongtaccheo.com';
  $head[]='content-length: '.strlen($data);
  $head[]='x-requested-with: XMLHttpRequest';
  $head[]='content-type: application/x-www-form-urlencoded; charset=UTF-8';
  $head[]='referer: https://tuongtacheo.com/kiemtien'.$loai;
  $head[]='origin: https://tuongtaccheo.com';
  $head[]='cookie: TawkConnectionTime=0';
  $head[] = "cookie: _ga=GA1.2.1589399778.".time().";";
$head[] = "cookie: _gat_gtag_UA_88794877_6=1;";
$head[] = "cookie: _gid=GA1.2.667146195.".time()."; ";
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
  curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_POST, 1);
  curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch,CURLOPT_COOKIEFILE,"TTC.txt");
  $xacnhan = curl_exec($ch);
return (strstr($xacnhan,'mess')) ? true : false;
}
function nhantiencx($id,$type,$useragent){
  $ch= curl_init();
  $dat= http_build_query(array('id'=> $id , 'loaicx'=> $type));
  curl_setopt($ch, CURLOPT_URL, 'https://tuongtaccheo.com/kiemtien/camxuccheo/nhantien.php');
  $head[]='Host: tuongtaccheo.com';
  $head[]='content-length: '.strlen($dat);
  $head[]='x-requested-with: XMLHttpRequest';
  $head[]='content-type: application/x-www-form-urlencoded; charset=UTF-8';
  $head[]='referer: https://tuongtacheo.com/kiemtien/camxuccheo/';
  $head[]='cookie: TawkConnectionTime=0';
  $head[] = "cookie: _ga=GA1.2.1589399778.".time().";";
$head[] = "cookie: _gat_gtag_UA_88794877_6=1;";
$head[] = "cookie: _gid=GA1.2.667146195.".time()."; ";
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
  curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_POST, 2);
  curl_setopt($ch,CURLOPT_POSTFIELDS,$dat);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch,CURLOPT_COOKIEFILE,"TTC.txt");
 $xacnhan = curl_exec($ch);
 return (strstr($xacnhan,'mess')) ? true : false;
}
function datnick($idfb,$useragent){
$dat=http_build_query(array('iddat[]'=> $idfb, 'loai'=>'fb'));
$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL,'https://tuongtaccheo.com/cauhinh/datnick.php');
	$head[]='Host: tuongtaccheo.com';
	$head[]='content-length: '.strlen($dat);
	$head[]='accept: */*';
	$head[]='x-requested-with: XMLHttpRequest';
	$head[]='content-type: application/x-www-form-urlencoded; charset=UTF-8';
	$head[]='cookie: TawkConnectionTime=0';
	$head[] = "cookie: _ga=GA1.2.1589399778.".time().";";
$head[] = "cookie: _gat_gtag_UA_88794877_6=1;";
$head[] = "cookie: _gid=GA1.2.667146195.".time()."; ";
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_POST, 1);
  curl_setopt($ch,CURLOPT_POSTFIELDS,$dat);
  curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,0);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch,CURLOPT_ENCODING, TRUE);
  curl_setopt($ch,CURLOPT_COOKIEFILE,"TTC.txt");
	return curl_exec($ch);
	curl_close($ch);
}
function getxuttc($useragent){
   $ch= curl_init();
  curl_setopt($ch, CURLOPT_URL, "https://tuongtaccheo.com/home.php");
  $head[]='Host: tuongtaccheo.com';
  $head[]='x-requested-with: XMLHttpRequest';
  $head[]='content-type: application/x-www-form-urlencoded; charset=UTF-8';
  $head[]='origin: https://tuongtaccheo.com';
  $head[]='cookie: TawkConnectionTime=0';
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch,CURLOPT_ENCODING, TRUE);
  curl_setopt($ch,CURLOPT_COOKIEFILE,"TTC.txt");
  $data = curl_exec($ch);
  curl_close($ch);
preg_match('#id="soduchinh">(.+?)<#is', $data, $sd);
return $sd["1"];
}
function checkmail($useragent,$email,$head){
    $ch = curl_init();
$ip = rand(100,200).'.'.rand(100,300).'.'.rand(100,300).'.'.rand(100,300);
$pass = md5(rand(1,20));
  curl_setopt_array($ch, array(
  CURLOPT_URL=> "https://b-graph.facebook.com/auth/login?email=$email&password=$pass&access_token=6628568379|c1e620fa708a1d5696fb991c1bde5662&method=post",
  CURLOPT_USERAGENT=> $useragent,
  CURLOPT_HTTPHEADER=> $head,
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_ENCODING=> TRUE
  ));
 return  json_decode(curl_exec($ch),true)["error"]['code'];
}
function nhanmail($loai,$mail,$somail,$so){
  $time = date('H:i:s');
echo "\033[1;33m[$so]"; usleep(30000); echo " \033[1;31m"; usleep(30000); echo "● \033[1;33m"; usleep(30000); echo "\033[1;31m"; usleep(30000); echo "●\033[1;35m "; usleep(30000); echo "[$time] \033[1;31m"; usleep(30000); echo "●"; usleep(30000); echo " \033[1;32m$mail \033[1;31m"; usleep(30000); echo "●\033[1;33m"; usleep(30000); echo " $loai \033[1;31m"; usleep(30000); echo "● "; usleep(30000); echo "\033[1;36m$somail \n";  
}
function layidlikesub($cookie,$loai,$link,$useragent,$head){
  $ch = curl_init();
    curl_setopt_array($ch, array(
    CURLOPT_URL=> $link,
    CURLOPT_USERAGENT =>$useragent,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIE => $cookie,
    CURLOPT_HTTPHEADER => $head,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_ENCODING => '',
    CURLOPT_HEADER => true));
    $data = curl_exec($ch);
 $num = explode('" />',explode('content="instagram://media?id=',$data)[1])[0];
if($loai == 'like'){
 return 'https://www.instagram.com/web/likes/'.$num.'/like/';
}else{
  return 'https://www.instagram.com/web/comments/'.$num.'/add/';
}
}
function laythongtin($cookie,$useragent){
  $ch = curl_init();
$head[] = "Host: www.instagram.com";
$head[] = "referer: https://www.instagram.com";
$head[] = "accept: */*";
$head[] = "content-type: application/x-www-form-urlencoded";
$head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
  curl_setopt_array($ch, array(
    CURLOPT_URL=> 'https://www.instagram.com/',
    CURLOPT_USERAGENT =>$useragent,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIE => $cookie,
    CURLOPT_HTTPHEADER => $head,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_ENCODING => '',
    CURLOPT_HEADER => true));
    $data = curl_exec($ch);
$xinta = explode('","',explode('"rollout_hash":"',$data)[1])[0];
$cookie = explode(';',explode('csrftoken=',$data)[1])[0];
$uid = explode('","is_joined_recently',explode('"id":"',$data)[1])[0];
$head[] = "x-csrftoken: $cookie";
$head[] = "x-ig-app-id: 1217981644879628";
$head[] = "x-instagram-ajax: $xinta";
return array($head,$uid);
}
function lamnhiemvu($cookie,$link,$useragent,$head){
  $ch = curl_init();
     curl_setopt($ch, CURLOPT_URL, $link);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$resut = json_decode(curl_exec($ch),true);
if (is_null($resut)){
  return '0';
}else if(strstr($resut['feedback_message'],'Chúng tôi hạn chế một số hoạt động để bảo vệ cộng đồng.')){
  return '1';
}else if($resut['status'] == 'ok'){
  return '2';
}
curl_close($ch);
}
function cmtig($cookie,$link,$msg,$useragent,$head){
  $ch = curl_init();
  $file = array('comment_text' => $msg,'replied_to_comment_id'=> '');
  curl_setopt($ch, CURLOPT_URL, $link);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, count($file));
	curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($file));
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$resut = json_decode(curl_exec($ch),true);
if (is_null($resut)){
  return '0';
}else if(strstr($resut['feedback_message'],'Chúng tôi hạn chế một số hoạt động để bảo vệ cộng đồng.')){
  return '1';
}else if($resut['status'] == 'ok'){
  return '2';
}
curl_close($ch);
}
function getcookieig($user,$pass,$useragent){
$ch=curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, 'https://vipig.net/login.php');
curl_setopt($ch, CURLOPT_COOKIEJAR, "IST.txt");
curl_setopt($ch, CURLOPT_USERAGENT,$useragent);
$login = array('username' => $user,'password' => $pass,'submit' => ' ĐĂNG NHẬP');
curl_setopt($ch, CURLOPT_POST,count($login));
curl_setopt($ch, CURLOPT_POSTFIELDS,$login);
$data = curl_exec($ch);
if(strlen($data) > 20){
  return false;
}else{
  return '2';
}
curl_close($ch);
}
function getnvig($loai,$useragent){
 $ch=curl_init();
 curl_setopt($ch, CURLOPT_URL,'https://vipig.net/kiemtien'.$loai.'/getpost.php');
 $head[]='Host: vipig.net';
 $head[]='accept: application/json, text/javascript, *'.'/'.'*; q=0.01';
 $head[]='x-requested-with: XMLHttpRequest';
 curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
 curl_setopt($ch,CURLOPT_FOLLOWLOCATION, TRUE);
 curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
 curl_setopt($ch,CURLOPT_POST,1);
 curl_setopt($ch,CURLOPT_HTTPGET, true);
 curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
 curl_setopt($ch,CURLOPT_ENCODING, TRUE);
 curl_setopt($ch,CURLOPT_COOKIEFILE, "IST.txt");
 return json_decode(curl_exec($ch));
 curl_close($ch);
}
function nhantienig($loai,$id,$useragent){
  $ch= curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://vipig.net/kiemtien'.$loai.'/nhantien.php');
  $data = $id;
  $head[]='Host: vipig.net';
  $head[]='content-length: '.strlen($data);
  $head[]='x-requested-with: XMLHttpRequest';
  $head[]='content-type: application/x-www-form-urlencoded; charset=UTF-8';
  $head[]='origin: https://vipig.net';
  $head[]='cookie: TawkConnectionTime=0';
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
  curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_POST, 1);
  curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
  curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,0);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch,CURLOPT_ENCODING, TRUE);
  curl_setopt($ch,CURLOPT_COOKIEFILE,"IST.txt");
  if(json_decode(curl_exec($ch))->{'mess'}){
    return '2';
  }
  curl_close($ch);
}
function datnickig($idfb,$useragent){
$dat=http_build_query(array('iddat[]'=> $idfb));
$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL,'https://vipig.net/cauhinh/datnick.php');
	$head[]='Host: vipig.net';
	$head[]='content-length: '.strlen($dat);
	$head[]='accept: */*';
	$head[]='x-requested-with: XMLHttpRequest';
	$head[]='content-type: application/x-www-form-urlencoded; charset=UTF-8';
	$head[]='cookie: TawkConnectionTime=0';
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_POST, 1);
  curl_setopt($ch,CURLOPT_POSTFIELDS,$dat);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch,CURLOPT_ENCODING, TRUE);
  curl_setopt($ch,CURLOPT_COOKIEFILE,"IST.txt");
	return curl_exec($ch);
	curl_close($ch);
}
function getxuig($useragent){
   $ch= curl_init();
  curl_setopt($ch, CURLOPT_URL, "https://vipig.net/home.php");
  $head[]='Host: vipig.net';
  $head[]='x-requested-with: XMLHttpRequest';
  $head[]='content-type: application/x-www-form-urlencoded; charset=UTF-8';
  $head[]='origin: https://tuongtaccheo.com';
  $head[]='cookie: TawkConnectionTime=0';
  curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch,CURLOPT_ENCODING, TRUE);
  curl_setopt($ch,CURLOPT_COOKIEFILE,"IST.txt");
  $data = curl_exec($ch);
  curl_close($ch);
preg_match('#id="soduchinh">(.+?)<#is', $data, $sd);
return $sd["1"];
}
function geturl($useragent){
  $ch = curl_init();
  $headhot = ["Host: signup.live.com",
           "accept: text/html,application/xhtml+xml,application/xml;q=0,9,image/webp,image/apng,*/*;q=0.8"
           ,
           "user-agent: ".$useragent];
  curl_setopt_array($ch, [
    CURLOPT_URL=> "https://signup.live.com/signup",
    CURLOPT_RETURNTRANSFER=>TRUE,
    CURLOPT_COOKIEJAR=>"cookie.txt",
    CURLOPT_FOLLOWLOCATION=>TRUE,
    CURLOPT_HEADER=>TRUE,
    CURLOPT_HTTPHEADER=> $headhot,
    ]);
$resut = curl_exec($ch);
unset($headhot);
$headhot[] = "Host: signup.live.com";
$headhot[] = "x-ms-apiversion: 2";
$headhot[] = "accept: application/json";
$headhot[] = "uaid: ".explode('","',explode('"uaid":"',$resut)[1])[0];
$canary = explode('","',explode('"apiCanary":"',$resut)[1])[0];
$headhot[] = "canary: ".json_decode('["'.$canary.'"]')[0];
$headhot[] = "hpgid: ".(explode(',"',explode('"hpgid":',$resut)[1])[0]);
$chuoi = (explode('"},',explode('"tcxt":"',$resut)[1])[0]);
$headhot[] = "tcxt: ".json_decode('["'.$chuoi.'"]')[0];
$headhot[] = "uiflvr: 1001";
$headhot[] = "scid: 100118";
$headhot[] = "referer: https://signup.live.com/";
$headhot[] = "x-ms-apitransport: xhr";
$url = curl_getinfo($ch)['url'];
return $headhot;
}
function checkmaillive($headhot,$mail){
  $ch = curl_init();
  $uaid = str_replace('uaid: ','',$headhot[3]);
  $hpgid = str_replace('hpgid: ','',$headhot[5]);
$data = '{"signInName":"'.$mail.'","uaid":"'.$uaid.'","includeSuggestions":true,"uiflvr":1001,"scid":100118,"hpgid":'.$hpgid.'}';
$headhot[] = "content-length: ".strlen($data);
  curl_setopt_array($ch, [
    CURLOPT_URL=> "https://signup.live.com/API/CheckAvailableSigninNames?lic=1",
    CURLOPT_RETURNTRANSFER=>TRUE,
    CURLOPT_FOLLOWLOCATION=>TRUE,
    CURLOPT_CUSTOMREQUEST=>"POST",
    CURLOPT_POST=> 5,
    CURLOPT_POSTFIELDS=> $data,
    CURLOPT_HTTPHEADER=> $headhot,
    CURLOPT_COOKIEFILE=>"cookie.txt"
    ]);
return json_decode(curl_exec($ch),true);
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}
?>