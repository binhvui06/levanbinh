date_default_timezone_set("Asia/Ho_Chi_Minh");
error_reporting(0);
session_start();
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$green = "[1;32m";
$wait = $green . "Đợi";
$xnhac = "[1;96m";
$res = "[0m";
$do = "[1;91m";
$den = "[1;90m";
$red = "[1;31m";
$yellow = "[1;93m";
$lightblue = "[1;35m";
$bluelight = "[1;34m";
$blue = "[1;36m";
$purple = "\e[35m";
$end = "[0m";
$do = "[1;91m";
$luc = "[1;92m";
$vang = "[1;93m";
$xduong = "[1;94m";
$hong = "[1;95m";
$trang = "[1;97m";
$BBlack = "[1;30m";
$BRed = "[1;31m";
$BGreen = "[1;32m";
$BYellow = "[1;33m";
$BBlue = "[1;34m";
$BPurple = "[1;35m";
$BCyan = "[1;36m";
$BWhite = "[1;37m";
$Blue = "[1;34m";
$res = "[0m";
$end = "[0m";
$red = "[1;31m";
$xanh = "[1;32m";
$cyan = "[1;36m";
$yellow = "[1;33m";
$turquoise = "[1;34m";
$maugi = "[1;35m";
$white = "[1;37m";
$red = "[1;31m";
$redb = "[1;31m";
$green = "[1;32m";
$greenb = "[1;32m";
$yellow = "[1;33m";
$yellowb = "[1;33m";
$syan = "[1;36m";
$blue = "[1;34m";
$blueb = "[1;34m";
$purple = "[1;35m";
$purpleb = "[1;35m";
$lightblue = "[1;36m";
$lightblue = "[1;35m";
$lightblueb = "[1;36m";
$input = array($d2 = "[1;36m", $tmd3 = "[1;37m", $tmd4 = "[1;37m", $tmd5 = "[1;31m", $tmd6 = "[1;31m", $tmd7 = "[1;32m", $tmd8 = "[1;32m", $tmd9 = "[1;33m", $tmd10 = "[1;33m", $tmd11 = "[1;34m", $tmd12 = "[1;34m", $tmd13 = "[1;35m", $tmd14 = "[1;35m", $tmd15 = "[1;36m", $tmd16 = "[1;36m");
$rand_keys = array_rand($input, 10);
$input = array($tmd1 = "[1;46m", $tmd2 = "[1;36m", $tmd3 = "[1;37m", $tmd4 = "[1;37m", $tmd5 = "[1;31m", $tmd6 = "[1;31m", $tmd7 = "[1;32m", $tmd8 = "[1;32m", $tmd9 = "[1;33m", $tmd10 = "[1;33m", $tmd11 = "[1;34m", $tmd12 = "[1;34m", $tmd13 = "[1;35m", $tmd14 = "[1;35m", $tmd15 = "[1;36m", $tmd16 = "[1;36m");
$rand_keys = array_rand($input, 15);
$end = "[0m";
$black = "[1;30m";
$blackb = "[1;30m";
$white = "[1;37m";
$whiteb = "[1;37m";
$red = "[1;31m";
$redb = "[1;31m";
$green = "[1;32m";
$greenb = "[1;32m";
$yellow = "[1;33m";
$yellowb = "[1;33m";
$syan = "[1;36m";
$blue = "[1;34m";
$blueb = "[1;34m";
$purple = "[1;35m";
$purpleb = "[1;35m";
$lightblue = "[1;36m";
$lightblue = "[1;35m";
$lightblueb = "[1;36m";
$input = array($d2 = "[1;36m", $tmd3 = "[1;37m", $tmd4 = "[1;37m", $tmd5 = "[1;31m", $tmd6 = "[1;31m", $tmd7 = "[1;32m", $tmd8 = "[1;32m", $tmd9 = "[1;33m", $tmd10 = "[1;33m", $tmd11 = "[1;34m", $tmd12 = "[1;34m", $tmd13 = "[1;35m", $tmd14 = "[1;35m", $tmd15 = "[1;36m", $tmd16 = "[1;36m");
$rand_keys = array_rand($input, 10);
$input = array($tmd1 = "[1;46m", $tmd2 = "[1;36m", $tmd3 = "[1;37m", $tmd4 = "[1;37m", $tmd5 = "[1;31m", $tmd6 = "[1;31m", $tmd7 = "[1;32m", $tmd8 = "[1;32m", $tmd9 = "[1;33m", $tmd10 = "[1;33m", $tmd11 = "[1;34m", $tmd12 = "[1;34m", $tmd13 = "[1;35m", $tmd14 = "[1;35m", $tmd15 = "[1;36m", $tmd16 = "[1;36m");
$rand_keys = array_rand($input, 15);
@system('clear');
$useragent = "Mozilla/5.0 (Linux; Android 11; Pixel 2 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.185 Mobile Safari/537.36";
$head[] = "Connection: keep-alive";
$head[] = "Keep-Alive: 300";
$head[] = "authority: m.facebook.com";
$head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
$head[] = "cache-control: max-age=0";
$head[] = "upgrade-insecure-requests: 1";
$head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
$head[] = "sec-fetch-site: none";
$head[] = "sec-fetch-mode: navigate";
$head[] = "sec-fetch-user: ?1";
$head[] = "sec-fetch-dest: document";
while (true) {
echo chay(10);
    echo $BGreen."Điền Cookie Acc Cần Thực Hiện : $BWhite";
    $cookie = trim(fgets(STDIN));
    $access = cookie($cookie, $useragent);
    if (explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access) [1]) [0]) {
        $access_token = explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access) [1]) [0];
        $idfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token=' . $access_token))->{'id'};
        break;
    } else {
        exit($BRed . " Cookie Sai
");
    }
}
while (true) {
    unset($so);
    unset($_SESSION['giaay']);
    unset($nhap);
    unset($nguoi);
    unset($so1);
    unset($dem);
    system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO HỦY LIKE PAGE FACEBOOK \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime Nhập Số Page Cần Xóa : $BWhite";
    $nguoi = trim(fgets(STDIN));
    $likepage = xemlikepage($cookie, $access_token, $useragent)->{'data'};
    if (empty($likepage)) {
        echo $BWhite . " Bạn Chưa Like Page Nào Cả 
";
        sleep(1);
    } else {
            echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime Bạn Đang Theo Dõi : $BYellow " . count($likepage) . " Page \n";
echo chay(10);
        foreach ($likepage as $id) {
            $uid = $id->{'id'};
            $name = $id->{'name'};
            bolikepage($cookie, $uid, $useragent);
            $so++;
            echo $BCyan . "[" . $BCyan . $so . $BCyan . "]$BRed ●$BGreen Đã Bỏ Like Page Thành Công $BRed ●$BYellow  " . $name . "
";
            if ($nguoi == $so) {
                break;
            }
        }
    }
    if ($nguoi == $so) {
        unset($so);
        break;
    }

            
function getidunfl($cookie, $idfb, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/timeline/app_collection/?' . http_build_query(array('collection_token' => $idfb . ':2356318349:33', '_rdr' => '')));
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $n = curl_exec($ch);
    $lin = explode('collection', explode('/timeline/app_collection/more/?collection_token', $n) [1]) [0];
    $link = str_replace('&amp;', '&', $lin);
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/timeline/app_collection/more/?collection_token' . $link . 'collection');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $m = curl_exec($ch);
    curl_close($ch);
    $liss = [];
    $n = explode('\">\u003Cspan', explode('href=\"\/', $m) [1]) [0];
    if ($n == '') {
        $bb = '1';
        $liss = '1';
    } else {
        $bb = '2';
    }
    while ($bb == '2') {
        $i++;
        $uid = explode('\">\u003Cspan', explode('href=\"\/', $m) [($i) ]) [0];
        if (strlen($uid) < 100) {
            array_push($liss, $uid);
        }
        if ($uid == '') {
            break;
        }
    }
    return $liss;
}

           function delay($delay) {
                for ($time = $delay;$time > - 1;$time--) {
        echo "\r\033[1;93m   ┗(•°_°•)\033[1;91m ~>       \033[1;92m L      \033[1;91m |\033[1;93m $time\033[1;91m | ";
        usleep(150000);

        echo "\r\033[1;91m   ┗(•°_°•)\033[0;33m   ~>     \033[0;37m LO     \033[0;31m |\033[0;33m $time\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;92m   ┗(•°_°•)\033[0;33m     ~>   \033[0;37m LOA    \033[0;31m |\033[0;33m $time\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;94m   ┗(•°_°•)\033[0;33m       ~> \033[0;37m LOAD   \033[0;31m |\033[0;33m $time\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;95m   ┗(•°_°•)\033[0;33m        ~>\033[0;37m LOAD.  \033[0;31m |\033[0;33m $time\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;95m   ┗(•°_°•)\033[0;33m        ~>\033[0;37m LOAD.. \033[0;31m |\033[0;33m $time\033[0;31m | ";
        usleep(150000);
        echo "\r\033[1;95m   ┗(•°_°•)\033[0;33m        ~>\033[0;37m LOAD...\033[0;31m |\033[0;33m $time\033[0;31m | ";
        usleep(100000);
        echo "\r                                          \r";
                }
            }
            if ($nguoi == $so) {
                break;
            }
        }
function bolikepage($cookie, $id, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/' . $id);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $n = curl_exec($ch);
    $lin = explode('" class="', explode('/a/profile.php?unfan', $n) [1]) [0];
    $link = str_replace('&amp;', '&', $lin);
    curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/a/profile.php?unfan" . $link);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $n = curl_exec($ch);
    curl_close($ch);
    return explode('</title><meta', explode('head><title>', $n) [1]) [0];
}
function xacnhanbanbe($cookie, $id, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/' . $id);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $n = curl_exec($ch);
    $lin = explode('" class="', explode('/a/mobile/friends/profile_add_friend.php?', $n) [1]) [0];
    $link = str_replace('&amp;', '&', $lin);
    curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/a/mobile/friends/profile_add_friend.php?" . $link);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $n = curl_exec($ch);
    curl_close($ch);
    return explode('</title><meta', explode('head><title>', $n) [1]) [0];
}
function xemlikepage($cookie, $access_token, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/me/likes?access_token=' . $access_token . '&limit=5000&fields=name,id');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function addbanbe($cookie, $access_token, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/me/friendrequests?access_token=' . $access_token . '&limit=5000&fields=from.name');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function getbaiviet($cookie, $access_token, $useragent, $idfb) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/' . $idfb . '/posts?limit=1000&fields=id,name&access_token=' . $access_token);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function demlike($cookie, $access_token, $idpost, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/v1.0/' . $idpost . '/likes?access_token=' . $access_token . '&pretty=1&limit=5000');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function getbanbe($access_token, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/me/friends/?access_token=' . $access_token);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    return json_decode(curl_exec($ch));
    curl_close($ch);
}
function xoabanbe($cookie, $id, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/profile.php?id=' . $id);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    $list = curl_exec($ch);
    $data1 = explode('" autocomplete=', explode('name="fb_dtsg" value="', $list) [1]) [0];
    $data2 = explode('" autocomplete=', explode('name="jazoest" value="', $list) [1]) [0];
    $data = http_build_query(array('fb_dtsg' => $data1, 'jazoest' => $data2, 'friend_id' => $id, 'unref' => 'profile_gear', 'confirm' => 'Xác nhận'));
    $head[] = 'content-length: ' . strlen($data);
    $head[] = 'refer: https://mbasic.facebook.com/removefriend.php?friend_id=' . $id . '&unref=profile_gear&refid=17';
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/a/removefriend.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $h = curl_exec($ch);
    curl_close($ch);
}
function cookie($cookie, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $access = curl_exec($ch);
    curl_close($ch);
    return $access;
}
function gettt($cookie, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/home.php');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 9; LGM-V300L) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.185 Mobile Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $n = curl_exec($ch);
    $lin = explode('">Thích</a><span', explode('a/like.php?', $n) [1]) [0];
    $link = str_replace('&amp;', '&', $lin);
    $url = "https://mbasic.facebook.com/a/like.php?" . $link;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ccc = curl_exec($ch);
    return explode('</title><meta', explode('head><title>', $ccc) [1]) [0];
    curl_close($ch);
}
function cmt($cookie, $msg, $id, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/' . $id);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $m = curl_exec($ch);
    $lin = explode('">Viết bình luận...', explode('/a/comment.php?', $m) [1]) [0];
    $link1 = explode('"><input type="', $lin) [0];
    $link = str_replace('&amp;', '&', $link1);
    $data1 = explode('" autocomplete="', explode('name="fb_dtsg" value="', $lin) [1]) [0];
    $data2 = explode('" autocomplete="', explode('name="jazoest" value="', $lin) [1]) [0];
    curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/a/comment.php?" . $link);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $dat = http_build_query(array('fb_dtsg' => $data1, 'jazoest' => $data2, 'comment_text' => $msg));
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $dat);
    $n = curl_exec($ch);
    curl_close($ch);
    return explode('</title><meta', explode('head><title>', $n) [1]) [0];
}
function page($id, $cookie, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/' . $id);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
	:'));
    $page = curl_exec($ch);
    if (explode('&amp;refid=', explode('pageSuggestionsOnLiking=1&amp;gfid=', $page) [1]) [0]) {
        $get = explode('&amp;refid=', explode('pageSuggestionsOnLiking=1&amp;gfid=', $page) [1]) [0];
        $link = 'https://mbasic.facebook.com/a/profile.php?fan&id=' . $id . '&origin=page_profile&pageSuggestionsOnLiking=1&gfid=' . $get . '&refid=17';
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
    }
    curl_close($ch);
}
function camxuc($cookie, $id, $useragent, $type) {
    $ch = curl_init();
    if (strpos($id, '_')) {
        $uid = explode('_', $id, 2);
        $id2 = 'story.php?story_fbid=' . $uid[1] . '&id=' . $uid[0];
    } else {
        $id2 = $id;
    }
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/' . $id2);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
	:'));
    $page = curl_exec($ch);
    if (preg_match('~Location: (.*)~i', $result, $match)) {
        $location = trim($match[1]);
        $link = 'https://mbasic.facebook.com' . explode('facebook.com', $location) [1];
        return array('link' => $link);
    } else {
        if ($id2 != $id && explode('&amp;origin_uri=', explode('amp;ft_id=', $page, 2) [1], 2) [0]) {
            $get = explode('&amp;origin_uri=', explode('amp;ft_id=', $page, 2) [1], 2) [0];
        } else {
            $get = $id2;
        }
        $link = 'https://mbasic.facebook.com/reactions/picker/?is_permalink=1&ft_id=' . $get;
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $cx = curl_exec($ch);
        $HAHA = explode('<a href="', $cx);
        if ($type == 'LOVE') {
            $haha2 = explode('" style="display:block"', $haha[2]) [0];
        } else if ($type == 'WOW ') {
            $haha2 = explode('" style="display:block"', $haha[5]) [0];
        } else if ($type == 'Thả Haha') {
            $haha2 = explode('" style="display:block"', $haha[4]) [0];
        } else if ($type == 'SAD ') {
            $haha2 = explode('" style="display:block"', $haha[6]) [0];
        } else {
            $haha2 = explode('" style="display:block"', $haha[7]) [0];
        }
        $link2 = html_entity_decode($haha2);
        curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com' . $link2);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
        curl_close($ch);
    }
}
function camxuc1($cookie, $link, $useragent, $type) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $link);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $m = curl_exec($ch);
    if ($type == 'LIKE') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=1', $m) [1]) [0];
        $link4 = '&amp;reaction_type=1' . $link2;
    }
    if ($type == 'THUONG') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=16', $m) [1]) [0];
        $link4 = '&amp;reaction_type=16' . $link2;
    }
    if ($type == 'LOVE') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=2', $m) [1]) [0];
        $link4 = '&amp;reaction_type=2' . $link2;
    }
    if ($type == 'WOW') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=3', $m) [1]) [0];
        $link4 = '&amp;reaction_type=3' . $link2;
    }
    if ($type == 'Thả Haha') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=4', $m) [1]) [0];
        $link4 = '&amp;reaction_type=4' . $link2;
    }
    if ($type == 'SAD') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=7', $m) [1]) [0];
        $link4 = '&amp;reaction_type=7' . $link2;
    }
    if ($type == '') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=8') [1]) [0];
        $link4 = '&amp;reaction_type=8' . $link2;
    }
    $link3 = explode('&amp;reaction_type=', explode('<a href="/ufi/reaction/?', $m) [1]) [0];
    $link5 = str_replace('&amp;', '&', $link3 . $link4);
    curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/ufi/reaction/?" . $link5);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $n = curl_exec($ch);
    curl_close($ch);
    return explode('</title><meta', explode('head><title>', $n) [1]) [0];
}
function datnicktds($user, $idfb) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_URL, 'https://traodoisub.com/scr/api_dat.php?user=' . $user . '&idfb=' . $idfb);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Linux; Android 11; Pixel 2 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.127 Mobile Safari/537.36");
    $h = curl_exec($ch);
    return json_decode($h);
}
function nhantientds($loai, $id) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://traodoisub.com/scr/nhantien' . $loai . '.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $tdsxu = array('id' => $id);
    curl_setopt($ch, CURLOPT_POST, count($tdsxu));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $tdsxu);
    curl_setopt($ch, CURLOPT_COOKIEFILE, "TDS.txt");
    $xu = curl_exec($ch);
    curl_close($ch);
    return $xu;
}
function nhantiencxtds($loai, $id) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://traodoisub.com/scr/nhantiencx.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $tdsxu = array('id' => $id, 'loaicx' => $loai);
    curl_setopt($ch, CURLOPT_POST, count($tdsxu));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $tdsxu);
    curl_setopt($ch, CURLOPT_COOKIEFILE, "TDS.txt");
    $xu = curl_exec($ch);
    curl_close($ch);
    return $xu;
}
function getcookietds($user, $pass) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, 'https://traodoisub.com/scr/login.php');
    curl_setopt($ch, CURLOPT_COOKIEJAR, "TDS.txt");
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    $login = array('username' => $user, 'password' => $pass, 'submit' => ' ĐĂNG NHẬP');
    curl_setopt($ch, CURLOPT_POST, count($login));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $login);
    curl_setopt($ch, CURLOPT_COOKIEFILE, "TDS.txt");
    $source = curl_exec($ch);
    curl_close($ch);
    return $source;
}
function getnvtds($loai, $user) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_URL, 'https://traodoisub.com/scr/api_job.php?chucnang=' . $loai . '&user=' . $user);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Linux; Android 11; Pixel 2 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.127 Mobile Safari/537.36");
    $list = curl_exec($ch);
    curl_close($ch);
    return json_decode($list);
}
function followtoken($access_token, $id, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/' . $id . '/subscribers');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function liketoken($access_token, $id, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/' . $id . '/likes');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function cmttoken($access_token, $id, $msg, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/' . $id . '/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('message' => $msg, 'access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function gethome($cookie, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/home.php');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    return curl_exec($ch);
    curl_close($ch);
}
function camxuctuongtac($cookie, $link, $useragent, $type) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $link);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $m = curl_exec($ch);
    if ($type == 'LIKE') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=1', $m) [1]) [0];
        $link4 = '&amp;reaction_type=1' . $link2;
    }
    if ($type == 'THUONG') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=16', $m) [1]) [0];
        $link4 = '&amp;reaction_type=16' . $link2;
    }
    if ($type == 'LOVE') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=2', $m) [1]) [0];
        $link4 = '&amp;reaction_type=2' . $link2;
    }
    if ($type == 'WOW') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=3', $m) [1]) [0];
        $link4 = '&amp;reaction_type=3' . $link2;
    }
    if ($type == 'HAHA') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=4', $m) [1]) [0];
        $link4 = '&amp;reaction_type=4' . $link2;
    }
    if ($type == 'SAD') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=7', $m) [1]) [0];
        $link4 = '&amp;reaction_type=7' . $link2;
    }
    if ($type == '') {
        $link2 = explode('" style="display:block"', explode('&amp;reaction_type=8') [1]) [0];
        $link4 = '&amp;reaction_type=8' . $link2;
    }
    $link3 = explode('&amp;reaction_type=', explode('<a href="/ufi/reaction/?', $m) [1]) [0];
    $link5 = str_replace('&amp;', '&', $link3 . $link4);
    curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/ufi/reaction/?" . $link5);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $n = curl_exec($ch);
    curl_close($ch);
    return explode('</title><meta', explode('head><title>', $n) [1]) [0];
}
function gettiephome($cookie, $linktiep, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linktiep);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    return curl_exec($ch);
    curl_close($ch);
}
function thembanbe($cookie, $url, $useragent) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/friends/center/mbasic/?fb_ref=tn&sr=1&ref_component=mbasic_home_header&ref_page=MFriendsCenterMBasicController');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    $list = curl_exec($ch);
    $link = explode('" class="', explode('/a/mobile/friends/add_friend.php?', $list) [1]) [0];
    $link2 = 'https://mbasic.facebook.com/a/mobile/friends/add_friend.php?' . str_replace('&amp;', '&', $link);
    curl_setopt($ch, CURLOPT_URL, $link2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);
    curl_close($ch);
    return explode('&hf', explode('id=', $link2) [1]) [0];
} 
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}