@system('clear');
error_reporting(0);
date_default_timezone_set('Asia/Ho_Chi_Minh');
if (!file_exists("soluong_very.txt"))
{
    firet();
    luong();
} else {
    $mang = [];
    $count = preg_split('/\r\n|[\r\n]/', file_get_contents("soluong_very.txt"));
    foreach ($count as $list)
    {
        if ($list == true)
        {
            $mang[] = $list;
        }
    }
    print ("\033[1;92m Có " . count($mang) . " đã được cấu hình từ trước, bạn có muốn sử dụng lại không? ( y / n ): ");
    $hoi = trim(fgets(STDIN));
    if($hoi == "n") {
        luong();
    }
}

$mang = [];
$count = preg_split('/\r\n|[\r\n]/', file_get_contents("soluong_very.txt"));
foreach ($count as $list)
{
    if ($list == true)
    {
        $mang[] = $list;
    }
}

$time = 900 / count($mang);
print ("\033[1;92m Thời gian chờ mặc định:\033[1;95m $time\n");
print ("\033[1;92m Nhập id post:\033[1;95m ");
$idpost = trim(fgets(STDIN));
print ("\033[1;92m Nhập LIKE để tăng Like\n");
print ("\033[1;92m Nhập HAHA để tăng Haahaa\n");
print ("\033[1;92m Nhập LOVE để tăng Yêu thích\n");
print ("\033[1;92m Nhập WOW để tăng bất ngờ\n");
print ("\033[1;92m Nhập SAD để tăng buồn\n");
print ("\033[1;92m Nhập ANGRY để tăng tức giận\n");
echo "[1;37m NHẬP REACTION : [1;31m";
//print ("\033[1;92m Nhập:\033[1;95m ");
$type = trim(fgets(STDIN));
while (true)
{
    foreach ($mang as $l)
    {
        $ex = explode("|", $l);
        $useragent = $ex[0];
        $name_cookie = $ex[1];

        for ($v = 0;$v <= 25;$v++)
        {
            print ("\033[1;37m- ");
        }
        print ("\n");
        print ("\033[1;92mAcc đang sử dụng:" . $ex[2] . "\n");
//\033[1;95m $name_cookie | 
        $send_1 = send_1($name_cookie, $useragent, $idpost, $type);
        if ($send_1 == "404")
        {
            $mang = array_diff($mang, [$l]);
            print ("\033[1;92m Acc $ex[2] cookie đã hết hạn hoạc chưa đủ thời gian chờ!\n");
            $time = 900 / count($mang);
            print ("\033[1;92m Thời gian làm mới:\033[1;95m $time\n");
        }
        else
        {
            $send_2 = send_2($name_cookie, $useragent, $send_1);
            if (strpos($send_2, "Likes/Reaction Delivered") == true)
            {
$so++;
                print ("\033[0;36m [$so]\033[1;5m [" . date("h:i:s") . "]\033[1;92m Tăng thành công cho id $idpost\n");
                for ($v = round($time);$v > 0;$v--)
                {
                    print ("\r\033[1;93m Đợi $v giây!\r");
                    sleep(1);
                }
            }
            else
            {
                print ("\r\033[1;92m Không thành công!\r");
            }
        }
    }
}

function luong()
{
    print ("\033[1;92m Nhập số Facebook cần chạy:\033[1;95m ");
    $soluong = trim(fgets(STDIN));
    if (!file_exists("soluong_very.txt"))
    {
        system('rm -r soluong_very.txt');
    }
    else
    {
        print ("\033[1;92m Bạn muốn tiếp tục thêm mới hay xoá tất cả?  (y/n): ");
        $hoi_cau = trim(fgets(STDIN));
        if ($hoi_cau == "n")
        {
            system('rm -r soluong_very.txt');
        }
    }
    for ($v = 1;$v <= $soluong;$v++)
    {
        $ran = mt_rand(111, 999) . $v;

        $useragent_random = random_useragent();
        $link = json_decode(getlink($ran, $useragent_random) , true);
        $link_code = $link["verification_url"] . "?user_code=" . $link["user_code"];
        echo "\rĐang lấy Useragent tự động...\r";
        print ("\033[1;92m Useragent $v :$useragent_random\n");
        print ("\033[1;92m Facebook $v\n");
        print ("\033[1;92m Link xác minh :\033[1;95m $link_code\n");
        print ("\033[1;92m Có muốn tự mở link không (y/n): ");
        $cauhoi = trim(fgets(STDIN));
        if ($cauhoi == 'y')
        {
            system("xdg-open $link_code");
        }
        print ("\033[1;92m Ấn Enter nếu đã xác nhận: ");
        $enter_if_very = trim(fgets(STDIN));
        $link = very($ran, $useragent_random);
        $json_very = json_decode($link, true);
        $status = $json_very["logged_in"];
        if ($status == "yes")
        {
            print ("\033[1;92m Xác nhận thành công Facebook $v:\033[1;95m " . $json_very["name"] . "\n");
            $open = fopen("soluong_very.txt", "a+");
            fwrite($open, "$useragent_random|cookie_$ran.txt|" . $json_very["name"] . "\n");
        }
        else
        {
            print ("\033[1;95m Xác nhận lỗi!\n");
        }

    }
    print ("\033[1;92m Ok, chạy thôi\n");
}
function getlink($name_cookie, $useragent)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://fbliker.net/do_login.php");
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, "$useragent");
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie_$name_cookie.txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie_$name_cookie.txt");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Expect:'
    ));
    $access = curl_exec($ch);
    curl_close($ch);
    return $access;
}
function very($name_cookie, $useragent)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://fbliker.net/do_login2.php");
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, "$useragent");
    curl_setopt($ch, CURLOPT_ENCODING, '');

    curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie_$name_cookie.txt");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Expect:'
    ));
    $access = curl_exec($ch);
    curl_close($ch);
    return $access;
}
function send_1($name_cookie, $useragent, $id, $type)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://fbliker.net/autolike.php?type=custom");
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, "$useragent");
    curl_setopt($ch, CURLOPT_ENCODING, '');

    curl_setopt($ch, CURLOPT_COOKIEFILE, "$name_cookie");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Expect:'
    ));
    $access = curl_exec($ch);
    curl_close($ch);
    if (strpos($access, '<form action="" method="post" onsubmit="ShowLoading()">') == true)
    {
        $ex = explode('<form action="" method="post" onsubmit="ShowLoading()">', $access) [1];
        $send_id = explode('"', explode('type="text" class="form-control" name="', $ex) [1]) [0];
        $hidden = explode('"', explode('name="', explode('type="hidden"', $ex) [1]) [1]) [0];
        $value = explode('"', explode('value="', explode('type="hidden"', $ex) [1]) [1]) [0];
        $submit = explode('"', explode('name="', explode('type="submit"', $ex) [1]) [1]) [0];
        $submit_v = explode('"', explode('value="', explode('type="submit"', $ex) [1]) [1]) [0];
        $ghep = $send_id . "=" . $id . "&" . "type=$type&" . "&" . $hidden . "=$value" . "&$submit=$submit_v";
    }
    else
    {
        $ghep = "404";
    }
    return $ghep;
}
function send_2($name_cookie, $useragent, $data)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://fbliker.net/autolike.php?type=custom");
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, "$useragent");
    curl_setopt($ch, CURLOPT_ENCODING, '');

    curl_setopt($ch, CURLOPT_COOKIEFILE, "$name_cookie");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Expect:'
    ));
    $access = curl_exec($ch);
    curl_close($ch);
    return $access;
}
function random_useragent()
{
    $connect = file_get_contents("https://user-agents.net/random");
    $ex = explode('">', explode('</a></li>', explode('<li><a href="/string/', $connect) [1]) [0]) [0];
    return $ex;
}

function firet()
{
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO HACK LIKE FACEBOOK ĐA LUỒNG \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Donate Để Có Động Lực Viết Tool\n";
    usleep(100000);
echo chay(10);
//chay(14);
echo "$BGreen" . "● THÔNG BÁO\n";
echo $BWhite . $tb . " \n\n";
echo "$BGreen" . "● LƯU Ý\n";
echo "$BPurple" . ">> [" . "$do" . "+" . "$BPurple" . "] " . "$BWhite";
$a0 = "Nếu không hoạt động, hãy chạy lại file.\n";
$len = strlen($a0);
for ($x = 0;$x < $len;$x++)
{
    echo $a0[$x];
    usleep(5535);
}
echo "$BPurple" . ">> [" . "$do" . "+" . "$BPurple" . "] " . "$BWhite";

$a3 = "Nếu không lên like, hãy lấy lại cookie...\n\n";

$len = strlen($a3);
for ($x = 0;$x < $len;$x++)
{
    echo $a3[$x];
    usleep(55);
}
echo "$BGreen" . "● Cấu Hình\n";
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}