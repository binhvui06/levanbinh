error_reporting(0);
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$res="\033[0m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$green="\033[1;32m";
$blue="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$lime="\033[1;37m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$orange= "\033[1;29m";
$do="\033[1;31m";
$xl="\033[1;32m";
$vang="\033[1;33m";
$xn="\033[1;34m";
$res="\033[1;35m";
$nau="\033[1;36m";
$trang="\033[1;97m";
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen TOOL AUTO APP YOUTUBE \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen APP TUBVIEW \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen APP UTVIEWS \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m3\033[1;31m]$BGreen APP CHANNELSUB \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m4\033[1;31m]$BGreen WEBSITE HOATUBE.COM \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m5\033[1;31m]$BGreen APP FAST SUB4SUB \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m6\033[1;31m]$BGreen APP TUBE ROCKET \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m7\033[1;31m]$BGreen VIEWTUB BOOST \n";
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Vui Lòng Nhập Chế Độ : ";
$chon = trim(fgets(STDIN));
echo chay(10);
////// TUBVIEW
if ($chon == '1'){
echo $BGreen."Nhập ID : $white ";
$uid = trim(fgets(STDIN));
echo $BGreen."Nhập Token : $white ";
$token = trim(fgets(STDIN));
@system('clear');
echo chay(18);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen TOOL AUTO APP TUBVIEW \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(18);
function truycap($host,$tsm,$data) {
$url = $host;
$mr = curl_init();
curl_setopt_array($mr, array(
 CURLOPT_PORT => "443",
 CURLOPT_URL => "$url",
 CURLOPT_ENCODING => "",
 CURLOPT_RETURNTRANSFER => true,
 CURLOPT_SSL_VERIFYPEER => false,
 CURLOPT_TIMEOUT => 30,
 CURLOPT_CUSTOMREQUEST => "POST",
 CURLOPT_POSTFIELDS => $data,
 CURLOPT_HTTPHEADER => $tsm));

$mr2 = curl_exec($mr);curl_close($mr);
$json = json_decode($mr2,true);
return $json;
}

$tsm = array(
"Host:www.tubview.net",
"Content-Type:application/x-www-form-urlencoded"
);
while(true){

$host_video = "https://www.tubview.net/earn";
$data_video = "user_id=".$uid."&token=".$token."";
$tc_video   = truycap($host_video,$tsm,$data_video);
//////

$id   = $tc_video['video_id'];
$cid  = $tc_video['cid'];
$time = $tc_video['second'];
$coin = $tc_video['reward'];

if($id >= "0"){

for ($time=$time;$time>-1;$time--){
echo $BPurple."[ > Đang xem video < ][$time] Giây \r";
sleep(1);
}

///////////// nhan thuong
$host_nhan = "https://www.tubview.net/earn";
$data_nhan = "user_id=".$uid."&token=".$token."&cid=".$cid."&language=vi";
$tc_nhan   = truycap($host_nhan,$tsm,$data_nhan);


$xutong = $tc_nhan['coin'];
$ketqua = $tc_nhan['toast'];
$so++;
echo $BCyan."[$so] $BRed 🍭$BGreen Thành Công + : $ketqua $BRed 🍭$BGreen Tổng Xu : $BYellow $xutong XU \n";

}else{echo $BPurple."Đang tìm nhiệm vụ... \r";}}}
////// UTVIEWS
if ($chon == '2'){
echo $green."Nhập uid : ";
$uid = trim(fgets(STDIN));
echo $green."Nhập Token : ";
$token = trim(fgets(STDIN));
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen TOOL AUTO APP UTVIEWS \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(18);
$hien = array(
"Content-Type:application/x-www-form-urlencoded",
"Host:utviews.com"
);
///////////////////// lay video id
while(true){
$mr = curl_init();
curl_setopt_array($mr, array(
  CURLOPT_PORT => "443",
  CURLOPT_URL => "https://utviews.com/earn",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POSTFIELDS => "user_id=".$uid."&token=".$token."&version=20",
  CURLOPT_HTTPHEADER => $hien));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);

$coin = $json['coin'];
$time = $json['second'];
$id   = $json['video_id'];
$cid  = $json['cid'];
$nhan = $json['reward'];
$so = $so +1;
if($id >= "0"){
echo $nau."[$so] $BPurple ID : $id $red 🍭 \n";
for ($time=$time;$time>-1;$time--){
echo $kuing."Vui lòng chờ  $green $time \r";
sleep(1);
}
///////////////////// nhan tien
$mr = curl_init();
curl_setopt_array($mr, array(
  CURLOPT_PORT => "443",
  CURLOPT_URL => "https://utviews.com/earn",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POSTFIELDS => "user_id=".$uid."&token=".$token."&cid=".$cid."&version=20",
  CURLOPT_HTTPHEADER => $hien));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);
$poin = $json['coin'];
echo $trang."$green Thành Công + $nhan $red 🍭 $green Tổng Xu : $yellow$poin \n";}}
}
////// ChannelSub
if ($chon == '3'){
echo $BGreen."Nhập UserId : $BWhite";
$idnick =trim(fgets(STDIN));
echo $BGreen."Nhập Token : $BWhite";
$token =trim(fgets(STDIN));
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen TOOL AUTO APP ChannelSub \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
while(true){ 
// Get id video
$url = "https://channelsub.com/earn";

$data = 'userId='.$idnick.'&token='.$token.'&type=3&channelId=';

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => $data,
CURLOPT_HTTPHEADER => array(
"language:vi",
"version:15",
"user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36",
"Content-Type:application/x-www-form-urlencoded",
"Content-Length:103",
"Host:channelsub.com",
"Connection:Keep-Alive",
"Accept-Encoding:gzip",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);

$video_id = $json['video_id'];
$cid = $json['cid'];
$time = $json['second'];
$reward = $json['reward'];
$so++;
echo $BCyan."[$so]$BRed 🍭$BGreen ID $BRed 🍭$BGreen $video_id \n";
for ($time=$time;$time>-1;$time--){
echo $BPurple."Đang xem video $green $time giây   \r";
sleep(1);
}
// nhận tiền
$url = "https://channelsub.com/earn";

$data = 'userId='.$idnick.'&token='.$token.'&type=3&channelId=&cid='.$cid.'&viewed=1&like=2&sub=0';

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => $data,
CURLOPT_HTTPHEADER => array(
"language:vi",
"version:15",
"user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36",
"Content-Type:application/x-www-form-urlencoded",
"Content-Length:163",
"Host:channelsub.com",
"Connection:Keep-Alive",
"Accept-Encoding:gzip",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);
$nt = $json['coin'];
$toast = $json['toast'];
echo "\033[1;35m[\033[1;32mSUCCESS\033[1;35m]$BRed 🍭$BGreen + $reward $BRed 🍭$BYellow $nt \n";
}
if($video_id == ""){
exit("$BRed Vui Lòng Chạy Lại Tool Để Tiếp Tục\n");
}
}
////// HOATUBE
if ($chon == '4'){
echo $BGreen."Nhập Cookie : $BWhite ";
$cookie = trim(fgets(STDIN));
$useragent ="Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.30 Mobile Safari/537.36";
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen TOOL AUTO WEBSITE HOATUBE.COM \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
// Get id video
while(true){ 
$url = "https://hoatube.com/index.php?page=module&md=youtube";

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_HTTPHEADER => array(
"Host:hoatube.com",
"upgrade-insecure-requests:1",
"user-agent:$useragent",
"referer:https://hoatube.com/index.php",
"cookie:$cookie",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);


$hoa = explode('<b id="c_coins" class="text-warning">', $mr2)[1];
$hoa = explode('<', $hoa)[0];

$id = explode('<div class="website_block" id="', $mr2)[1];
$id = explode('"', $id)[0];

$so++;
echo $BCyan."[$so] $BRed 🍭$BGreen ID $BRed 🍭$BPurple $id \n";

// Bắt đầu làm nhiệm vụ
$url = "https://hoatube.com/index.php?page=module&md=youtube&vid=".$id."";

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_HTTPHEADER => array(
"Host:hoatube.com",
"upgrade-insecure-requests:1",
"user-agent:$useragent",
"referer:https://hoatube.com/index.php?page=module&md=youtube",
"cookie:$cookie",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);

$time = explode('var length = ', $mr2)[1];
$time = explode(';', $time)[0];


for ($time=$time;$time>-1;$time--){
echo $BPurple."Đang xem video $BGreen $time  giây  \r";
sleep(1);
}

// nhan tien
$url = "https://hoatube.com/system/modules/youtube/process.php";

$data = 'data='.$id.'';

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => $data,
CURLOPT_HTTPHEADER => array(
"Host:hoatube.com",
"user-agent:$useragent",
"x-requested-with:XMLHttpRequest",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://hoatube.com",
"referer:https://hoatube.com/index.php?page=module&md=youtube&vid=".$id."",
"cookie:$cookie",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);

if($mr2 == "9"){
echo $BGreen."\033[1;31m[\033[1;32mSUCCESS\033[1;31m] $BRed 🍭$BGreen + 9 Hoa $BRed 🍭$BGreen Tổng Hoa $BRed 🍭$BGreen $BYellow $hoa \n";
}}}
if ($chon == '5'){
echo $res."Nhập Uid: ";
$uid=trim(fgets(STDIN));
echo $xl."Nhập Apikey: ";
$api=trim(fgets(STDIN));
echo $nau."Nhập Delay (Nên Nhập 30 < x < 80): ";
$g=trim(fgets(STDIN));
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen TOOL AUTO Fast Sub4Sub \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
while(true){
 $url = "http://fastfollowers.online/get_user.php";
$data = "uid=$uid";
$mr = curl_init();
curl_setopt_array($mr, array(
    CURLOPT_PORT => "80",
    CURLOPT_URL => "$url",
    CURLOPT_ENCODING => "",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => array(
"host:fastfollowers.online",
"apikey:$api",
"Mozilla/5.0 (Linux; Android 10; Active 3 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36",
"content-type:application/x-www-form-urlencoded; charset=utf-8",
"32",
"gzip",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);

$cr=$json['user']['credit'];



$url = "http://fastfollowers.online/get_random_campaign_v1.php";
$data = "createdUID=$uid";
$mr = curl_init();
curl_setopt_array($mr, array(
    CURLOPT_PORT => "80",
    CURLOPT_URL => "$url",
    CURLOPT_ENCODING => "",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => array(
"host:fastfollowers.online",
"apikey:$api",
"Mozilla/5.0 (Linux; Android 10; Active 3 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36",
"content-type:application/x-www-form-urlencoded; charset=utf-8",
"39",
"gzip",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);

$id=$json['campaign']['0']['id'];
$cs=$json['campaign']['0']['campaignId'];
$tg=$json['campaign']['0']['videoWatchTime'];
if ($cs=="") {
  echo $do."Vui lòng lấy lại Uid và Apikey\n";
  exit();
}
echo "{$trang}Video Id: {$nau}»{$vang}$id{$nau}« {$res}| {$trang}Có: {$nau}»{$vang}$cr{$nau}« {$trang}Xu\n";
for ($i = 0; $i < $g; $i++ ) {
echo $trang, "Đang xem: [{$res}{$i}{$trang}] Giây \r";
    sleep(1);
}

$url="http://fastfollowers.online/update_credit_v1.php";
$data="campaignId=$cs&uid=$uid&credit=112";
$mr = curl_init();
curl_setopt_array($mr, array(
    CURLOPT_PORT => "80",
    CURLOPT_URL => "$url",
    CURLOPT_ENCODING => "",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => array(
"host:fastfollowers.online",
"apikey:$api",
"Mozilla/5.0 (Linux; Android 10; Active 3 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36",
"content-type:application/x-www-form-urlencoded; charset=utf-8",
"61",
"gzip",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);
$t=$json['responseMessage'];


echo "{$res}<==> {$trang}$t \n";
}
}
if ($chon == '6'){
echo $BGreen."Nhập Token : $BWhite";
$token =trim(fgets(STDIN));
@system('clear');
function GET($host,$tsm)
{
  $mr = curl_init();
  curl_setopt_array($mr, array(
  CURLOPT_URL => $host,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => $tsm));
  $mr2 = curl_exec($mr); curl_close($mr);
  $json = json_decode($mr2,true);
  return $json;
}
function POST($host,$tsm1,$data)
{
  $mr = curl_init();
  curl_setopt_array($mr, array(
  CURLOPT_URL => $host,
  CURLOPT_PORT => "3000",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_CUSTOMREQUEST => "PUT",
  CURLOPT_POSTFIELDS => $data,
  CURLOPT_HTTPHEADER => $tsm1));
  $mr2 = curl_exec($mr); curl_close($mr);
  $json = json_decode($mr2,true);
  return $json;
}
$tsm = array(
"Host:mutupipe.westus2.cloudapp.azure.com:3000",
"Connection:Keep-Alive",
"token:$token",
);
$tsm1 = array(
"Host:mutupipe.westus2.cloudapp.azure.com:3000",
"Connection:Keep-Alive",
"token:$token",
"Content-Length:71",
"User-Agent:okhttp/3.12.0",
"Content-Type:application/json; charset=UTF-8",
);
//////
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen TOOL AUTO APP Tube Rocket \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
$tc_a = get("http://mutupipe.westus2.cloudapp.azure.com:3000/api/member",$tsm);
$xu = $tc_a['result']['coin'];
if($xu==""){
	echo "{$do}Token Die \n";exit();}
///////
while(true){
$tc_b = get("http://mutupipe.westus2.cloudapp.azure.com:3000/api/video",$tsm);
$id = $tc_b['result']['videoId'];
if($id==""){
	echo "Token Die \n";exit();}
$time = $tc_b['result']['playSecond'];
///echo "$id \n";
for($i = $time;$i>-1;$i--){
        echo "{$xl}Đang xem video {$do}$i  {$xl}➣         \r";
        usleep(200000);
        echo "                         \r";
        echo "{$vang}Đang xem video {$xl}$i    {$do}➣       \r";
        usleep(200000);
        echo "                         \r";
        echo "{$xn}Đang xem video {$res}$i      {$vang}➣      \r";
        usleep(200000);
        echo "                         \r";
        echo "{$do}Đang xem video {$vang}$i        {$xn}➣    \r";
        usleep(200000);
        echo "                         \r";
        echo "{$nau}Đang xem video {$xn}$i          {$res}➣  \r";
        usleep(200000);
        echo "                                                  \r";
        }
        
//////
$data_c = '{"id":"'.$id.'","playCount":0,"playSecond":0,"boost":0,"status":""}';
$tc_c = post("http://mutupipe.westus2.cloudapp.azure.com:3000/api/video",$tsm1,$data_c);
$xu1 = $tc_c['result']['coin'];
$so++;
echo $BCyan."[$so]$BRed 🍭$BGreen $id $BRed 🍭$BYellow $xu1 \n";
}
}
if ($chon == '7'){
error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";

echo $BGreen."Nhập Autho : $BWhite";
$autho =trim(fgets(STDIN));
echo $BGreen."Nhập Secure : $BWhite";
$secu =trim(fgets(STDIN));
echo $BGreen."Nhập User ID : $BWhite";
$user =trim(fgets(STDIN));
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO ViewTubBoost \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
while(true){ 
// get id
$header = array( 
"Authorization:".$autho."",
"Secure:".$secu."",
"Content-Type:application/x-www-form-urlencoded",
"Host:promptdating.co",
"User-Agent:okhttp/4.8.1",
);
$data = 'user_id='.$user.'&start=0';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://promptdating.co/view4view/j1a1/campaign/getViewCampaignList');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

$id = explode('campaign_id":"', $mr2)[1];
$id = explode('"', $id)[0];

$idvd = explode('campaign_url":"', $mr2)[1];
$idvd = explode('"', $idvd)[0];
$so++;
echo $BCyan."[$so]$BRed ★$BGreen ID $BRed ★$BGreen $idvd \n";
delay(61);
// nhận tiền
$header = array( 
"Authorization:".$autho."",
"Secure:".$secu."",
"Content-Type:application/x-www-form-urlencoded",
"Host:promptdating.co",
"User-Agent:okhttp/4.8.1",
);
$data = 'user_id='.$user.'&campaign_type=2&campaign_id='.$id.'&campaign_url='.$idvd.'';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://promptdating.co/view4view/j1a1/campaign/task_completed');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

$nhan = explode('total_coin":"', $mr2)[1];
$nhan = explode('"', $nhan)[0];

echo $BGreen." Thành Công + 10 $BRed ★$BYellow $nhan \n";
} // vòng lặp while
}
function delay ($delay){
	for($tt = $delay ;$tt>= 1;$tt--){
        echo "\r\033[1;33m  LVB \033[1;31m ~>       \033[1;32m LO      \033[1;31m | $tt | "; usleep(150000);
        echo "\r\033[1;31m  LVB \033[0;33m   ~>     \033[0;37m LOA     \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;32m  LVB \033[0;33m     ~>   \033[0;37m LOAD    \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;34m  LVB \033[0;33m       ~> \033[0;37m LOADI   \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m  LVB \033[0;33m        ~>\033[0;37m LOADIN  \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m  LVB \033[0;33m        ~>\033[0;37m LOADING \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m  LVB \033[0;33m        ~>\033[0;37m LOADING.\033[0;31m | $tt | ";usleep(150000);} 
echo "\r\e[1;95m    ⚡LÊ VĂN BÌNH⚡                       \r"; 
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}