error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
$useragent ="Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36";
@system('clear');
echo chay(10);
echo $BGreen."Nhập Tài Khoản : $BWhite";
$tk =trim(fgets(STDIN));
echo $BGreen."Nhập Mật Khẩu : $BWhite";
$mk =trim(fgets(STDIN));
echo $BGreen."Cookie Facebook : $BWhite";
$cookie =trim(fgets(STDIN));
// login
$mr = curl_init();
$login = 'user='.$tk.'&password='.$mk.'&remember=on&connect=';
curl_setopt($mr, CURLOPT_URL, 'http://ezylike.com/?page=register');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEJAR, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $login);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr);
curl_close($mr);
// home
$url ="http://ezylike.com/index.php";
$mr2 = home($url);
$name = explode('<div class="title"><img src="//www.gravatar.com/avatar/488da95fde6db91e7d29ec8b673a0de3?s=40" class="border border-white rounded" /> ', $mr2)[1];
$name = explode('<', $name)[0];

$xu = explode('<span class="text-warning"><b>', $mr2)[1];
$xu = explode('<', $xu)[0];

@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO EZYLIKE.COM\n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Tài Khoản Của Bạn Là: ".$BWhite.$name."\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Số Xu Hiện Tại Của Bạn Là: ".$BWhite.$xu."\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen XEM VIDEO \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen PAGE\n";
echo $BGreen." Ví dụ bạn muốn làm xem video + page thì điền 1+2 ";sleep(3); echo "\r"."                                                           "."\r";
echo chay(10);
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime  Vui Lòng Nhập chế độ : $BWhite";
$chon_1 =trim(fgets(STDIN));
$chon = "số $chon_1";
echo chay(10);
while(true){ 
if(strpos($chon, '1') != false){
// làm job
$header = array( 
"Host:ezylike.com",
"Upgrade-Insecure-Requests:1",
"User-Agent:$useragent",
"Referer:http://ezylike.com/index.php",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'http://ezylike.com/index.php?page=module&md=youtube');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

$id = explode('<div class="website_block" id="', $mr2)[1];
$id = explode('"', $id)[0];

$so++;
echo $BCyan."[$so]$BRed ★$BGreen ID : $id \n";
// xem video
$header = array( 
"Host:ezylike.com",
"Upgrade-Insecure-Requests:1",
"User-Agent:$useragent",
"Referer:http://ezylike.com/index.php?page=module&md=youtube",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'http://ezylike.com/index.php?page=module&md=youtube&vid='.$id.'');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

$time = explode('var length =', $mr2)[1];
$time = explode(';', $time)[0];

for ($time=$time;$time>-1;$time--){
echo $BPurple."Vui lòng chờ $BGreen  $time       \r";
sleep(1); echo "\r                                         \r";
}
// xu
$url ="http://ezylike.com/index.php";
$mr2 = home($url);

$xu = explode('<span class="text-warning"><b>', $mr2)[1];
$xu = explode('<', $xu)[0];
// nhận tiền
$header = array( 
"Host:ezylike.com",
"X-Requested-With:XMLHttpRequest",
"User-Agent:$useragent",
"Content-Type:application/x-www-form-urlencoded; charset=UTF-8",
"Origin:http://ezylike.com",
"Referer:http://ezylike.com/index.php?page=module&md=youtube&vid=".$id."",
);
$data = 'data='.$id.'';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'http://ezylike.com/system/modules/youtube/process.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
echo $BGreen."[VIDEO]$BRed ★$BYellow $xu \n";
if($id == ""){
exit("$BRed Hết Video \n");
}
}
if(strpos($chon, '2') != false){
// get job page
$header = array( 
"Host:ezylike.com",
"Upgrade-Insecure-Requests:1",
"User-Agent:$useragent",
"Referer:http://ezylike.com/",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'http://ezylike.com/?page=module&md=facebook');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

$idpage = explode('<div class="website_block" id="', $mr2)[1];
$idpage = explode('"', $idpage)[0];

$urlpage = explode('<img src="https://graph.facebook.com/', $mr2)[1];
$urlpage = explode('/', $urlpage)[0];

$so++;
echo $BCyan."[$so]$BRed ★$BGreen ID : $idpage $BRed ★$BGreen URL ID : $urlpage \n";
// làm job
$header = array( 
"Host:ezylike.com",
"Accept:application/json, text/javascript, */*; q=0.01",
"X-Requested-With:XMLHttpRequest",
"User-Agent:$useragent",
"Content-Type:application/x-www-form-urlencoded; charset=UTF-8",
"Origin:http://ezylike.com",
"Referer:http://ezylike.com/?page=module&md=facebook",
);
$data = 'get=1&url=https%3A%2F%2Fhref.li%2F%3Fhttps%3A%2F%2Fwww.facebook.com%2F'.$urlpage.'%2F&pid='.$idpage.'';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'http://ezylike.com/system/modules/facebook/process.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

// fb
$url = "https://mbasic.facebook.com/".$urlpage;
        $head = array (
        "Host: mbasic.facebook.com",
        "upgrade-insecure-requests: 1",
        "save-data: on",
        "user-agent: Mozilla/5.0 (Linux; Android 5.1.1; SM-J320G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*"."/"."*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site: same-origin",
        "sec-fetch-mode: navigate",
        "sec-fetch-user: ?1",
        "sec-fetch-dest: document",
        "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
        "cookie: $cookie",
        );
        $ch = curl_init();
        curl_setopt_array ($ch, array (
        CURLOPT_URL => $url,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_HTTPGET => true,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_HEADER => true,
        CURLOPT_ENCODING => TRUE));
        $data = curl_exec($ch);
        if (strpos($data,"xs=deleted") == true){

        } else {
        $one = explode("location: ",$data);
        $two = explode("rdr",$one[1]);

        $url = $two[0]."rdr";
        curl_setopt_array ($ch, array (
        CURLOPT_URL => $url,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_HTTPGET => true,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_HEADER => true,
        CURLOPT_ENCODING => TRUE));
        $data = curl_exec($ch);
        $one = explode("/a/profile.php?",$data);
        $two = explode('"',$one[1]);


        $url = "https://mbasic.facebook.com/a/profile.php?".htmlspecialchars_decode($two[0]);
        curl_setopt_array ($ch, array (
        CURLOPT_URL => $url,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_HTTPGET => true,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_HEADER => true,
        CURLOPT_ENCODING => TRUE));
        $data = curl_exec($ch);
        }
// xu
$url ="http://ezylike.com/index.php";
$mr2 = home($url);

$xu = explode('<span class="text-warning"><b>', $mr2)[1];
$xu = explode('<', $xu)[0];
// nhận tiền
$header = array( 
"Host:ezylike.com",
"Accept:application/json, text/javascript, */*; q=0.01",
"X-Requested-With:XMLHttpRequest",
"User-Agent:$useragent",
"Content-Type:application/x-www-form-urlencoded; charset=UTF-8",
"Origin:http://ezylike.com",
"Referer:http://ezylike.com/?page=module&md=facebook",
);
$data = 'type=1&id='.$idpage.'';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'http://ezylike.com/system/modules/facebook/process.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
echo $BGreen."[PAGE]$BRed ★$BYellow $xu \n";
}
} // vòng lặp while
function home($url){
$header = array( 
"Host:ezylike.com",
"Upgrade-Insecure-Requests:1",
"User-Agent:$useragent",
"Referer:http://ezylike.com/?page=register",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, $url);
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
return $mr2;
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}
