error_reporting(0);
session_start();
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$resss = "\033[0m";
$res = "\033[0;33m";
$red = "\033[0;31m";
$green = "\033[0;37m";
$yellow = "\033[0;33m";
$white = "\033[0;33m";
$xnhac = "\033[1;96m";
$maufulldo= "\e[1;47;31m";
$den = "\033[1;90m";
$do = "\033[1;91m";
$luc = "\033[1;92m";
$vang = "\033[1;93m";
$xduong = "\033[1;94m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
$kongdz = $do."[".$luc."🍬".$do."] ".$trang."=> ";
$kongvip = $do."[".$luc."🍬".$do."]";
$thanhngang = $vang."----------------------------------------------------------\n";
date_default_timezone_set("Asia/Ho_Chi_Minh");
system('clear');
while (true){
echo chay(10);
$dem = 0;
echo $kongdz."".$luc."Vào Web ".$trang."Traodoisub.com".$luc." Bấm Cài Đặt Trên Web\n";
echo $kongdz."".$luc."Sao Chép ".$vang."Access_token".$luc." Dán Vào\n";
  echo $kongdz."".$luc."Nhập Access_token: $vang";
  $tokenacc = trim(fgets(STDIN));
  echo chay(10);
//Token 
$khoToken = [];
$list_id = [];
$list_name = [];
if (file_exists('Token.txt')){
    echo $kongdz."".$luc."Nhập ".$vang."[".$trang." yes ".$vang."] ".$luc."Thêm Token Facebook Để Chạy\n";
    echo $kongdz."".$luc."Nhập ".$vang."[".$trang." no ".$vang." ] ".$luc."Vào Chạy Tool Vì Lần Trước Lưu Token Facebook Rồi\n";
    echo $kongdz."".$luc."Nhập ".$trang."yes ".$luc."Hoặc ".$trang."no: $vang";
    $choice=trim(fgets(STDIN));
    if ($choice=='yes'){
        @system('rm Token.txt');
        }
    }
if (!file_exists('Token.txt')){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Bạn Muốn Chạy Bao Nhiêu Token Facebook: $vang";
$sotk = trim(fgets(STDIN));
for($a = 1; $a <= $sotk; $a++){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Token Facebook Thứ $a: $vang";
$nhaptk = (string)trim(fgets(STDIN));
if($nhaptk == ''){break;}
$token = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$nhaptk), true);
if ($token["error"]["code"] == 368){
	echo $do.$token["error"]["message"]."\n"; $a--; continue;
} else if (!isset($token)){ echo $do."Access Token Die !!!                          \n"; $a--; continue; 
} else {
	$idfb = $token["id"];
	$tenfb = $token["name"];
	array_push($list_id, $idfb);
	array_push($list_name, $tenfb);
	array_push($khoToken,$nhaptk);
    }
}
//lưu token
            $js=json_encode($khoToken);
            $demcki=count($khoToken);
            $k = fopen("Token.txt","a+");
			fwrite($k, $js);
			fclose($k);
//lưu id
			$js=json_encode($list_id);
            $k = fopen("listid.txt","a+");
			fwrite($k, $js);
			fclose($k);
//lưu ten
			$js=json_encode($list_name);
            $k = fopen("listname.txt","a+");
			fwrite($k, $js);
			fclose($k);
    }else{
        $khoToken = json_decode(fread(fopen("Token.txt","r"),filesize("Token.txt")),true);
        $list_id = json_decode(fread(fopen("listid.txt","r"),filesize("listid.txt")),true);
		$list_name = json_decode(fread(fopen("listname.txt","r"),filesize("listname.txt")),true);
        $demcki = count($khoToken);
    }
//url
$urlinfo = "https://traodoisub.com/api/?fields=profile&access_token=$tokenacc";
$urllike = "https://traodoisub.com/api/?fields=like&access_token=$tokenacc";
$urlsub = "https://traodoisub.com/api/?fields=follow&access_token=$tokenacc";
$urlshare = "https://traodoisub.com/api/?fields=share&access_token=$tokenacc";
$urlcmt = "https://traodoisub.com/api/?fields=comment&access_token=$tokenacc";
//login
$info = api($urlinfo);
if ($info["error"]) {
    exit ($info["error"]);
}
//$thongtin
$user = strtolower($info["data"]["user"]);
$xuhientai = $info["data"]["xu"];
system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen TOOL AUTO TDS TOKEN ĐA LUỒNG \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen Thể Loại Tool Bạn Đang Chạy Là Tool: ".$BWhite."Token\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen Số Facebook Chạy Tool ".$BWhite."Token ".$luc."Là: ".$BWhite.$demcki."\n";
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen Tài Khoản TDS Của Bạn Là: ".$BWhite.$user."\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen Số Xu Hiện Tại Của Bạn Là: ".$BWhite.$xuhientai."\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen LIKE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen FOLLOW\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m3\033[1;31m]$BGreen COMMENTS\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m4\033[1;31m]$BGreen SHARE\n";
echo $BGreen." Ví dụ bạn muốn làm like follow thì điền 12 ";sleep(3); echo "\r"."                                                           "."\r";
echo chay(10);
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$nvblock = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$nvblock.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$thoigiannghi = trim(fgets(STDIN));
$hienthixu = "10";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chạy Bao Nhiêu Nhiệm Vụ Rồi Dừng Tool: $vang";
$dungtool = trim(fgets(STDIN));
while(true){
  if(count($khoToken) == 0){
    echo $kongdz."".$luc."Bạn Muốn Chạy Bao Nhiêu Token Facebook: $vang";
$sotk = trim(fgets(STDIN));
for($a = 1; $a <= $sotk; $a++){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Token Facebook Thứ $a: $vang";
$nhaptk = (string)trim(fgets(STDIN));
if($nhaptk == ''){break;}
$token = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$nhaptk), true);
if ($token["error"]["code"] == 368){
	echo $do.$token["error"]["message"]."\n"; $a--; continue;
} else if (!isset($token)){ echo $do."Access Token Die !!!                          \n"; $a--; continue; 
} else {
	$idfb = $token["id"];
	$tenfb = $token["name"];
	array_push($list_id, $idfb);
	array_push($list_name, $tenfb);
	array_push($khoToken,$nhaptk);
    }
    }
//lưu token
            $js=json_encode($khoToken);
            $demcki=count($khoToken);
            $k = fopen("Token.txt","a+");
			fwrite($k, $js);
			fclose($k);
//lưu id
			$js=json_encode($list_id);
            $k = fopen("listid.txt","a+");
			fwrite($k, $js);
			fclose($k);
//lưu ten
			$js=json_encode($list_name);
            $k = fopen("listname.txt","a+");
			fwrite($k, $js);
			fclose($k);
  }
$themtk = 0;
  for($xz=0;$xz<count($khoToken);$xz++){
 if ( $themtk == 1){ break; }
    $access_token = $khoToken[$xz];
	$idfb = $list_id[$xz];
	$tenfb = $list_name[$xz];
$urlcauhinh = "https://traodoisub.com/api/?fields=run&id=$idfb&access_token=$tokenacc";
$cauhinh = api($urlcauhinh);
if ($cauhinh["data"]["msg"] == "Cấu hình thành công!") {
	echo chay(10);
    echo $vang."ID FB: ".$luc.$idfb.$do." 🍬 ".$vang."Tên FB: ".$luc.$tenfb."".$res."\n";
    echo chay(10);
} else {
    echo $do."Chưa Cấu Hình ID Facebook ".$idfb." Vào Trao Đổi Sub\n";
    exit;
}
$spam = 0;
while (true) {
  $text = file_get_contents('https://google.com');
if($text == false){
  echo "Đường truyền không ổn định, tool sẽ tự động bật khi đường truyền ổn định trở lại!!?! \n";
  while(true){
  $text = file_get_contents('https://google.com');
  if($text !== false){
    break;
}
}}
    if ($spam == 1) {
        break;
    }
    if ($spam == 2) {
    	unset($listlike, $listsub, $listcmt, $listshare );
    	$nhiemvu = $nv_new;
    }
    //listlike
    if (strpos($nhiemvu, '1') !== false) {
        for ($i = 0; $i < 30; $i++) {
        sleep(1);
            $listlike = api($urllike);
            if (count($listlike) !== 0) {
                break;
            }

        }
    }
    //listfollow
    if (strpos($nhiemvu, '2') !== false) {
        while (true) {
        sleep(1);
            $listsub = api($urlsub);
            if (count($listsub) !== 0) {
                break;
            }

        }}
    //listcmt
    if (strpos($nhiemvu, '3') !== false) {
        for ($i = 1; $i < 30; $i++) {
        sleep(1);
            $listcmt = api($urlcmt);
            if (count($listcmt) !== 0) {
                break;
            }

}
    }
    //listshare
    if (strpos($nhiemvu, '4') !== false) {
        for ($i = 1; $i < 30; $i++) {
        sleep(1);
            $listshare = api($urlshare);
            if (count($listshare) > 0) {
                break;
            }

}
    }
    for ($lap = 0; $lap < 20; $lap++) {
        // like
        if ($listlike !== NULL) {
            $idlike = $listlike[$lap]["id"];
            if ($idlike !== '') {
                $g = like($access_token, $idlike, $cookie);
                if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Token die !!?!\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368 && $g->{'error'}->{'error_subcode'} == 1404078) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                $nhanlike = nhantien('LIKE', $idlike, $tokenacc);
                if ($nhanlike["success"] == 200) {
                    $xu = $nhanlike["data"]["xu"];
                    $xujob = "+300";
                    $dem++;
                    
                    hoanthanhlike($dem, 'LIKE', $idlike, $xujob, $xu, $hienthixu, $dungtool);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                    if ( $dem >= $dungtool ){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khoToken as $access_token ){
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nv_new = trim(fgets(STDIN));
echo chay(10);
$spam = 2;
break;
}
if ($stop == '3'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$nvblock = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$nvblock.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$thoigiannghi = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Làm Bao Nhiêu Nhiệm Vụ Hiển Thị Tổng Số Xu Đang Có: $vang";
$hienthixu = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khoToken=[];
 $list_id = [];
$list_name = [];
  break;
 } else { continue; }
 } //dừng 
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $nvblock == 0){
                      delay($thoigiannghi);
                    }
                   
                    delay($delay);
                }
            }}
        //follow
        if ($listsub !== NULL) {
            $idsub = $listsub[$lap]["id"];
            if ($idsub !== '') {
                $g = follow($access_token, $idsub, $cookie);
                if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Token die !!?!\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368 && $g->{'error'}->{'error_subcode'} == 1404078) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                $nhansub = nhantien('FOLLOW', $idsub, $tokenacc);
                if ($nhansub["success"] == 200) {
                    $xu = $nhansub["data"]["xu"];
                    $xujob = "+600";
                    $dem++;
                    $te=json_decode(file_get_contents('https://graph.facebook.com/?ids='.$idsub.'&fields=id,name&access_token='.$access_token), true);
					$ten=$te[$idsub]["name"];
					if(!isset($ten)){ $ten = $idsub; }
                    hoanthanhfollow($dem, 'FOLLOW', $idsub, $ten, $xujob, $xu, $hienthixu, $dungtool);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                                        if ( $dem >= $dungtool ){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khoToken as $access_token ){
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nv_new = trim(fgets(STDIN));
echo chay(10);
$spam = 2;
break;
}
if ($stop == '3'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$nvblock = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$nvblock.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$thoigiannghi = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Làm Bao Nhiêu Nhiệm Vụ Hiển Thị Tổng Số Xu Đang Có: $vang";
$hienthixu = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khoToken=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng 
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $nvblock == 0){
                      delay($thoigiannghi);
                    }
                    
                    
                    delay($delay);
                }
            }}
            if ($listshare !== NULL) {
                $idshare = $listshare[$lap]["id"];
                if (isset($idshare)) {
                    $g = share($access_token, $idshare);
                    if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Token die !!?!\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368 && $g->{'error'}->{'error_subcode'} == 1404078) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                        $nhanshare = nhantien('SHARE', $idshare, $tokenacc);
                        if ($nhanshare["success"] == 200) {
                            $xu = $nhanshare["data"]["xu"];
                            $xujob = "+800";
                            $dem++;
                            hoanthanhshare($dem, 'SHARE', $idshare, $xujob, $xu, $hienthixu, $dungtool);
                            if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                                                if ( $dem >= $dungtool ){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khoToken as $access_token ){
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nv_new = trim(fgets(STDIN));
echo chay(10);
$spam = 2;
break;
}
if ($stop == '3'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$nvblock = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$nvblock.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$thoigiannghi = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Làm Bao Nhiêu Nhiệm Vụ Hiển Thị Tổng Số Xu Đang Có: $vang";
$hienthixu = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khoToken=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng 
                            if($dem % $doinick == 0){
                              $spam = 1; break;
                            }
                            if($dem % $nvblock == 0){
                      delay($thoigiannghi);
                    }
                    
                    delay($delay);
                }}}
        //cmt
        if ($listcmt !== NULL) {
            $idcmt = $listcmt[$lap]["id"];
            $msg = $listcmt[$lap]["msg"];
            if ($idcmt !== '') {
                $g = cmt($access_token, $idcmt, $cookie, $msg);
                if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Token die !!?!\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368&& $g["error"]["error_subcode"] == 1404078) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }}
                $nhancmt = nhantien('COMMENT', $idcmt, $tokenacc);
                if ($nhancmt["success"] == 200) {
                    $xu = $nhancmt["data"]["xu"];
                    $xujob = "+600";
                    $dem++;
                    hoanthanhcmt($dem, 'CMT', $idcmt, $xujob, $xu, $msg, $hienthixu, $dungtool);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                                        if ( $dem >= $dungtool ){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khoToken as $access_token ){
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nv_new = trim(fgets(STDIN));
echo chay(10);
$spam = 2;
break;
}
if ($stop == '3'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$nvblock = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$nvblock.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$thoigiannghi = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Làm Bao Nhiêu Nhiệm Vụ Hiển Thị Tổng Số Xu Đang Có: $vang";
$hienthixu = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khoToken=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng 
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $nvblock == 0){
                      delay($thoigiannghi);
                    }
                  
                    delay($delay);
                }
            }}
    }
}}
} //while max
function api($url) {
    $head = array(
        "Host: traodoisub.com",
        "cache-control: max-age=0",
        "upgrade-insecure-requests: 1",
        "user-agent: Mozilla/5.0 (Linux; Android 9; Mi A1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.110 Mobile Safari/537.36",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site: none",
        "sec-fetch-mode: navigate",
        "sec-fetch-user: ?1",
        "sec-fetch-dest: document",
        //"accept-encoding: gzip, deflate, br",
        "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
    );
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_SSL_VERIFYPEER => FALSE,
        CURLOPT_RETURNTRANSFER => 1
    ));
    $get = curl_exec($ch);
    curl_close($ch);
    return json_decode($get, true);
}
function nhantien($type, $id, $tokenacc) {
    $nhan = file_get_contents("https://traodoisub.com/api/coin/?type=$type&id=$id&access_token=$tokenacc");
    return json_decode($nhan, true);
}
function follow($access_token, $idtest, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$idtest.'/subscribers');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function like($access_token, $id, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/likes');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);

}
function share($access_token,$id) {
 $ch=curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/v2.0/me/feed');
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
$data = array(
'privacy' => '{"value":"EVERYONE"}',
'message' => '',
'link' => 'https://mbasic.facebook.com/'.$id.'',
'access_token' => $access_token
);
curl_setopt($ch, CURLOPT_POST,count($data));
curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
$a = json_decode(curl_exec($ch), true);                                    
curl_close($ch);
   return $a;
}
function cmt($access_token, $idcmt, $cookie, $msg) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$idcmt.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('message' => $msg, 'access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function hoanthanhlike($dem, $type, $idlike, $xujob, $xu) {
$maul=rand(31,37);
$maui="\033[1;".$maul."m";
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;96m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idlike."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhfollow($dem, $type, $idsub, $ten, $xujob, $xu) {
$maul=rand(31,37);
$maui="\033[1;".$maul."m";
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;96m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idsub."\033[1;91m 🍬 \033[1;96m".$ten."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhshare($dem, $type, $idshare, $xujob, $xu) {
$maul=rand(31,37);
$maui="\033[1;".$maul."m";
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;96m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idshare."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhcmt($dem, $type, $id, $xujob, $xu,$msg) {
$maul=rand(31,34);
$mauli="\033[1;".$maul."m";
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;96m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$id."\033[1;91m 🍬 \033[1;96m".$msg." \033[1;91m🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
    
function delay($delay) {
    for ($time = $delay; $time > -1; $time--) {
        echo "\r\033[1;93m   LVB \033[1;91m ~>       \033[1;92m LO      \033[1;91m | $time | ";
        usleep(150000);
        echo "\r\033[1;91m   LVB \033[0;33m   ~>     \033[0;37m LOA     \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;92m   LVB \033[0;33m     ~>   \033[0;37m LOAD    \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;94m   LVB \033[0;33m       ~> \033[0;37m LOADI   \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADIN  \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADING \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADING.\033[0;31m | $time | ";
        usleep(150000);}
        echo "\r\e[1;95m    ⚡Lê Văn Bình⚡                       \r";}
function laytoken($cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $access = curl_exec($ch);
    curl_close($ch);
    if (explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access)[1])[0]) {
        $access_token = explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access)[1])[0];
    }
    return $access_token;
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}