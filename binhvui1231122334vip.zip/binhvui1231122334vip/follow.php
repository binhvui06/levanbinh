error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
$useragent ="Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.1.4472.198 Safari/537.36";
@system('clear');
echo chay(10);
echo $BGreen."Nhập Cookie Facebook : $BWhite";
$cookie =trim(fgets(STDIN));
echo $BGreen."Nhập ID Cần Tăng Follow : $BWhite";
$id =trim(fgets(STDIN));
@system('clear');
sleep(2);
// login
$header = array( 
"Host:autofollows.ml",
"Upgrade-Insecure-Requests:1",
"Origin:null",
"Content-Type:application/x-www-form-urlencoded",
"User-Agent:$useragent",
);
$data = 'user='.$cookie.'&submit=';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://autofollows.ml/x_login.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
// logo
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO TĂNG FOLLOW FACEBOOK \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo $BGreen."Đang tăng Follow  ID : $id \n";
while(true){ 
sleep(1);
// tăng follow
$header = array( 
"Host:autofollows.ml",
"Upgrade-Insecure-Requests:1",
"Origin:null",
"Content-Type:application/x-www-form-urlencoded",
"User-Agent:$useragent",
);
$data = 'id='.$id.'&submit=';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://autofollows.ml/follow.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

// thành công
$header = array( 
"Host:autofollows.ml",
"Upgrade-Insecure-Requests:1",
"User-Agent:$useragent",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://autofollows.ml/follow.php?info=follow_success');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

$so++;
echo $BCyan."[$so]$BRed ★$BGreen $id $BRed ★$BYellow Auto Followers Success! \n";
for ($time=300;$time>-1;$time--){
echo $BPurple."Vui lòng chờ $BGreen  $time       giây       \r";
sleep(1); echo "\r                                         \r";
}
} // vòng lặp while
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}