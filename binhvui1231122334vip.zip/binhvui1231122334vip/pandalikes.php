error_reporting(1);
$BBlack="\033[1;30m" ; 
$do="\033[1;31m" ;
$xanhlacay="\033[1;32m" ;
$vang="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$datroi="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$useragent='Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.152 Mobile Chrome/89.1.4389.152 Mobile Safari/537.36';
@system('clear');
echo chay(10);
echo $xanhlacay."Nhập Cookie : $BWhite";
$cookie =trim(fgets(STDIN));
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BWhite =>$xanhlacay TOOL AUTO PANDALIKES.XYZ \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BWhite =>$datroi Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BWhite =>$turquoise Youtube : $datroi LÊ VĂN BÌNH ✅ $xanhlacay\n";
    usleep(100000);
echo chay(10);

while(true){ 
// Get id video
$url = "https://pandalikes.xyz/index.php?page=module&md=youtube";

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_HTTPHEADER => array(
"Host:pandalikes.xyz",
"upgrade-insecure-requests:1",
"user-agent:$useragent",
"referer:https://pandalikes.xyz/index.php",
"cookie:$cookie",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);


$name = explode('<div class="title"><img src="https://i.imgur.com/34fAsw6.png" class="" />', $mr2)[1];
$name = explode('<', $name)[0];

$coin = explode('<b id="c_coins" class="text-warning">', $mr2)[1];
$coin = explode('<', $coin)[0];

$bn = explode('<b class="text-success">', $mr2)[1];
$bn = explode('<', $bn)[0];

$id = explode('<div class="website_block" id="', $mr2)[1];
$id = explode('"', $id)[0];

$xu = explode('<div class="coins"><b>Reward</b>: <span>', $mr2)[1];
$xu = explode('<', $xu)[0];

$so++;
echo $datroi."[$so]$do ★$xanhlacay ID$do ★$xanhlacay $id$do ★$xanhlacay + $xu \n";
// time
$url = "https://pandalikes.xyz/index.php?page=module&md=youtube&vid=".$id."";

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_HTTPHEADER => array(
"Host:pandalikes.xyz",
"upgrade-insecure-requests:1",
"user-agent:$useragent",
"referer:https://pandalikes.xyz/index.php?page=module&md=youtube",
"cookie:$cookie",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);


$time = explode('var length = ', $mr2)[1];
$time = explode(';', $time)[0];

for ($time=$time;$time>-1;$time--){
echo $vang."Vui lòng chờ $green $time giây  \r";
sleep(1);
}
// nhan tien
$url = "https://pandalikes.xyz/system/modules/youtube/process.php";

$data = 'data='.$id.'';

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => $data,
CURLOPT_HTTPHEADER => array(
"Host:pandalikes.xyz",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://pandalikes.xyz",
"referer:https://pandalikes.xyz/index.php?page=module&md=youtube&vid=".$id."",
"cookie:$cookie",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);


echo "\033[1;33m[\033[1;32mSUCCESS\033[1;33m]$do ★$xanhlacay + $xu $do ★$xanhlacay $coin $do ★$xanhlacay $bn \n";
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}


