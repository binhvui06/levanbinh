error_reporting(0);
session_start();
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$resss="\033[0m";
$ress = "\033[0;32m";
$res = "\033[0;33m";
$red = "\033[0;31m";
$green = "\033[0;37m";
$yellow = "\033[0;33m";
$white = "\033[0;33m";
$xnhac = "\033[1;96m";
$den = "\033[1;90m";
$do = "\033[1;91m";
$luc = "\033[1;92m";
$vang = "\033[1;93m";
$xduong = "\033[1;94m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
$kongdz = $do."[".$luc."🍬".$do."] ".$trang."=> ";
$kongvip = $do."[".$luc."🍬".$do."]";
$thanhngang = $vang."----------------------------------------------------------\n";
date_default_timezone_set("Asia/Ho_Chi_Minh");
system('clear');
while (true){
echo chay(10);
$dem = 0;
  echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Vào Web ".$trang."Traodoisub.com".$luc." Bấm Cài Đặt Trên Web\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sao Chép ".$vang."Access_token".$luc." Dán Vào\n";
  echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Access_token: $vang";
  $tokenacc = trim(fgets(STDIN));
echo chay(10);
//cookie 
$khocookie = [];
$list_id = [];
$list_name = [];
if (file_exists('cookie.txt')){
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$vang."[".$trang." yes ".$vang."] ".$luc."Thêm Cookie Facebook Để Chạy\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$vang."[".$trang." no ".$vang." ] ".$luc."Vào Chạy Tool Vì Lần Trước Lưu Cookie Facebook Rồi\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$trang."yes ".$luc."Hoặc ".$trang."no: $vang";
    $choice=trim(fgets(STDIN));
    if ($choice=='yes'){
        @system('rm cookie.txt');
        }
    }
if (!file_exists('cookie.txt')){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Bạn Muốn Chạy Bao Nhiêu Cookie Facebook: $vang";
$sock = trim(fgets(STDIN));
for($a = 1; $a <= $sock;$a++){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Cookie Facebook Thứ $a: $vang";
$nhapck = (string)trim(fgets(STDIN));
if($nhapck == ''){break;}
$access_token = laytoken($nhapck);
$token = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token), true);
if ($token["error"]["code"] == 368){
	echo $do.$token["error"]["message"]."\n"; $a--; continue;
} else if (!isset($token)){ echo $do."Access Token Die !!!                          \n"; $a--; continue; 
} else {
	$idfb = $token["id"];
	$tenfb = $token["name"];
	array_push($list_id, $idfb);
	array_push($list_name, $tenfb);
	array_push($khocookie,$nhapck);
    }
    }
//lưu cookie
            $js=json_encode($khocookie);
            $demcki=count($khocookie);
            $k = fopen("cookie.txt","a+");
			fwrite($k, $js);
			fclose($k);
//lưu tên
			$js=json_encode($list_name);
            $k = fopen("tenck.txt","a+");
			fwrite($k, $js);
			fclose($k);
    }else{
        $khocookie = json_decode(fread(fopen("cookie.txt","r"),filesize("cookie.txt")),true);
        $list_name = json_decode(fread(fopen("tenck.txt","r"),filesize("tenck.txt")),true);
		$demcki = count($khocookie);
    }
//url
$urlinfo = "https://traodoisub.com/api/?fields=profile&access_token=$tokenacc";
$urllike = "https://traodoisub.com/api/?fields=like&access_token=$tokenacc";
$urlsub = "https://traodoisub.com/api/?fields=follow&access_token=$tokenacc";
$urlcx = "https://traodoisub.com/api/?fields=reaction&access_token=$tokenacc";
$urlshare = "https://traodoisub.com/api/?fields=share&access_token=$tokenacc";
$urlcmt = "https://traodoisub.com/api/?fields=comment&access_token=$tokenacc";
$urlpage = "https://traodoisub.com/api/?fields=page&access_token=$tokenacc";
$urllikecmt = "https://traodoisub.com/api/?fields=reactcmt&access_token=$tokenacc";
//login
$info = api($urlinfo);
if ($info["error"]) {
    exit ($info["error"]);
}
//$thongtin
$user = $info["data"]["user"];
$xuhientai = $info["data"]["xu"];
system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen TOOL AUTO TDS COOKIE ĐA LUỒNG \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen Thể Loại Tool Bạn Đang Chạy Là Tool: ".$BWhite."Cookie\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen Số Facebook Chạy Tool ".$BWhite."Cookie ".$luc."Là: ".$BWhite.$demcki."\n";
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen Tài Khoản TDS Của Bạn Là: ".$BWhite.$user."\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen Số Xu Hiện Tại Của Bạn Là: ".$BWhite.$xuhientai."\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen LIKE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen FOLLOW\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m3\033[1;31m]$BGreen CẢM XÚC\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m4\033[1;31m]$BGreen COMMENTS\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m5\033[1;31m]$BGreen PAGE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m6\033[1;31m]$BGreen SHARE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$BGreen  Nhập \033[1;31m[\033[1;32m7\033[1;31m]$BGreen CẢM XÚC CMT\n";
echo $BGreen." Ví dụ bạn muốn làm like follow thì điền 12 ";sleep(3); echo "\r"."                                                           "."\r";
echo chay(10);
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$xxxxx = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$xxxxx.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$delaybl = trim(fgets(STDIN));
$hienthixu = "10";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chạy Bao Nhiêu Nhiệm Vụ Rồi Dừng Tool: $vang";
$dungtool = trim(fgets(STDIN));
while(true){
  if(count($khocookie) == 0){
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Bạn Muốn Chạy Bao Nhiêu Cookie Facebook: $vang";
    $sock = trim(fgets(STDIN));
for($a = 1; $a < $sock;$a++){
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập Cookie Facebook Thứ $a: $vang";
$nhapck = (string)trim(fgets(STDIN));
if($nhapck == ''){break;}
$access_token = laytoken($nhapck);
$token = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token), true);
if ($token["error"]["code"] == 368){
	echo $do.$token["error"]["message"]."\n"; $a--; continue;
} else if (!isset($token)){ echo $do."Access Token Die !!!                          \n"; $a--; continue; 
} else {
	$idfb = $token["id"];
	$tenfb = $token["name"];
	array_push($list_id, $idfb);
	array_push($list_name, $tenfb);
	array_push($khocookie,$nhapck);
    }
    }
//lưu cookie
            $js=json_encode($khocookie);
            $demcki=count($khocookie);
            $k = fopen("cookie.txt","a+");
			fwrite($k, $js);
			fclose($k);
//lưu tên
			$js=json_encode($list_name);
            $k = fopen("tenck.txt","a+");
			fwrite($k, $js);
			fclose($k);
  }
  $themtk = 0;
  for($xz=0;$xz<count($khocookie);$xz++){
 if ( $themck == 1){ break; }
 $cookie = $khocookie[$xz];
$access_token = laytoken($cookie);
if (strpos($access_token, 'EAAAA') !== 0) {
    echo "Cookie lỗi!!?! \n"; continue;
}
$idfb = explode(';',explode('c_user=',$cookie)[1])[0];
$tenfb = $list_name[$xz];
$urlcauhinh = "https://traodoisub.com/api/?fields=run&id=$idfb&access_token=$tokenacc";
$cauhinh = api($urlcauhinh);
if ($cauhinh["data"]["msg"] == "Cấu hình thành công!") {
	echo chay(10);
    echo $vang."ID FB: ".$luc.$idfb.$do." 🍬 ".$vang."Tên FB: ".$luc.$tenfb."".$res."\n";
    echo chay(10);
} else {
    echo $do."Chưa Cấu Hình ID Facebook ".$idfb." Vào Trao Đổi Sub\n";
    exit;
}
$spam = 0;
while (true) {
  $text = file_get_contents('https://google.com');
if($text == false){
  echo "Đường truyền không ổn định, tool sẽ tự động bật khi đường truyền ổn định trở lại!!?! \n";
  while(true){
  $text = file_get_contents('https://google.com');
  if($text !== false){
    break;
}
}}
    if ($spam == 1) {
        break;
    }
    //listlike
    if (strpos($nhiemvu, '1') !== false) {
        for ($i = 0; $i < 30; $i++) {
sleep(7);
            $listlike = api($urllike);
            if (count($listlike) !== 0) {
                break;
            }}
    } else { unset($listlike); }
    //listfollow
    if (strpos($nhiemvu, '2') !== false) {
        while (true) {
sleep(1);
            $listsub = api($urlsub);
            if (count($listsub) !== 0) {
                break;
            }
        }} else { unset($listsub); }
    //listreaction
    if (strpos($nhiemvu, '3') !== false) {
        for ($i = 1; $i < 30; $i++) {
sleep(1);
            $listcx = api($urlcx);
            if (count($listcx) !== 0) {
                break;
            }}
    } else { unset($listcx); }
    //listcmt
    if (strpos($nhiemvu, '4') !== false) {
        for ($i = 1; $i < 30; $i++) {
sleep(1);
            $listcmt = api($urlcmt);
            if (count($listcmt) !== 0) {
                break;
            }}
    } else { unset($listcmt); }
    //listpage
    if (strpos($nhiemvu, '5') !== false) {
        for ($i = 1; $i < 30; $i++) {
sleep(1);
            $listpage = api($urlpage);
            if (count($listpage) !== 0) {
                break;
            }}
    } else { unset($listpage); }
    //share
    if (strpos($nhiemvu, '6') !== false) {
        for ($i = 1; $i < 30; $i++) {
sleep(1);
            $listshare = api($urlshare);
            if (count($listshare) > 0) {
                break;
            }}
    } else { unset($listshare); }
    //listlikecmt
    if (strpos($nhiemvu, '7') !== false) {
        for ($i = 1; $i < 30; $i++) {
sleep(1);
            $listlikecmt = api($urllikecmt);
            if (count($listlikecmt) !== 0) {
                break;
            }}
    } else { unset($listlikecmt); }
    for ($lap = 0; $lap < 20; $lap++) {
        // like
        if ($listlike !== NULL) {
            $idlike = $listlike[$lap]["id"];
            if ($idlike !== '') {
                $g = like($access_token, $idlike, $cookie);
                if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Cookie die !!?!\n";
                    array_splice($khoToken,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368 && $g->{'error'}->{'error_subcode'} == 1404154) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1;
                    break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1;
                    break;
                }
                $nhanlike = nhantien('LIKE', $idlike, $tokenacc);
                if ($nhanlike["success"] == 200) {
                    $xu = $nhanlike["data"]["xu"];
                    $xujob = "+300";
                    $dem++;
                    
                    hoanthanhlike($dem, 'LIKE', $idlike, $xujob, $xu);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                    if ( $dem >= $dungtool ){
echo $kongdz.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khocookie as $cookie ){ 
 $access_token = laytoken($cookie);
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $kongdz.$luc."Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $kongdz.$luc."Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
$hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Để Chạy Nhiệm Vụ Fanpage\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."6".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."7".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc CMT\n";
echo $kongdz.$luc."Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $kongdz.$luc."Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo chay(10);
break;
}
if ($stop == '3'){
echo $kongdz.$luc."Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$xxxxx = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$xxxxx.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$delaybl = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khocookie=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng 
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $xxxxx == 0){
                      delay($delaybl);
                    }
                    
                    
                    delay($delay);
                }
            }}
        //follow
        if ($listsub !== NULL) {
            $idsub = $listsub[$lap]["id"];
            if ($idsub !== '') {
                $g = follow($access_token, $idsub, $cookie);
                if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Cookie die !!?!\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368 && $g->{'error'}->{'error_subcode'} == 1404154) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                $nhansub = nhantien('FOLLOW', $idsub, $tokenacc);
                if ($nhansub["success"] == 200) {
                    $xu = $nhansub["data"]["xu"];
                    $xujob = "+600";
                    $dem++;
                    $te=json_decode(file_get_contents('https://graph.facebook.com/?ids='.$idsub.'&fields=id,name&access_token='.$access_token), true);
					$ten=$te[$idsub]["name"];
					if(!isset($ten)){ $ten = $idsub; }
                    hoanthanhfollow($dem, 'FOLLOW', $idsub, $ten, $xujob, $xu);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                    if ( $dem >= $dungtool ){
echo $kongdz.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khocookie as $cookie ){ 
 $access_token = laytoken($cookie);
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $kongdz.$luc."Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $kongdz.$luc."Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Để Chạy Nhiệm Vụ Fanpage\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."6".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."7".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc CMT\n";
echo $kongdz.$luc."Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $kongdz.$luc."Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo chay(10);
break;
}
if ($stop == '3'){
echo $kongdz.$luc."Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$xxxxx = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$xxxxx.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$delaybl = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khocookie=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng 
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $xxxxx == 0){
                      delay($delaybl);
                    }
                    
                    
                    delay($delay);
                }
            }}
        //cảm xúc
        if ($listcx !== NULL) {
            $idcx = $listcx[$lap]["id"];
            $type = $listcx[$lap]["type"];
            if ($idcx !== '') {
                $g = camxuc($idcx, $type, $cookie);
                if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Cookie die !!?!\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                $nhancx = nhantien($type, $idcx, $tokenacc);
                if ($nhancx["success"] == 200) {
                    $xu = $nhancx["data"]["xu"];
                    $xujob = "+400";
                    $dem++;
                    if ($type == 'WOW') {
                        $type = 'WOW';
                    } elseif ($type == 'SAD') {
                        $type = 'SAD';
                    } elseif ($type == 'ANGRY') {
                        $type = 'ANGRY';
                    } elseif ($type == 'LOVE') {
                        $type = 'LOVE';
                    } elseif ($type == 'HAHA') {
                        $type = 'HAHA';
                    } elseif ($type == 'CARE') {
                        $type = 'CARE';
                    }
                    hoanthanhcx($dem, $type, $idcx, $xujob, $xu);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                    if ( $dem >= $dungtool ){
echo $kongdz.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khocookie as $cookie ){ 
 $access_token = laytoken($cookie);
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $kongdz.$luc."Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $kongdz.$luc."Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Để Chạy Nhiệm Vụ Fanpage\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."6".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."7".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc CMT\n";
echo $kongdz.$luc."Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $kongdz.$luc."Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo chay(10);
break;
}
if ($stop == '3'){
echo $kongdz.$luc."Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$xxxxx = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$xxxxx.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$delaybl = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khocookie=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng  
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $xxxxx == 0){
                      delay($delaybl);
                    }
                    
                    
                    delay($delay);
                }
            }}
            if ($listshare !== NULL) {
                $id = $listshare[$lap]["id"];
                    $g = share($access_token, $id);
                    if ($g -> {'error'} -> {'code'} == 190) {
                        echo "Cookie die !!?!\n";
                        array_splice($khoToken,$xz,1);
                        array_splice($list_id, $xz, 1);
                    	array_splice($list_name, $xz, 1);
                        $spam = 1; break;
                    }
                    if ($g -> {'error'} -> {'code'} == 368 && $g->{'error'}->{'error_subcode'} == 1404154) {
                        echo "\033[1;91m".$g-> {'error'}-> {'message'};
                        echo "\n";
                        array_splice($khoToken,$xz,1);
                        array_splice($list_id, $xz, 1);
                    	array_splice($list_name, $xz, 1);
                        $spam = 1; break;
                    }
                    if ($g -> {'error'} -> {'code'} == 405) {
                        echo "\033[1;91m"."Tài khoản bị checkpoint";
                        array_splice($khoToken,$xz,1);
                        array_splice($list_id, $xz, 1);
                    	array_splice($list_name, $xz, 1);
                        $spam = 1; break;
                    }
                        $nhanshare = nhantien('SHARE', $id, $tokenacc);
                        if ($nhanshare["success"] == 200) {
                            $xu = $nhanshare["data"]["xu"];
                            $xujob = "+800";
                            $dem++;
                            hoanthanhshare($dem, 'SHARE', $id, $xujob, $xu);
                            if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                            if ( $dem >= $dungtool ){
echo $kongdz.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khocookie as $cookie ){ 
 $access_token = laytoken($cookie);
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $kongdz.$luc."Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $kongdz.$luc."Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Để Chạy Nhiệm Vụ Fanpage\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."6".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."7".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc CMT\n";
echo $kongdz.$luc."Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $kongdz.$luc."Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo chay(10);
break;
}
if ($stop == '3'){
echo $kongdz.$luc."Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$xxxxx = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$xxxxx.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$delaybl = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khocookie=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng 
                            if($dem % $doinick == 0){
                              $spam = 1; break;
                            }
                            if($dem % $xxxxx == 0){
                      delay($thoigiannghi);
                    }
                    
                    delay($delay);
                }}
        //cmt
        if ($listcmt !== NULL) {
            $idcmt = $listcmt[$lap]["id"];
            $msg = $listcmt[$lap]["msg"];
            if ($idcmt !== '') {
                $g = cmt($access_token, $idcmt, $cookie, $msg);
                if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Cookie die !!?!\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368 && $g->{'error'}->{'error_subcode'} == 1404154) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                $nhancmt = nhantien('COMMENT', $idcmt, $tokenacc);
                if ($nhancmt["success"] == 200) {
                    $xu = $nhancmt["data"]["xu"];
                    $xujob = "+600";
                    $dem++;
                    hoanthanhcmt($dem, 'CMT', $idcmt, $xujob, $xu, $msg);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                    if ( $dem >= $dungtool ){
echo $kongdz.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khocookie as $cookie ){ 
 $access_token = laytoken($cookie);
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $kongdz.$luc."Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $kongdz.$luc."Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Để Chạy Nhiệm Vụ Fanpage\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."6".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."7".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc CMT\n";
echo $kongdz.$luc."Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $kongdz.$luc."Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo chay(10);
break;
}
if ($stop == '3'){
echo $kongdz.$luc."Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$xxxxx = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$xxxxx.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$delaybl = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khocookie=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng 
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $xxxxx == 0){
                      delay($delaybl);
                    }
                    
                    
                    delay($delay);
                }
            }}
        //page
        if ($listpage !== NULL) {
            $idpage = $listpage[$lap]["id"];
            if ($idpage !== '') {
                $g = page($idpage, $cookie);
                if ($g -> {'error'} -> {'code'} == 190) {
                    echo "Cookie die !!?!\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 368) {
                    echo "\033[1;91m".$g-> {'error'}-> {'message'};
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                if ($g -> {'error'} -> {'code'} == 405) {
                    echo "\033[1;91m"."Tài khoản bị checkpoint";
                    echo "\n";
                    array_splice($khocookie,$xz,1);
                    array_splice($list_id, $xz, 1);
                    array_splice($list_name, $xz, 1);
                    $spam = 1; break;
                }
                $nhanpage = nhantien('PAGE', $idpage, $tokenacc);
                if ($nhanpage["success"] == 200) {
                    $xu = $nhanpage["data"]["xu"];
                    $xujob = "+700";
                    $dem++;
                    $te=json_decode(file_get_contents('https://graph.facebook.com/?ids='.$idpage.'&fields=id,name&access_token='.$access_token), true);
					$tenpage=$te[$idpage]["name"];
                    hoanthanhpage($dem, 'PAGE', $idpage, $tenpage, $xujob, $xu);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                    if ( $dem >= $dungtool ){
echo $kongdz.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khocookie as $cookie ){ 
 $access_token = laytoken($cookie);
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $kongdz.$luc."Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $kongdz.$luc."Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Để Chạy Nhiệm Vụ Fanpage\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."6".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."7".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc CMT\n";
echo $kongdz.$luc."Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $kongdz.$luc."Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo chay(10);
break;
}
if ($stop == '3'){
echo $kongdz.$luc."Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$xxxxx = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$xxxxx.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$delaybl = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khocookie=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng  
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $xxxxx == 0){
                      delay($delaybl);
                    }
                    
                    
                    delay($delay);
                }
            }
        }
        //likecmt
        if ($listlikecmt !== NULL) {
            $idlikecmt = $listlikecmt[$lap]["id"];
            $type = $listlikecmt[$lap]["type"];
            if ($idlikecmt !== '') {
                if ($type == 'LIKE'){
                    like($access_token, $idlikecmt, $cookie);
                }else{
                    camxuc($idlikecmt, $type, $cookie);
                }               
                $nhanpage = nhantien($type.'CMT', $idlikecmt, $tokenacc);
                if ($nhanpage["success"] == 200) {
                    $xu = $nhanpage["data"]["xu"];
                    $xujob = "+600";
                    $dem++;
                    hoanthanhlikecmt($dem, $type.' CMT', $idlikecmt, $xujob, $xu);
                    if ($dem % $hienthixu == 0){
                    	echo chay(10);
                    echo $luc."Tài khoản: ".$vang.$user.$do." 🍬 ".$luc."Tổng Xu Đang Có: ".$vang.$xu."\n";
                    echo chay(10);
                    }
                    if ( $dem >= $dungtool ){
echo $kongdz.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Dừng Tool \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Thay Nhiệm Vụ Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Thay Delay Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."4".$do."]".$luc." Thay Token Mới \n";
echo $kongdz.$luc."Nhập ".$do."[".$vang."5".$do."]".$luc." Tiếp Tục Với Các Tài Khoản $vang";
foreach ( $khocookie as $cookie ){ 
 $access_token = laytoken($cookie);
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
echo $vang.$tenfb.$luc." 🍬 ";
}
echo "\n";
echo $kongdz.$luc."Nhập Số: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
if ($stop == '1'){
	$dungtool = 999999;
    echo $trang."Bạn Đã Chọn Dừng Tool Số Xu Của Bạn Là: ".$vang.$xu."\n";
    echo $luc."Cảm Ơn Bạn Đã Sử Dụng Tool Của Lê Văn Bình\n";
    exit;}
if (($stop == '2') or ($stop == '3') or ($stop == '4') or ($stop == '5')){
	echo $kongdz.$luc."Bạn Muốn Chạy Thêm Bao Nhiệm Nhiệm Vụ Nữa: $vang";
		$chaythem = trim (fgets(STDIN));
  $hienthixu10 = "0";
 $dungtool = $dungtool + $chaythem;
 $hienthixu = $hienthixu + $hienthixu10;
echo chay(10);
}
 if ($stop == '2'){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Like\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Follow\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."4".$do."]".$luc." Để Chạy Nhiệm Vụ Comment\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."5".$do."]".$luc." Để Chạy Nhiệm Vụ Fanpage\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."6".$do."]".$luc." Để Chạy Nhiệm Vụ Share\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Nhập ".$do."[".$vang."7".$do."]".$luc." Để Chạy Nhiệm Vụ Cảm Xúc CMT\n";
echo $kongdz.$luc."Muốn Chạy Random Thì Ghép Mấy Số Nhiệm Vụ Bất Kỳ\n";
echo $kongdz.$luc."Nhập Số Để Chạy Nhiệm Vụ: $vang";
$nhiemvu = trim(fgets(STDIN));
echo chay(10);
break;
}
if ($stop == '3'){
echo $kongdz.$luc."Nhập Thời Gian Làm Nhiệm Vụ: $vang";
$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Kích Hoạt Chống Block: $vang";
$xxxxx = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Sau ".$vang.$xxxxx.$luc." Nhiệm Vụ Nghỉ Ngơi Bao Nhiêu Giây: $vang";
$delaybl = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$BWhite =>$lime  Chuyển Nick Sau Bao Nhiêu Nhiệm Vụ: $vang";
$doinick = trim(fgets(STDIN));
echo chay(10);
}
if ($stop == '4'){
 $spam = 1;
 $themtk = 1;
 $khocookie=[];
 $list_id = [];
 $list_name = [];
  break;
 } else { continue; }
 } //dừng 
                    if($dem % $doinick == 0){
                      $spam = 1; break;
                    }
                    if($dem % $xxxxx == 0){
                      delay($delaybl);
                    }
                    
                    
                    delay($delay);
                }
            }
        }
    }
}}}}
function api($url) {
    $head = array(
        "Host: traodoisub.com",
        "cache-control: max-age=0",
        "upgrade-insecure-requests: 1",
        "user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/E7FBAF",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site: none",
        "sec-fetch-mode: navigate",
        "sec-fetch-user: ?1",
        "sec-fetch-dest: document",
        //"accept-encoding: gzip, deflate, br",
        "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
    );
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_SSL_VERIFYPEER => FALSE,
        CURLOPT_RETURNTRANSFER => 1
    ));
    $get = curl_exec($ch);
    curl_close($ch);
    return json_decode($get, true);
}
function nhantien($type, $id, $tokenacc) {
    $nhan = file_get_contents("https://traodoisub.com/api/coin/?type=$type&id=$id&access_token=$tokenacc");
    return json_decode($nhan, true);
}
function follow($access_token, $idtest, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$idtest.'/subscribers');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function share($access_token,$id) {
 $ch=curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/v2.0/me/feed');
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
$data = array(
'privacy' => '{"value":"EVERYONE"}',
'message' => '',
'link' => 'https://mbasic.facebook.com/'.$id.'',
'access_token' => $access_token
);
curl_setopt($ch, CURLOPT_POST,count($data));
curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
$a = json_decode(curl_exec($ch), true);                                    
curl_close($ch);
   return $a;
}
function like($access_token, $id, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/likes');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);

}
function cmt($access_token, $idcmt, $cookie, $msg) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$idcmt.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('message' => $msg, 'access_token' => $access_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function page($idpage, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$idpage);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
    :'));
    $page = curl_exec($ch);
    if (explode('&amp;refid=', explode('pageSuggestionsOnLiking=1&amp;gfid=', $page)[1])[0]) {
        $get = explode('&amp;refid=', explode('pageSuggestionsOnLiking=1&amp;gfid=', $page)[1])[0];
        $link = 'https://mbasic.facebook.com/a/profile.php?fan&id='.$idpage.'&origin=page_profile&pageSuggestionsOnLiking=1&gfid='.$get.'&refid=17';
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
    }
    curl_close($ch);

}
function camxuc($idcx, $type, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/reactions/picker/?is_permalink=1&ft_id='.$idcx);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
    :'));
    $cx = curl_exec($ch);
    $haha = explode('<a href="', $cx);
    if ($type == 'LOVE') {
        $haha2 = explode('" style="display:block"', $haha[2])[0];
    } else if ($type == 'WOW') {
        $haha2 = explode('" style="display:block"', $haha[5])[0];
    } else if ($type == 'CARE') {
        $haha2 = explode('" style="display:block"', $haha[3])[0];
    } else if ($type == 'HAHA') {
        $haha2 = explode('" style="display:block"', $haha[4])[0];
    } else if ($type == 'SAD') {
        $haha2 = explode('" style="display:block"', $haha[6])[0];
    } else {
        $haha2 = explode('" style="display:block"', $haha[7])[0];
    }
    $link2 = html_entity_decode($haha2);
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com'.$link2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);
    curl_close($ch);
}
function hoanthanhlike($dem, $type, $idlike, $xujob, $xu) {
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idlike."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhfollow($dem, $type, $idsub, $ten, $xujob, $xu) {
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idsub."\033[1;91m 🍬 \033[1;96m".$ten."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhcx($dem, $type, $idcx, $xujob, $xu) {
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idcx."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhshare($dem, $type, $id, $xujob, $xu) {
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$id."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhcmt($dem, $type, $idcmt, $xujob, $xu,$msg) {
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idcmt."\033[1;91m 🍬 \033[1;96m".$msg." \033[1;91m🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhpage($dem, $type, $idpage, $tenpage, $xujob, $xu) {
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idpage."\033[1;91m 🍬 \033[1;96m".$tenpage."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function hoanthanhlikecmt($dem, $type, $idlikecmt, $xujob, $xu) {
$a = "\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i")."\033[1;91m 🍬\033[1;93m $type\033[1;91m 🍬 \033[1;97m".$idlikecmt."\033[1;91m 🍬\033[1;92m ".$xujob." \033[1;91m🍬 \033[1;33m $xu\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(2000);
    }}
function delay($delay) {
    for ($time = $delay; $time > -1; $time--) {
        echo "\r\033[1;93m   LVB \033[1;91m ~>       \033[1;92m LO      \033[1;91m | $time | ";
        usleep(150000);
        echo "\r\033[1;91m   LVB \033[0;33m   ~>     \033[0;37m LOA     \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;92m   LVB \033[0;33m     ~>   \033[0;37m LOAD    \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;94m   LVB \033[0;33m       ~> \033[0;37m LOADI   \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADIN  \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADING \033[0;31m | $time | ";
        usleep(150000);
        echo "\r\033[1;95m   LVB \033[0;33m        ~>\033[0;37m LOADING.\033[0;31m | $time | ";
        usleep(150000);}
        echo "\r\e[1;95m    ⚡Lê Văn Bình⚡                       \r";}
function laytoken($cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $access = curl_exec($ch);
    curl_close($ch);
    if (explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access)[1])[0]) {
        $access_token = explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access)[1])[0];
    }
    return $access_token;
}
function joingr($id,$cookie){
  $ch = curl_init();
  $head_fb=array(
    "Host:mbasic.facebook.com",
    "cache-control:max-age=0",
    "upgrade-insecure-requests:1",
    "save-data:on",
    "user-agent:Mozilla/5.0 (Linux; Android 10; RMX1929) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Mobile Safari/537.36",
    "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "sec-fetch-site:cross-site",
    "sec-fetch-mode:navigate",
    "sec-fetch-user:?1",
    "sec-fetch-dest:document",
    "accept-language:vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
    "cookie:".$cookie);
  curl_setopt_array ($ch, array (
  CURLOPT_URL => "https://mbasic.facebook.com/groups/$id?_rdr",
  CURLOPT_FOLLOWLOCATION => false,
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_POST => 1,
  CURLOPT_HTTPGET => true,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTPHEADER => $head_fb,
  CURLOPT_HEADER => true,
  CURLOPT_ENCODING => TRUE));
  $data = curl_exec($ch);
 // var_dump($data);
  if (strpos($data,"xs=deleted") == true){
  echo ( $red."Cookie die rồi\n");
  }
  $tìm =explode("/a/group/join/?",$data);
  $tìm1=explode('"',$tìm[1]);
  $fb=explode('name="fb_dtsg" value="',$data);
  $fb=explode('"',$fb[1]);
  $fbdtsg=htmlspecialchars_decode($fb[0]);
  $jaz=explode('name="jazoest" value="',$data);
  $jaz=explode('"',$jaz[1]);
  $url="https://mbasic.facebook.com/a/group/join/?".htmlspecialchars_decode($tìm1[0]);
  $data="fb_dtsg=$fbdtsg&jazoest=".$jaz[0];
  curl_setopt_array ($ch, array (
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => $data,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTPHEADER => $head_fb));
  $xxx = curl_exec($ch);
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}