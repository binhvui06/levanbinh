error_reporting(0);
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
/***[ Color ]***/
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
/***[ USERAGENT ]***/
$_SESSION['useragent'] = 'Mozilla/5.0 (Linux; Android 10; CPH1819) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36';
/***[ Đánh Dấu Bản Quyền ]***/
$thanh_xau= $trang."~".$do."[".$luc."●".$do."] ".$trang."➩ ";
$thanh_dep= $trang."~".$do."[".$luc."✓".$do."] ".$trang."➩ ";
@system('clear');
while (true){
echo chay(10);
echo $lime."Nhập Cookie TTC : $BWhite";
$_SESSION['cookie_web'] = trim(fgets(STDIN));
$ch = curl_init();
curl_setopt_array($ch, array(
	CURLOPT_URL => 'https://tuongtaccheo.com/home.php',
	CURLOPT_PORT => "443",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_SSL_VERIFYPEER => true,
	CURLOPT_CUSTOMREQUEST => "GET",
	CURLOPT_COOKIE => $_SESSION['cookie_web']
  ));
$data = curl_exec($ch);
if (strpos ($data, "Chào mừng") !== false){
	echo $xnhac."    Đăng nhập thành công !!!\n";
	break;
} else {
	echo $do." Đăng Nhập Thất Bại, Vui Lòng Nhập Lại  \n";
}
}
$user =  explode('</i>', explode('>Chào mừng <i>', $data)[1])[0];
$khock = [];
$list_id = [];
$list_name = [];
if (file_exists('cookiettc.txt')){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Nhập ".$do."[".$BWhite."1".$do."]".$luc." Sử Dụng Cookie Đã Lưu \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Nhập ".$do."[".$BWhite."2".$do."]".$luc." Nhập Cookie Facebook Mới \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Nhập Lựa Chọn : $BWhite";
	$nhap = trim(fgets(STDIN));
if($nhap == '1'){
	echo $trang."=> ".$xnhac."Đang Lấy Dữ Liệu Đã Lưu \n"; sleep (1);
} else {
	@system('rm cookiettc.txt');
	@system('rm listids.txt');
	@system('rm listnames.txt');
	echo chay(10);
}
}
if (!file_exists('cookiettc.txt')){
	$x = 0;
echo $BYellow."Nhập Cookie Facebook Nếu Muốn Dừng Bấm Xuống Hàng Nhé\n";
echo chay(10);
    while (true) { $x++;
echo $lime."Nhập Cookie Facebook Thứ $x : $BWhite";
	$cookie = trim(fgets(STDIN));
	if ($cookie == '' ){ break; }
$access_token = laytoken($cookie);
if(json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))->{'id'}){
        $idfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))->{'id'};
        $name = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))->{'name'};
        array_push($khock, $cookie);
        array_push($list_id, $idfb);
		array_push($list_name, $name);
    } else {
        echo $do." Cookie Sai ! Vui Lòng Nhập Lại !!! \n"; $x--;
}
}
	$js=json_encode($khock);
            $demcki=count($khock);
            $k = fopen("cookiettc.txt","a+");
			fwrite($k, $js);
			fclose($k);
	$js=json_encode($list_id);
            $k = fopen("listids.txt","a+");
			fwrite($k, $js);
			fclose($k);
	$js=json_encode($list_name);
            $k = fopen("listnames.txt","a+");
			fwrite($k, $js);
			fclose($k);
}
	$khock = json_decode(fread(fopen("cookiettc.txt","r"),filesize("cookiettc.txt")),true);
	$list_id = json_decode(fread(fopen("listids.txt","r"),filesize("listids.txt")),true);
	$list_name = json_decode(fread(fopen("listnames.txt","r"),filesize("listnames.txt")),true);
$xu = coin($thanh_dep);
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen TOOL AUTO TTC COOKIE ĐA LUỒNG \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen Facebook : $BPurple 100047478314721 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen Thể Loại Tool Bạn Đang Chạy Là Tool: ".$BWhite."Cookie\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen Tài Khoản TTC Của Bạn Là: ".$BWhite.$user."\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen Số Xu Hiện Tại Của Bạn Là: ".$BWhite.$xu."\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen LIKE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen FOLLOW\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m3\033[1;31m]$BGreen COMMENTS\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m4\033[1;31m]$BGreen SHARE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m5\033[1;31m]$BGreen CẢM XÚC\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m6\033[1;31m]$BGreen CẢM XÚC CMT\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m7\033[1;31m]$BGreen PAGE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m8\033[1;31m]$BGreen THAM GIA GRUOPS\n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Có Thể Chọn Nhiều Nhiệm Vụ (Ví Dụ 2+4) \n";
echo chay(10);
while(true){
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Nhập Số Để Chạy Nhiệm Vụ: $BWhite";
$nhiemvu = trim(fgets(STDIN));
if($nhiemvu !== ''){ break;}
}
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Nhập Delay: $BWhite";
	$delay = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Sau ____ Nhiệm Vụ Thì Kích Hoạt Chống Block.     \r";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Sau $BWhite";
	$dungblock = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Sau ".$BWhite.$dungblock.$luc." Nhiệm Vụ Nghỉ Ngơi ____ Giây       \r";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Sau ".$BWhite.$dungblock.$luc." Nhiệm Vụ Nghỉ Ngơi $BWhite";
	$delaybl = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Đổi Nick: $BWhite";
	$chuyen = trim(fgets(STDIN));
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Sau Bao Nhiêu Nhiệm Vụ Thì Dừng Tool: $BWhite";
	$dungtool = trim(fgets(STDIN));
$dem = 0;
echo chay(10);
if (strpos($nhiemvu, '8') !== false) {
echo $do."[ CẢNH BÁO ]".$luc." Nhiệm Vụ Join Group Dễ Bị CheckPoint Tài Khoản, Hãy Cân Nhắc \n";
echo chay(10);
}
while(true) {
	if (count($khock) == 0 ){
		echo chay(10);
		@system('rm cookiettc.txt');
		@system('rm listids.txt');
		@system('rm listnames.txt');
        echo $do."Đã Xoá Tất Cả Cookie, Vui Lòng Nhập Lại  \n";
unset($x);
$list_id = [];
$list_name = [];
	while (true) { $x++;
echo $lime."Nhập Cookie Facebook Thứ $x: $BWhite";
	$cookie = trim(fgets(STDIN));
	if ($cookie == '' ){ break; }
$access_token = laytoken($cookie);
if(json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))->{'id'}){
        $idfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))->{'id'};
        $name = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))->{'name'};
        array_push($khock, $cookie);
        array_push($list_id, $idfb);
		array_push($list_name, $name);
    } else {
        echo $do." Cookie Sai ! Vui Lòng Nhập Lại !!! \n"; $x--;
}
}
	$js=json_encode($khock);
            $demcki=count($khock);
            $k = fopen("cookiettc.txt","a+");
			fwrite($k, $js);
			fclose($k);
	$js=json_encode($list_id);
            $k = fopen("listids.txt","a+");
			fwrite($k, $js);
			fclose($k);
	$js=json_encode($list_name);
            $k = fopen("listnames.txt","a+");
			fwrite($k, $js);
			fclose($k);
echo chay(10);
}
for ($tr = 0; $tr < count($khock) ; $tr++){
	$cookie = $khock[$tr];
	$access_token = laytoken($cookie);
	$idfb = $list_id[$tr];
	$name = $list_name[$tr];
    $datnick = cauhinh($idfb);
if($datnick == '1') {
	echo $BWhite."Đang Cấu Hình ID: ".$luc.$idfb."\n";
} else {
     echo $do." Cấu Hình Thất Bại, Vui Lòng Thêm Nick $name Vào Cấu Hình \r"; continue;
}
$stool = 0;
while (true){
if($stool == 1){ break; }
if (strpos($nhiemvu, '1') !== false) { $nvlike = 1; }
if (strpos($nhiemvu, '2') !== false) { $nvsub = 1; }
if (strpos($nhiemvu, '3') !== false) { $nvcmt = 1; }
if (strpos($nhiemvu, '4') !== false) { $nvshare = 1; }
if (strpos($nhiemvu, '5') !== false) { $nvcx = 1; }
if (strpos($nhiemvu, '6') !== false) { $nvcxcmt = 1; }
if (strpos($nhiemvu, '7') !== false) { $nvpage = 1; }
if (strpos($nhiemvu, '8') !== false) { $nvgr = 1; }
if($nvlike == 1){
	$listpost = getnv("");
	if(count($listpost) == 0){ $nvlike = 0; }
} else { $listpost = []; }
if($nvsub == 1){
	$listsub = getnv("/subcheo");
	if(count($listsub) == 0){ $nvsub = 0; }
} else { $listsub = []; }
if($nvcmt== 1){
	$listcmt = getnv("/cmtcheo");
	if(count($listcmt) == 0){ $nvcmt = 0; }
} else { $listcmt = []; }
if($nvshare == 1){
	$listshare= getnv("/sharecheo");
	if(count($listshare) == 0){ $nvshare = 0; }
} else { $listcmt = []; }
if($nvcx == 1){
	$listcx = getnv("/camxuccheo");
	if(count($listcx) == 0){ $nvcx = 0; }
} else { $listcx = []; }
if($nvcxcmt== 1){
	$listcxcmt = getnv("/camxuccheobinhluan");
	if(count($listcxcmt) == 0){ $nvcxcmt = 0; }
} else { $listcxcmt = []; }
if($nvpage== 1){
	$listpage = getnv("/likepagecheo");
	if(count($listpage) == 0){ $nvpage = 0; }
} else { $listpage = []; }
if($nvgr == 1){
	$listgr = getnv("/thamgianhomcheo");
	if(count($listgr) == 0){ $nvgr = 0; }
} else { $listgr = []; }
if(($nvlike + $nvsub + $nvcmt + $nvshare + $nvcx + $nvcxcmt + $nvpage + $nvgr) == 0){
	for ($i = 10; $i > 0; $i--) { echo "\033[1;37m Tất Cả Các Nhiệm Vụ Đã Hết, Vui Lòng Chờ $i giây"; sleep(1); echo "\r                                                     \r"; }
	continue;
}
for($lap = 0; $lap < count(max($listpost, $listsub, $listcmt, $listcx, $listcxcmt, $listpage, $listgr)); $lap++){
 if($nvlike == 1){
            $id = $listpost[$lap]["idpost"];
			if (isset($id)){
            $g = camxuc($id, 'LIKE', $cookie);
            if (strpos ($g[2], 'Tài khoản của bạn hiện bị hạn chế') !== false){
                echo $do." Tài Khoản $name Đã Bị Block Like !!!					\n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
            if(strpos ($g[1], 'Đăng nhập') !== false){
                echo $do."  Cookie Tài Khoản $name Đã Bị Out !!!                \n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
            $hoanthanh = nhantien($id, "");
			$xu = coin($thanh_dep);
   if (strlen($hoanthanh["mess"]) > 27){  
         $dem++;
         $xujob = "+300";
	hoanthanh($dem, ' LIKE ', $id, $xujob, $xu);
	if($dem >= $dungtool){
		echo chay(10);
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Có Muốn Tiếp Tục Không (y/n): $BWhite";
			$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Thực Hiện Thêm Bao Nhiêu Nhiệm Vụ Nữa: $BWhite";
			$them = trim(fgets(STDIN));
			$dungtool = $dungtool + $them;
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Muốn Nhập Cookie Mới Không (y/n): $BWhite";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { 
				$khock = []; $stool = 1; break; 
			} else {
				echo chay(10);
				$stool = 1; break;
			}
	} else {
		exit($luc." Cảm Ơn Bạn Đã Sử Dụng Tool By ".$xnhac."LVB \n"); 
	} 
	}
  	if ($dem % $chuyen == 0 ) { $stool = 1; break; }
    if ( $dem % $dungblock == 0 ){ delaybl($delaybl); }
			else { delay($delay); }
 		    } 
   	  		}
 } 
if ($nvsub == 1){
            $id = $listsub[$lap]["idpost"];
            if (isset($id)){
           $g = follow($access_token,$id);
            if ($g->{'error'}->{'code'} == 368 and $g->{'error'}->{'error_subcode'} == 1404078){
                echo $do." Tài Khoản $name Đã Bị Block Follow !!!		\n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
            if ($g->{'error'}->{'code'} == 190){
                echo $do."  Cookie Tài Khoản $name Đã Bị Out !!!                \n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
            $hoanthanh = nhantien($id, "/subcheo");
            $xu = coin($thanh_dep);
            if ($hoanthanh["mess"]) {
            $dem++;
            $xujob = "+600";
            $id = substr($id, 0, 15);
hoanthanh($dem, 'FOLLOW', $id, $xujob, $xu);
if($dem >= $dungtool){
		echo chay(10);
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Có Muốn Tiếp Tục Không (y/n): $BWhite";
			$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Thực Hiện Thêm Bao Nhiêu Nhiệm Vụ Nữa: $BWhite";
			$them = trim(fgets(STDIN));
			$dungtool = $dungtool + $them;
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Muốn Nhập Cookie Mới Không (y/n): $BWhite";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { 
				$khock = []; $stool = 1; break; 
			} else {
				echo chay(10);
				$stool = 1; break;
			}
	} else {
		exit($luc." Cảm Ơn Bạn Đã Sử Dụng Tool By ".$xnhac."LVB \n"); 
	} 
	}
 	if ($dem % $chuyen == 0 ) { $stool = 1; break; }
   if ( $dem % $dungblock == 0 ){ delaybl($delaybl); } else { delay($delay); }
            } 
				}
} 
if ($nvcmt == 1) {
            $id = $listcmt[$lap]["idpost"];
            $nd = $listcmt[$lap]["nd"];
            $json = json_decode($nd, true);
            $msg = $json["0"];
            if (isset($id)){
         $g = cmt($access_token,$id,$msg);
           if ($g->{'error'}->{'code'} == 368 and $g->{'error'}->{'error_subcode'} == 1404078){
                echo $do." Tài Khoản $name Đã Bị Block Comment !!!		\n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
            if ($g->{'error'}->{'code'} == 190){
                echo $do."  Cookie Tài Khoản $name Đã Bị Out !!!                \n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
            $hoanthanh = nhantien($id, "/cmtcheo");
            $xu = coin($thanh_dep);
            if ($hoanthanh["mess"]) {
            $dem++;
            $xujob = "+600";
  hoanthanh($dem, 'COMMENT', $id, $xujob, $xu);
  if($dem >= $dungtool){
		echo chay(10);
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Có Muốn Tiếp Tục Không (y/n): $BWhite";
			$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Thực Hiện Thêm Bao Nhiêu Nhiệm Vụ Nữa: $BWhite";
			$them = trim(fgets(STDIN));
			$dungtool = $dungtool + $them;
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Muốn Nhập Cookie Mới Không (y/n): $BWhite";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { 
				$khock = []; $stool = 1; break; 
			} else {
				echo chay(10);
				$stool = 1; break;
			}
	} else {
		exit($luc." Cảm Ơn Bạn Đã Sử Dụng Tool By ".$xnhac."LVB \n"); 
	} 
	}
 	if ($dem % $chuyen == 0 ) { $stool = 1; break; }
if ( $dem % $dungblock == 0 ){ delaybl($delaybl); } else { delay($delay); }
            } 
                  }
} 
if ($nvshare == 1) {
            $id = $listshare[$lap]["idpost"];
            if (isset($id)){
         $g = share($id,$access_token);
           if ($g->{'error'}->{'code'} == 368 and $g->{'error'}->{'error_subcode'} == 1404078){
                echo $do." Tài Khoản $name Đã Bị Block Share !!!		\n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
            if ($g->{'error'}->{'code'} == 190){
                echo $do."  Cookie Tài Khoản $name Đã Bị Out !!!                \n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
            $hoanthanh = nhantien($id, "/sharecheo");
            $xu = coin($thanh_dep);
            if ($hoanthanh["mess"]) {
            $dem++;
            $xujob = "+600";
            $id = substr($id, 0, 15);
  hoanthanh($dem, 'SHARE ', $id, $xujob, $xu);
  if($dem >= $dungtool){
		echo chay(10);
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Có Muốn Tiếp Tục Không (y/n): $BWhite";
			$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Thực Hiện Thêm Bao Nhiêu Nhiệm Vụ Nữa: $BWhite";
			$them = trim(fgets(STDIN));
			$dungtool = $dungtool + $them;
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Muốn Nhập Cookie Mới Không (y/n): $BWhite";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { 
				$khock = []; $stool = 1; break; 
			} else {
				echo chay(10);
				$stool = 1; break;
			}
	} else {
		exit($luc." Cảm Ơn Bạn Đã Sử Dụng Tool By ".$xnhac."LVB \n"); 
	} 
	}
 	if ($dem % $chuyen == 0 ) { $stool = 1; break; }
if ( $dem % $dungblock == 0 ){ delaybl($delaybl); } else { delay($delay); }
            } 
                  }
} 
if ($nvcx == 1) {
			$idcx = $listcx[$lap]["idpost"];
			$type = $listcx[$lap]["loaicx"];
			if ( $idcx !== '' and isset($idcx)){
			$g = camxuc($idcx, $type, $cookie);
			if(strpos ($g[1], 'Đăng nhập') !== false){
				echo $do."  Cookie Tài Khoản $name Đã Bị Out !!!                \n";
                array_splice($khock, $tr, 1); $stool = 1; break;
            }
		$hoanthanh = nhantiencx($idcx, $type);
            $xu = coin($thanh_dep);
            if ($hoanthanh["mess"]) {
            $dem++;
            $xujob = "+400";
  hoanthanh($dem, ' '.$type.' ', $idcx, $xujob, $xu);
  if($dem >= $dungtool){
		echo chay(10);
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Có Muốn Tiếp Tục Không (y/n): $BWhite";
			$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Thực Hiện Thêm Bao Nhiêu Nhiệm Vụ Nữa: $BWhite";
			$them = trim(fgets(STDIN));
			$dungtool = $dungtool + $them;
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Muốn Nhập Cookie Mới Không (y/n): $BWhite";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { 
				$khock = []; $stool = 1; break; 
			} else {
				echo chay(10);
				$stool = 1; break;
			}
	} else {
		exit($luc." Cảm Ơn Bạn Đã Sử Dụng Tool By ".$xnhac."LVB \n"); 
	} 
	}
   	if ($dem % $chuyen == 0 ) { $stool = 1; break; }
if ( $dem % $dungblock == 0 ){ delaybl($delaybl); } else { delay($delay); }
            } 
                  }
}
if ($nvcxcmt == 1) {
			$idcxcmt = $listcxcmt[$lap]["idpost"];
			$type = $listcxcmt[$lap]["loaicx"];
			if ( $idcxcmt !== '' and isset($idcxcmt)){
				if ( $type == 'LIKE' ){
					$g = like($access_token,$idcxcmt);
					if ($g->{'error'}->{'code'} == 368 and $g->{'error'}->{'error_subcode'} == 1404078){
               		 echo $do." Tài Khoản $name Đã Bị Block Like Comment !!!		\n";
                		array_splice($khock, $tr, 1); $stool = 1; break;
            		}
            		if ($g->{'error'}->{'code'} == 190){
                		echo $do."  Cookie Tài Khoản $name Đã Bị Out !!!                \n";
                		array_splice($khock, $tr, 1); $stool = 1; break;
            		}
				} else {
					$g = camxuc($idcxcmt, $type, $cookie);
					if(strpos ($g[1], 'Đăng nhập') !== false){
						echo $do."  Cookie Tài Khoản $name Đã Bị Out !!!                \n";
                		array_splice($khock, $tr, 1); $stool = 1; break;
					}
				}
		$hoanthanh = nhantiencxcmt($idcxcmt, $type);
            $xu = coin($thanh_dep);
            if (strlen($hoanthanh["mess"]) > 27){
            $dem++;
            $xujob = "+600";
  hoanthanh($dem, $type.' COMMENT', $idcxcmt, $xujob, $xu);
  if($dem >= $dungtool){
		echo chay(10);
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Có Muốn Tiếp Tục Không (y/n): $BWhite";
			$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Thực Hiện Thêm Bao Nhiêu Nhiệm Vụ Nữa: $BWhite";
			$them = trim(fgets(STDIN));
			$dungtool = $dungtool + $them;
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Muốn Nhập Cookie Mới Không (y/n): $BWhite";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { 
				$khock = []; $stool = 1; break; 
			} else {
				echo chay(10);
				$stool = 1; break;
			}
	} else {
		exit($luc." Cảm Ơn Bạn Đã Sử Dụng Tool By ".$xnhac."LVB \n"); 
	} 
	}
   	if ($dem % $chuyen == 0 ) { break; }
if ( $dem % $dungblock == 0 ){ delaybl($delaybl); } else { delay($delay); }
            } 
                  }
}
if ($nvpage == 1) {
            $id = $listpage[$lap]["idpost"];
            if ( $id !== '' and isset($id)){
				$g = page($id,$cookie);
				if(strpos ($g, 'Đăng nhập') !== false){
					echo $do."  Cookie Tài Khoản $name Đã Bị Out !!!                \n";
                	array_splice($khock, $tr, 1); $stool = 1; break;
            	}
            $hoanthanh = nhantien($id,"/likepagecheo");
            $xu = coin($thanh_dep);
            if ($hoanthanh["mess"]) {
            $dem++;
            $xujob = "+700";
  hoanthanh($dem, ' PAGE ', $id, $xujob, $xu);
  if($dem >= $dungtool){
		echo chay(10);
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Có Muốn Tiếp Tục Không (y/n): $BWhite";
			$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Thực Hiện Thêm Bao Nhiêu Nhiệm Vụ Nữa: $BWhite";
			$them = trim(fgets(STDIN));
			$dungtool = $dungtool + $them;
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Muốn Nhập Cookie Mới Không (y/n): $BWhite";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { 
				$khock = []; $stool = 1; break; 
			} else {
				echo chay(10);
				$stool = 1; break;
			}
	} else {
		exit($luc." Cảm Ơn Bạn Đã Sử Dụng Tool By ".$xnhac."LVB \n"); 
	} 
	}
   	if ($dem % $chuyen == 0 ) { $stool = 1; break; }
if ( $dem % $dungblock == 0 ){ delaybl($delaybl); } else { delay($delay); }
            } 
                  }
}
if ($nvgr== 1) {
            $id = $listgr[$lap]["idpost"];
            if ( $id !== '' and isset($id)){
                $g = group($id,$cookie);
				if($g["code"] == 368){
					echo $do." Tài Khoản $name Đã Bị Block Tính Năng Join Group !!!		\n";
				}
            $hoanthanh = nhantien($id,"/thamgianhomcheo");
            $xu = coin($thanh_dep);
            if ($hoanthanh["mess"]) {
            $dem++;
            $xujob = "+1200";
  hoanthanh($dem, 'GROUP', $id, $xujob, $xu);
  if($dem >= $dungtool){
		echo chay(10);
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Có Muốn Tiếp Tục Không (y/n): $BWhite";
			$nhap_stop = trim(fgets(STDIN));
	if ( strtolower($nhap_stop) == 'y'){
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Thực Hiện Thêm Bao Nhiêu Nhiệm Vụ Nữa: $BWhite";
			$them = trim(fgets(STDIN));
			$dungtool = $dungtool + $them;
		echo $lime."\033[1;37m~\033[1;31m[\033[1;32m🍬\033[1;31m]$white =>$lime  Bạn Muốn Nhập Cookie Mới Không (y/n): $BWhite";
			$nhap_ck = trim(fgets(STDIN));
			if (strtolower($nhap_ck) == 'y') { 
				$khock = []; $stool = 1; break; 
			} else {
				echo chay(10);
				$stool = 1; break;
			}
	} else {
		exit($luc." Cảm Ơn Bạn Đã Sử Dụng Tool By ".$xnhac."LVB \n"); 
	} 
	}
   	if ($dem % $chuyen == 0 ) { $stool = 1; break; }
if ( $dem % $dungblock == 0 ){ delaybl($delaybl); } else { delay($delay); }
            } else { sleep(1); }
				}
}
} 
}
}
}
/*** #####################[ FUNCTION ]#################### ***/
function cauhinh($idfb){
    $url = "https://tuongtaccheo.com/cauhinh/datnick.php";
    $data = "iddat[]=".$idfb."&loai=fb";
    $head = array(
"Host: tuongtaccheo.com",
"content-length: ".strlen($data),
"accept: */*",
"origin: https://tuongtaccheo.com",
"x-requested-with: XMLHttpRequest",
"user-agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
"content-type: application/x-www-form-urlencoded; charset=UTF-8",
"referer: https://tuongtaccheo.com/cauhinh/index.php"
);
    $ch = curl_init();
    curl_setopt_array($ch, array(
	CURLOPT_URL => $url,
	CURLOPT_FOLLOWLOCATION => TRUE,
	CURLOPT_RETURNTRANSFER => 1,
	CURLOPT_POST => 1,
	CURLOPT_POSTFIELDS => $data,
	CURLOPT_SSL_VERIFYPEER => 0,
	CURLOPT_COOKIE => $_SESSION['cookie_web'],
	CURLOPT_HTTPHEADER => $head,
	CURLOPT_ENCODING => TRUE
));
    return curl_exec($ch);
}
function getnv($type){
    $url  = "https://tuongtaccheo.com/kiemtien".$type."/getpost.php";
    $head = array(
        "Host: tuongtaccheo.com",
        "accept: application/json, text/javascript, *" . "/" . "*; q=0.01",
        "x-requested-with: XMLHttpRequest",
        "user-agent: Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
        "referer: https://tuongtaccheo.com/kiemtien/".$type
    );
    $ch   = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_FOLLOWLOCATION => TRUE,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_HTTPGET => true,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_COOKIE => $_SESSION['cookie_web'],
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_ENCODING => TRUE
    ));
    $data = json_decode(curl_exec($ch), true);
    return $data;
}
function nhantien($id,$type){
    $url  = "https://tuongtaccheo.com/kiemtien".$type."/nhantien.php";
    $data = "id=".$id;
	$head = array(
        "Host: tuongtaccheo.com",
        "content-length: " . strlen($data),
        "x-requested-with: XMLHttpRequest",
        "user-agent: Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
        "content-type: application/x-www-form-urlencoded; charset=UTF-8",
        "origin: https://tuongtaccheo.com",
        "referer: https://tuongtaccheo.com/kiemtien".$type
    );
    $ch   = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_FOLLOWLOCATION => TRUE,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_COOKIE => $_SESSION['cookie_web'],
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_ENCODING => TRUE
    ));
    $a = json_decode(curl_exec($ch), true);
    return $a;
}
function nhantiencx($id,$type){
    $url  = "https://tuongtaccheo.com/kiemtien/camxuccheo/nhantien.php";
    $data = "id=".$id."&loaicx=".$type;
    $head = array(
        "Host: tuongtaccheo.com",
        "content-length: " . strlen($data),
        "x-requested-with: XMLHttpRequest",
        "user-agent: Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
        "content-type: application/x-www-form-urlencoded; charset=UTF-8",
        "origin: https://tuongtaccheo.com",
        "referer: https://tuongtaccheo.com/kiemtien/camxuccheo"
    );
    $ch   = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_FOLLOWLOCATION => TRUE,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_COOKIE => $_SESSION['cookie_web'],
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_ENCODING => TRUE
    ));
    $a = json_decode(curl_exec($ch), true);
    return $a;
}
function nhantiencxcmt($id,$type){
    $url  = "https://tuongtaccheo.com/kiemtien/camxuccheobinhluan/nhantien.php";
    $data = "id=".$id."&loaicx=".$type;
	$head = array(
        "Host: tuongtaccheo.com",
        "content-length: " . strlen($data),
        "x-requested-with: XMLHttpRequest",
        "user-agent: Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
        "content-type: application/x-www-form-urlencoded; charset=UTF-8",
        "origin: https://tuongtaccheo.com",
        "referer: https://tuongtaccheo.com/kiemtien/camxuccheobinhluan"
    );
    $ch   = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_FOLLOWLOCATION => TRUE,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_COOKIE => $_SESSION['cookie_web'],
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_ENCODING => TRUE
    ));
    $a = json_decode(curl_exec($ch), true);
    return $a;
}
function coin($thanh_dep){
	while (true){
	$ch = curl_init();
curl_setopt_array($ch, array(
	CURLOPT_URL => 'https://tuongtaccheo.com/home.php',
	CURLOPT_PORT => "443",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_SSL_VERIFYPEER => true,
	CURLOPT_CUSTOMREQUEST => "GET",
	CURLOPT_COOKIE => $_SESSION['cookie_web']
  ));
$access = curl_exec($ch);
curl_close($ch);
$xu = explode('"soduchinh">', explode('</strong>', $access)[0])[1];
if (strpos ($access, "Chào mừng") == false){
	continue;
} else if ($xu !== ''){
	return $xu;
} else {
	echo "\033[1;31m Lỗi Không Xác Định                  \r";
}
}
}
function follow($access_token,$id){
        $ch=curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/subscribers');
        $head[] = "Connection: keep-alive";
        $head[] = "Keep-Alive: 300";
        $head[] = "authority: m.facebook.com";
        $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
        $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
        $head[] = "cache-control: max-age=0";
        $head[] = "upgrade-insecure-requests: 1";
        $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
        $head[] = "sec-fetch-site: none";
        $head[] = "sec-fetch-mode: navigate";
        $head[] = "sec-fetch-user: ?1";
        $head[] = "sec-fetch-dest: document";
        curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
        $data = array('access_token' => $access_token);
        curl_setopt($ch, CURLOPT_POST,count($data));
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        $access = curl_exec($ch);
        curl_close($ch);
        return json_decode($access);
}
function like($access_token,$id){
        $ch=curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/likes');
        $head[] = "Connection: keep-alive";
        $head[] = "Keep-Alive: 300";
        $head[] = "authority: m.facebook.com";
        $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
        $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
        $head[] = "cache-control: max-age=0";
        $head[] = "upgrade-insecure-requests: 1";
        $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
        $head[] = "sec-fetch-site: none";
        $head[] = "sec-fetch-mode: navigate";
        $head[] = "sec-fetch-user: ?1";
        $head[] = "sec-fetch-dest: document";
        curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
        $data = array('access_token' => $access_token);
        curl_setopt($ch, CURLOPT_POST,count($data));
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        $access = curl_exec($ch);
        curl_close($ch);
        return json_decode($access);
}
function cmt($access_token, $id, $msg){
        $ch=curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/comments');
        $head[] = "Connection: keep-alive";
        $head[] = "Keep-Alive: 300";
        $head[] = "authority: m.facebook.com";
        $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
        $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
        $head[] = "cache-control: max-age=0";
        $head[] = "upgrade-insecure-requests: 1";
        $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
        $head[] = "sec-fetch-site: none";
        $head[] = "sec-fetch-mode: navigate";
        $head[] = "sec-fetch-user: ?1";
        $head[] = "sec-fetch-dest: document";
        curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
        $data = array('message' => $msg,'access_token' => $access_token);
        curl_setopt($ch, CURLOPT_POST,count($data));
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        $access = curl_exec($ch);
        curl_close($ch);
        return json_decode($access);
}
function share($id,$access_token) {
   $ch=curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/v2.0/me/feed');
curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
$data = array(
'privacy' => '{"value":"EVERYONE"}',
'message' => '',
'link' => 'https://mbasic.facebook.com/'.$id.'',
'access_token' => $access_token
);
curl_setopt($ch, CURLOPT_POST,count($data));
curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
$a = json_decode(curl_exec($ch), true);                                    
curl_close($ch);
   return $a;
}
function camxuc($idcx, $type, $cookie) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/reactions/picker/?is_permalink=1&ft_id='.$idcx);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
    :'));
    $cx = curl_exec($ch);
    $haha = explode('<a href="', $cx);
    if ($type == 'LIKE') {
        $haha2 = explode('" style="display:block"', $haha[1])[0];
    } else if ($type == 'LOVE') {
        $haha2 = explode('" style="display:block"', $haha[2])[0];
    } else if ($type == 'WOW') {
        $haha2 = explode('" style="display:block"', $haha[5])[0];
    }else if ($type == 'CARE') {
        $haha2 = explode('" style="display:block"', $haha[3])[0];
    } else if ($type == 'HAHA') {
        $haha2 = explode('" style="display:block"', $haha[4])[0];
    } else if ($type == 'SAD') {
        $haha2 = explode('" style="display:block"', $haha[6])[0];
    } else {
        $haha2 = explode('" style="display:block"', $haha[7])[0];
    }
    $link2 = html_entity_decode($haha2);
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com'.$link2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $access = curl_exec($ch);
    curl_close($ch);
    return array($cx, $access);
}
function group ($id, $cookie){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://stoolnopro.com/admin/api/group.php?id='.$id.'&cookie='.$cookie);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36';
    $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
    $headers[] = 'Accept-Language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    $send = json_decode(curl_exec($ch), true);
    curl_close($ch);
    return $send;
}
function page($id,$cookie){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/'.$id);
        $head[] = "Connection: keep-alive";
        $head[] = "Keep-Alive: 300";
        $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
        $head[] = "Accept-Language: en-us,en;q=0.5";
        curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
        :'));
        $page = curl_exec($ch);
        if (explode('&amp;refid=',explode('pageSuggestionsOnLiking=1&amp;gfid=',$page)[1])[0]){
                $get = explode('&amp;refid=',explode('pageSuggestionsOnLiking=1&amp;gfid=',$page)[1])[0];
                $link = 'https://mbasic.facebook.com/a/profile.php?fan&id='.$id.'&origin=page_profile&pageSuggestionsOnLiking=1&gfid='.$get.'&refid=17';
                curl_setopt($ch, CURLOPT_URL, $link);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_exec($ch);
        }
        curl_close($ch);
        return $page;
}
function laytoken($cookie){
$ch=curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
$head[] = "Connection: keep-alive";
$head[] = "Keep-Alive: 300";
$head[] = "authority: m.facebook.com";
$head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
$head[] = "cache-control: max-age=0";
$head[] = "upgrade-insecure-requests: 1";
$head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
$head[] = "sec-fetch-site: none";
$head[] = "sec-fetch-mode: navigate";
$head[] = "sec-fetch-user: ?1";
$head[] = "sec-fetch-dest: document";
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
$access = curl_exec($ch);
curl_close($ch);
if (explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0]){
$access_token = explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0];
return $access_token; }
 else { return "2"; }
}
function hoanthanh($dem, $loai, $id, $xujob, $xu){
date_default_timezone_set( 'Asia/Ho_Chi_Minh' );
$kl = "\e[1;32m⌠\e[1;33mLVB\e[1;32m⌡\e[1;35m❯\e[1;36m❯\e[1;31m❯\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i:s")."\033[1;31m 🍬 \033[1;".rand(31,37)."m".$loai."\033[1;31m 🍬 \033[1;32m".$id."\033[1;31m 🍬 \033[1;32m$xujob \033[1;31m🍬\033[1;33m $xu \n";
for($i = 0; $i < strlen($kl); $i++){echo $kl[$i];usleep(1500);}
}
function delay ($delay){
	for($tt = $delay ;$tt>= 1;$tt--){
        echo "\r\033[1;33m   LVB \033[1;31m ~>       \033[1;32m LO      \033[1;31m | $tt | "; usleep(150000);
        echo "\r\033[1;31m   LVB \033[0;33m   ~>     \033[0;37m LOA     \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;32m   LVB \033[0;33m     ~>   \033[0;37m LOAD    \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;34m   LVB \033[0;33m       ~> \033[0;37m LOADI   \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADIN  \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADING \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADING.\033[0;31m | $tt | ";usleep(150000);} 
echo "\r\e[1;95m    ⚡LÊ VĂN BÌNH⚡                       \r"; 
}
function delaybl($delaybl) {
for ($time = $delaybl; $time > -0; $time--) {echo "\r"; 
	echo "\r\033[1;97m Đang hoạt động chống block sẽ chạy lại sau $time giây"; sleep(1); echo "\r                                                       \r"; 
}}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}