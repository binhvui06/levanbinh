error_reporting(0);
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$res="\033[0m";
$red="\033[1;31m";
$white= "\033[1;37m";
$whiteb= "\033[1;37m";
$redb="\033[1;31m";
$green="\033[1;32m";
$yellow="\033[1;33m";
$cam="\033[1;33m";
$test="\033[1;33m";
$greenb="\033[1;32m";
$blue="\033[1;34m";
$lam="\033[1;34m";
$tmi="\033[1;34m";
$hong="\033[1;35m";
$imt="\033[1;35m";
$cyan= "\e[1;36m";
$syan="\033[1;36m";
$xnhac= "\033[1;96m";
$den="\033[1;90m";
$do="\033[1;91m";
$luc="\033[1;92m";
$vang="\033[1;93m";
$xduong="\033[1;94m";
$hong="\033[1;95m";
$trang="\033[1;97m";
$vang="\033[1;93m";
$do="\033[1;91m";
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$BCyan="\033[1;36m";
$trang="\033[1;37m";
$do="\033[1;31m";
$luc="\033[1;32m";
$vang="\033[1;33m";
$luc="\033[1;92m";
@system("clear");
echo chay(10);
echo "$BGreen Nhập Cookie Facebook: $BWhite";
    $cookie = trim(fgets(STDIN));
@system("clear");
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO THÊM BẠN BÈ FACEBOOK \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BYellow Lưu ý : Phải có bạn bè nhé \n";
echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$lime Nhập Delay : $BWhite";
    $a = trim(fgets(STDIN));

echo chay(10);
    while (true) {
        $url = "https://mbasic.facebook.com/";
$head = array(
            "Host: mbasic.facebook.com",
            "upgrade-insecure-requests: 1",
            "save-data: on",
            "user-agent: Mozilla/5.0 (Linux; Android 5.1.1; SM-J320G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36",
            "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*" . "/" . "*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "sec-fetch-site: same-origin",
            "sec-fetch-mode: navigate",
            "sec-fetch-user: ?1",
            "sec-fetch-dest: document",
            "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
            "cookie: $cookie",
        );
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_POST => 1,
            CURLOPT_HTTPGET => true,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTPHEADER => $head,
            CURLOPT_HEADER => true,
            CURLOPT_ENCODING => TRUE
        ));
        $c = curl_exec($ch);
        $one = explode('href="/friends/center/mbasic/?', $c);
        $two = explode('"', $one[1]);
        $url = "https://mbasic.facebook.com/friends/center/?" . htmlspecialchars_decode($two[0]);
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_POST => 1,
            CURLOPT_HTTPGET => true,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTPHEADER => $head,
            CURLOPT_HEADER => true,
            CURLOPT_ENCODING => TRUE
        ));
        $c = curl_exec($ch);
        $one = explode('href="/a/mobile/friends/add_friend.php?', $c);
        $kb = explode('"', $one[1]);
        $url = "https://mbasic.facebook.com/a/mobile/friends/add_friend.php?" . htmlspecialchars_decode($kb[0]);
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_POST => 1,
            CURLOPT_HTTPGET => true,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTPHEADER => $head,
            CURLOPT_HEADER => true,
            CURLOPT_ENCODING => TRUE
        ));
        $c = curl_exec($ch);
        $id = explode('id=', $kb[0])[1];
        $id = explode('&', $id)[0];
$so++;
echo $BCyan."[$so]$BRed ●$BGreen Đã Thêm ID $BRed ●$BYellow $id \n";
for ($i=$a;$i>-1;$i--){
echo $BGreen."Vui lòng chờ $i Giây \r";
sleep(1);}
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}
