error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
echo chay(10);
echo $BGreen."Nhập Cookie Qlizz Intgram : $BWhite";
$cookie =trim(fgets(STDIN));
echo $BGreen."Nhập Tên Cần Buff Follow Intagram : $BWhite";
$ten =trim(fgets(STDIN));
@system('clear');
// Get id video
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BWhite =>$BGreen TOOL AUTO TĂNG FOLLOW INTGRAM \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BWhite =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Bản Quyền : $yellow http://www.toolautoapk.com/ \n";
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$Blue Website key tool vip + mail cổ tự động : $yellow https://shopmailco.tk/ \n";
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Website tương tác facebook : $yellow https://tuongtacdao.com/ \n";
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$BWhite =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
chay(10);

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "https://instagram.qlizz.com/",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_HTTPHEADER => array(
"Host:instagram.qlizz.com",
"x-requested-with:XMLHttpRequest",
"user-agent:Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.1.4389.226 Safari/537.36",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"cookie:$cookie",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$_token = explode('<input type="hidden" name="_token" value="',$mr2)[1];
$_token = explode('">',$_token)[0];

$url = "https://instagram.qlizz.com/send";

$data = '_token='.$_token.'&link='.$ten.'&tool=autofollowers';

$mr = curl_init();
curl_setopt_array($mr, array(
CURLOPT_PORT => "443",
CURLOPT_URL => "$url",
CURLOPT_ENCODING => "",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_TIMEOUT => 30,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => $data,
CURLOPT_HTTPHEADER => array(
"Host:instagram.qlizz.com",
"x-requested-with:XMLHttpRequest",
"user-agent:Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.1.4389.226 Safari/537.36",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://instagram.qlizz.com",
"referer:https://instagram.qlizz.com/autofollowers",
"cookie:$cookie",
)));
$mr2 = curl_exec($mr); curl_close($mr);
$json = json_decode($mr2,true);
if ($mr2 == "Your post is successfully added for free 10 followers. You will get followers in within 1 hour."){
  $dem++;
  echo $BCyan."[$dem]$BRed ★$BGreen Thành Công +10 Theo Dõi              \n";
}else{
echo $BRed."Chưa Đủ 1 Tiếng Để Tăng Vui Lòng Đợi \r";
  sleep(2);
  echo "                                               \r";
}
$so = 3600;
delay($so);
function delay($time){
for ($time=$time;$time>-10;$time--){
echo $BPurple."Vui lòng chờ$green $time  giây       \r";
sleep(1);
}
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}