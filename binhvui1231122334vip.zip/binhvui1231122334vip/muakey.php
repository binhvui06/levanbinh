error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
$useragent ="Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36";
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO SHOPMAILCO.TK \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen Đăng Ký Tài Khoản\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen Đăng Nhập \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập Chế Độ : $BWhite ";
$nhap = trim(fgets(STDIN));
if ($nhap == '1'){
echo chay(10);
echo $BGreen."Nhập Tài Khoản : $BWhite";
$ttk =trim(fgets(STDIN));
echo $BGreen."Nhập Email : $BWhite";
$email =trim(fgets(STDIN));
echo $BGreen."Nhập Mật Khẩu : $BWhite";
$mmk =trim(fgets(STDIN));
// tạo tk
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"Origin:https://shopmailco.tk",
"Content-Type:application/x-www-form-urlencoded",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/register/",
);
$data = 'username='.$ttk.'&email='.$email.'&password='.$mmk.'&btnDangKy=%C4%90%C4%83ng+K%C3%BD';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/register/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);


$dk = explode('<script type="text/javascript">swal("', $mr2)[1];
$dk = explode('"', $dk)[0];
if($dk == 'Thành Công'){
echo $BYellow."Đăng ký tài khoản thành công \n";
}else{
echo $BRed."Đăng ký thất bại \n"; die;
}}
if ($nhap == '2'){
// login
// luu tk mk
if (file_exists("tkshopmailco.txt") == true ){
echo chay(10);
echo $BGreen."Nhập [1] Để Giữ Lại Tài Khoản \n";
echo $BGreen."Nhập [2] Để Nhập Tài Khoản Mới \n";
echo $BGreen."Nhập : $BWhite";
	$nhaptk = trim(fgets(STDIN));
		if ($nhaptk == '1'){
			$data = fread(fopen('tkshopmailco.txt', 'r'), filesize('tkshopmailco.txt'));
			$tk = explode('|', $data)[0];
			$mk = explode('|', $data)[1];
		}
else if ($nhaptk == '2'){
@system('rm tkshopmailco.txt');
} else { die; }








}
if (!file_exists("tkshopmailco.txt") == true ){
echo chay(10);
echo $BGreen."Nhập Tài Khoản : $BWhite";
$tk =trim(fgets(STDIN));
echo $BGreen."Nhập Mật Khẩu : $BWhite";
$mk =trim(fgets(STDIN));
$f = fopen('tkshopmailco.txt', 'a+');
$tkmk = $tk.'|'.$mk.'|';
fwrite ($f, $tkmk);
}
// login
$mr = curl_init();
$login = 'username='.$tk.'&password='.$mk.'&btnDangNhap=%C4%90%C4%83ng+Nh%E1%BA%ADp';
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/login/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEJAR, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $login);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr);
curl_close($mr);

$nhan = explode('</head><script type="text/javascript">swal("Thành Công","', $mr2)[1];
$nhan = explode('"', $nhan)[0];
if($nhan == 'Đăng nhập thành công!'){
echo $BCyan."Đăng nhập thành công! \n";
}else{
echo $BRed."Sai Tài Khoản Hoặc Mật Khẩu \n"; die;
}
// home
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/login/",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

$name = explode(' <span class="user-name">', $mr2)[1];
$name = explode('<', $name)[0];

$sd = explode('style="color:yellow;">', $mr2)[1];
$sd = explode('<', $sd)[0];
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO MUA KEY + MAIL SHOPMAILCO.TK \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Tài Khoản Của Bạn Là: ".$BWhite.$name."\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Số Dư Hiện Tại Của Bạn Là: ".$BWhite.$sd."\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen Mua Key ( $BYellow 500₫/1 ngày $BGreen )\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen Mua Mail Rediffmai ( $BYellow 200₫/1 mail $BGreen )\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m3\033[1;31m]$BGreen Mua Mail Yahoo Full info ( $BYellow 500₫/1 mail $BGreen ) \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m4\033[1;31m]$BGreen Mua Mail Yahoo Không Có info ( $BYellow 250₫/1 mail $BGreen )\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập Chế Độ : $BWhite ";
$chon =trim(fgets(STDIN));
echo chay(10);
if($chon == '1'){
echo $BGreen."Nhập Số Ngày ( ví dụ : 1 ) : $BWhite";
$ngay =trim(fgets(STDIN));
echo $BGreen."Nhập Key ( ví dụ : binhvui06 ) : $BWhite";
$key =trim(fgets(STDIN));
// mua key
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"Origin:https://shopmailco.tk",
"Content-Type:application/x-www-form-urlencoded",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/",
);
$data = 'time_line='.$ngay.'&api_key='.$key.'&submit=';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

$ok = explode('</div><script type="text/javascript">swal("Thành Công","', $mr2)[1];
$ok = explode('"', $ok)[0];
if($ok == 'TẠO API KEY THÀNH CÔNG'){
echo $BGreen."Tạo key thành công key của bạn là $BRed ★$BYellow $key \n";
}else{
echo $BRed."Tạo key thất bại vui lòng xem lại \n"; die;
}}
// mua Rediffmai
if($chon == '2'){
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"Origin:https://shopmailco.tk",
"Content-Type:application/x-www-form-urlencoded",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/",
);
$data = 'code=Rediffmai02&loai=yahoo&soluong='.$sl.'&btnBuy=';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$ma = explode('location.href = "/order/view/', $mr2)[1];
$ma = explode('/"', $ma)[0];

// nhận mail
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/order/view/'.$ma.'/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$mail = explode('<textarea id="copyClone" class="form-control" readonly="">', $mr2)[1];
$mail = explode('<', $mail)[0];
if($mail == ''){
echo $BRed."Hết Mail \n"; die;
}
echo $BGreen." $mail \n";
$f = fopen("rediffmail.txt","a");
$luu = fwrite($f,"\n$mail");
fclose($f);
echo $BYellow."Mail Đã Được Lưu Tại File : rediffmail.txt \n";
}}
// mua yahoo 
if($chon == '3'){
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"Origin:https://shopmailco.tk",
"Content-Type:application/x-www-form-urlencoded",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/",
);
$data = 'code=YAHOO&loai=yahoo&soluong='.$sl.'&btnBuy=';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$ma = explode('location.href = "/order/view/', $mr2)[1];
$ma = explode('/"', $ma)[0];

// nhận mail
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/order/view/'.$ma.'/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$mail = explode('<textarea id="copyClone" class="form-control" readonly="">', $mr2)[1];
$mail = explode('<', $mail)[0];
if($mail == ''){
echo $BRed."Hết Mail \n"; die;
}
echo $BGreen." $mail \n";
$f = fopen("yahoo.txt","a");
$luu = fwrite($f,"\n$mail");
fclose($f);
echo $BYellow."Mail Đã Được Lưu Tại File : yahoo.txt \n";
}
// mua yahoo không có info
if($chon == '4'){
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"Origin:https://shopmailco.tk",
"Content-Type:application/x-www-form-urlencoded",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/",
);
$data = 'code=YAHOO01&loai=yahoo&soluong='.$sl.'&btnBuy=';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$ma = explode('location.href = "/order/view/', $mr2)[1];
$ma = explode('/"', $ma)[0];

// nhận mail
$header = array( 
"Host:shopmailco.tk",
"Upgrade-Insecure-Requests:1",
"User-Agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"Referer:https://shopmailco.tk/",
);
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://shopmailco.tk/order/view/'.$ma.'/');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
$mail = explode('<textarea id="copyClone" class="form-control" readonly="">', $mr2)[1];
$mail = explode('<', $mail)[0];
if($mail == ''){
echo $BRed."Hết Mail \n"; die;
}
echo $BGreen." $mail \n";
$f = fopen("yahoonoinfo.txt","a");
$luu = fwrite($f,"\n$mail");
fclose($f);
echo $BYellow."Mail Đã Được Lưu Tại File : yahoonoinfo.txt \n";
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}