echo $BYellow."╔═══════════════════════════════════════╗\n";
echo $BYellow."║      $BCyan ██      ██    ██ ██████        $BYellow ║     \n";          
echo $BYellow."║$BGreen       ██      ██    ██ ██   ██       $BYellow ║      \n";           
echo $BYellow."║$BYellow       ██      ██    ██ ██████        $BYellow ║      \n";
echo $BYellow."║$BPurple       ██       ██  ██  ██   ██       $BYellow ║      \n";
echo $BYellow."║$BBlue       ███████   ████   ██████        $BYellow ║       \n"; 
echo $BYellow."╚═══════════════════════════════════════╝\n";