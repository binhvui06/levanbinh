error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
$useragent ="Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36";
echo chay(10);
echo $BGreen."Nhập Tài Khoản : $BWhite";
$tk =trim(fgets(STDIN));
echo $BGreen."Nhập Mật Khẩu : $BWhite";
$mk =trim(fgets(STDIN));
// login
$mr = curl_init();
$login = 'username='.$tk.'&password='.$mk.'';
curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/scr/login.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEJAR, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $login);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr);
curl_close($mr);

$dn = explode('success":', $mr2)[1];
$dn = explode('}', $dn)[0];
if($dn == 'true'){
echo $BCyan."Đăng nhập thành công \n";
}else{
echo $BRed."Sai tài khoản hoặc mật khẩu \n"; die;
}
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO TẶNG XU TDS \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo $BGreen."Nhập User Cần Tặng : $BWhite";
$user =trim(fgets(STDIN));
echo $BGreen."Nhập Số Xu Tặng : $BWhite";
$xu =trim(fgets(STDIN));
$tongxu= $xu + $xu * 10 / 100;
echo $BCyan." Tổng Xu : $BYellow $tongxu \n";
// tặng xu
$header = array( 
"Host:traodoisub.com",
"x-requested-with:XMLHttpRequest",
"user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://traodoisub.com",
"referer:https://traodoisub.com/view/tangxu/",
);
$data = 'usernhan='.$user.'&xutang='.$xu.'';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/view/tangxu/tangxu.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
echo $BGreen." $mr2 \n";
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}