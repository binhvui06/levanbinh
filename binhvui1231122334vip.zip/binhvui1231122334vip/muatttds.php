error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
$useragent ="Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/95.1.240 Mobile Chrome/89.1.4389.240 Mobile Safari/537.36";
@system('clear');
echo chay(10);
echo $BGreen."Nhập Tài Khoản : $BWhite";
$tk =trim(fgets(STDIN));
echo $BGreen."Nhập Mật Khẩu : $BWhite";
$mk =trim(fgets(STDIN));
// login
$mr = curl_init();
$login = 'username='.$tk.'&password='.$mk.'';
curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/scr/login.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEJAR, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $login);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr);
curl_close($mr);

$success = explode('success":', $mr2)[1];
$success = explode('}', $success)[0];

if($success == 'true'){
echo $BCyan."Đăng Nhập Thành Công \n";
}else{
echo $BRed."Tài khoản không chính xác \n"; die;
}
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO MUA TƯƠNG TÁC TDS \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m1\033[1;31m]$BGreen LIKE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m2\033[1;31m]$BGreen CẢM XÚC \n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m3\033[1;31m]$BGreen FOLLOW\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m4\033[1;31m]$BGreen COMMENTS\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m5\033[1;31m]$BGreen PAGE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m6\033[1;31m]$BGreen SHARE\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m7\033[1;31m]$BGreen SHARE ẢO\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m8\033[1;31m]$BGreen CẢM XÚC CMT\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m9\033[1;31m]$BGreen THAM GIA GRUOPS\n";
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập \033[1;31m[\033[1;32m10\033[1;31m]$BGreen VIEW STORY\n";
echo chay(10);
    echo $lime."\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen  Nhập Chế Độ : $BWhite ";
    $chon =trim(fgets(STDIN));
echo chay(10);
if($chon =='1'){
// mua like
echo $BGreen."Nhập ID Cần Mua Like : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));

$url ="https://traodoisub.com/mua/like/themid.php";
$mr2 = mua($id, $sl, $useragent, $url, "like");
if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 20 like \n"; die;
}
}
if($chon == '2'){
echo "\033[1;31m[\033[1;33mTHÔNG BÁO\033[1;31m]\033[1;32m Có các loại cảm xúc sau $BCyan LIKE, LOVE, HAHA, WOW, SAD, ANGRY \n";
echo chay(10);
// mua cảm xúc
echo $BGreen."Nhập ID Cần Mua Cảm Xúc : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));
echo $BGreen."Nhập Cảm Xúc ( ví dụ : HAHA ) : $BWhite";
$cx =trim(fgets(STDIN));

$url ="https://traodoisub.com/mua/reaction/themid.php";
$mr2 = muacx($id, $sl, $useragent, $url,  $cx, "reaction");
if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 20 cảm xúc \n"; die;
}
}
if($chon == '3'){
// mua follow
echo $BGreen."Nhập ID Cần Mua Follow : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));

$url ="https://traodoisub.com/mua/follow/themid.php";
$mr2 = mua($id, $sl, $useragent, $url, "follow");
if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 20 follow \n"; die;
}
}
if($chon =='4'){
// mua cmt
echo $BGreen."Nhập ID Cần Mua Cmt : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));
echo $BGreen."Nhập Nội Dung : $BWhite";
$nd =trim(fgets(STDIN));

$header = array( 
"Host:traodoisub.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://traodoisub.com",
"referer:https://traodoisub.com/mua/comment/",
);
$data = 'maghinho=&id='.$id.'&sl='.$sl.'&noidung='.$nd.'&dateTime=2021-6-30+0%3A15%3A28';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/mua/comment/themid.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 20 cmt \n"; die;
}
}
if($chon == '5'){
// mua page
echo $BGreen."Nhập ID Cần Mua Like Page : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));

$url ="https://traodoisub.com/mua/fanpage/themid.php";
$mr2 = mua($id, $sl, $useragent, $url, "fanpage");
if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 20 page \n"; die;
}
}
if($chon == '6'){
// mua share
echo $BGreen."Nhập ID Cần Mua Share : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));

$url ="https://traodoisub.com/mua/share/themid.php";
$mr2 = mua($id, $sl, $useragent, $url, "share");
if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 20 share \n"; die;
}
}
if($chon == '7'){
// mua share ảo
echo $BGreen."Nhập ID Cần Mua Share Ảo : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));

$url ="https://traodoisub.com/mua/shareao/themid.php";
$mr2 = mua($id, $sl, $useragent, $url, "shareao");
if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 100 share ảo \n"; die;
}
}
if($chon == '8'){
echo "\033[1;31m[\033[1;33mTHÔNG BÁO\033[1;31m]\033[1;32m Có các loại cảm xúc sau $BCyan LIKE, LOVE, HAHA, WOW, SAD, ANGRY \n";
echo chay(10);
// mua cảm xúc cmt
echo $BGreen."Nhập ID Cần Mua Cảm Xúc Cmt : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));
echo $BGreen."Nhập Cảm Xúc ( ví dụ : HAHA ) : $BWhite";
$cx =trim(fgets(STDIN));

$header = array( 
"Host:traodoisub.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://traodoisub.com",
"referer:https://traodoisub.com/mua/reactioncmt/",
);
$data = 'maghinho=&id='.$id.'&sl='.$sl.'&dateTime=2021-6-29+23%3A9%3A56&loaicx='.$cx.'';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/mua/reactioncmt/themid.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);

if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 20 reactioncmt \n"; die;
}
}
if($chon == '9'){
// mua gruops
echo $BGreen."Nhập ID Cần Mua Thành Viên Gruops : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));

$url ="https://traodoisub.com/mua/group/themid.php";
$mr2 = mua($id, $sl, $useragent, $url, "group");
if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 20 thành viên gruops \n"; die;
}
}
if($chon == '10'){
// mua view story
echo $BGreen."Nhập Link Url Cần Mua View Story : $BWhite";
$id =trim(fgets(STDIN));
echo $BGreen."Nhập Số Lượng : $BWhite";
$sl =trim(fgets(STDIN));

$url ="https://traodoisub.com/mua/viewstr/themid.php";
$mr2 = mua($id, $sl, $useragent, $url, "viewstr");
if($mr2 =='Mua thành công!'){
echo $BGreen." $mr2 \n";
}else{
echo $BRed."Mua tối thiểu 100 view story \n"; die;
}
}
function mua($id, $sl, $useragent, $url, $loai){
$header = array( 
"Host:traodoisub.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://traodoisub.com",
"referer:https://traodoisub.com/mua/".$loai."/",
);
$data = 'maghinho=&id='.$id.'&sl='.$sl.'&dateTime=2021-6-29+23%3A9%3A56';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, $url);
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
return $mr2;
}
function muacx($id, $sl, $useragent, $url, $loai, $cx){
$header = array( 
"Host:traodoisub.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://traodoisub.com",
"referer:https://traodoisub.com/mua/".$loai."/",
);
$data = 'maghinho=&id='.$id.'&sl='.$sl.'&dateTime=2021-6-29+23%3A9%3A56&loaicx='.$cx.'';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, $url);
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
return $mr2;
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}