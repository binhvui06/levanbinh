error_reporting(0);
system("clear");
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$nau= "\e[38;5;94m";
$lucnhat = "\033[1;96m";
$do = "\033[1;91m";
$xanh = "\033[1;32m";
$vang = "\033[1;93m";
$xanhd = "\033[1;94m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
echo chay(10);
echo $xanh."Nhập Cookie Facebook : $BWhite";
$cookie=trim(fgets(STDIN));
$access_token = accessToken($cookie);
$tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
if($tenfb == ""){
echo $do."Lỗi Khi Lấy Token Tài Hãy Kiểm Tra Lại !\n";
exit();
}
$idfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'id'};

$headersfb = array(
"Host: mbasic.facebook.com",
"upgrade-insecure-requests: 1",
"save-data: on",
"user-agent: Mozilla/5.0 (Linux; Android 7.1.1; CPH1729 Build/N6F26Q; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.198 YaBrowser/19.6.0.158 (lite) Mobile Safari/537.36",
"accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
"sec-fetch-site: same-origin",
"sec-fetch-mode: navigate",
"sec-fetch-user: ?1",
"sec-fetch-dest: document",
"accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
"cookie:$cookie",
);

if (file_exists('Backup_Friend_Facebook.txt')){
echo $lucnhat."File Backup Đã Tồn Tại ...\n"."Nếu Muốn Backup Tài Khoản Khác Vui Lòng Đổi Tên File$do \"Backup_Friend_Facebook.txt\"$lucnhat Trong Bộ Nhớ ...\n"."Nhấn Enter Để Backup Lại !";
$start=trim(fgets(STDIN));
sleep(3);
}
system("rm Backup_Friend_Facebook.txt");
system("rm List_data_backup.txt");

@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO BACKUP FB COOKIE \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "$do"."•$lucnhat"."AccCount$xanhd [$nau"."ID$trang".":$xanh$idfb$xanhd"."]$trang"."[$vang"."Name$trang".":$hong$tenfb$trang]\n";
echo chay(10);

$dem = 0;
while(true){
echo $hong."▪︎•▪︎•>$xanh Đang Truy Cập Dữ Liệu Cần Backup\n";
if($dem == 0){
$urlgetid = "https://mbasic.facebook.com/profile.php?v=friends";
}else{
$urlgetid = "$nextlist";
}
$ch = curl_init();
curl_setopt_array($ch, array(
CURLOPT_URL => "$urlgetid", CURLOPT_ENCODING => "", CURLOPT_RETURNTRANSFER => true, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 30, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => $headersfb));
$ch1 = curl_exec($ch);
curl_close($ch);
$cursor1 = explode('<a href="/profile.php?v=friends&amp;unit_cursor=',$ch1)[1];
$cursor = explode('&amp;',$cursor1)[0];
$lst1 = explode('&amp;lst=',$cursor1)[1];
$lst = explode('&amp;refid=17',$lst1)[0];
$nextlist = "https://mbasic.facebook.com/profile.php?v=friends&unit_cursor=$cursor&lst=$lst&refid=17";

$edit = fopen("List_data_backup.txt","a+");
fwrite($edit, "$ch1");
fclose($edit);
$dem ++;

$setbreak = explode('m_more_friends',$ch1)[1];
if($setbreak == ""){
echo $vang."Trạng Thái :$xanh √\n\n";
sleep(1);
	break;
	}
}

echo $hong."▪︎•▪︎•>$xanh Đang Tiến Hành Backup \n";
echo chay(10);
$fp = fopen("List_data_backup.txt", "r");
$list = fread($fp, filesize("List_data_backup.txt"));
fclose($fp);
sleep(1);

$dem = 0;
$stt = 0;
while(true){
$araylist = explode('href="/profile.php?id=',$list);
$ida = explode('&amp;',$araylist[$dem])[0];
$name1 = explode('refid=17">',$araylist[$dem])[1];
$namea = explode('</a>',$name1)[0];

$araylistt = explode('href="/',$list);
$idb = explode('?fref',$araylistt[$dem])[0];
$name2 = explode('refid=17">',$araylistt[$dem])[1];
$nameb = explode('</a>',$name2)[0];
$dem ++;

$setsave1 = strlen($ida);
$setsave2 = strlen($idb);
if($setsave1 <5 and $setsave2 < 5){
	break;
}

if($setsave1 < 20 and $ida !==""){
$stt ++;
$done = xong($ida,$namea,$stt);
$edit = fopen("Backup_Friend_Facebook.txt","a+");
fwrite($edit, "ID : $ida / Name : $namea\n");
fclose($edit);
}
if($setsave2 <50 and $idb !== ""){
$stt ++;
$done = xong($idb,$nameb,$stt);
$edit = fopen("Backup_Friend_Facebook.txt","a+");
fwrite($edit, "ID : $idb / Name : $nameb\n");
fclose($edit);
}
}

function xong($id,$name,$stt){
$nau= "\e[38;5;94m";
$lucnhat = "\033[1;96m";
$do = "\033[1;91m";
$xanh = "\033[1;92m";
$vang = "\033[1;93m";
$xanhd = "\033[1;94m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
echo $trang."[";usleep(70000);echo $BCyan."$stt";usleep(70000);echo $trang."]";usleep(70000);echo $xanh."🍭";usleep(70000);echo $trang."[";usleep(70000);echo$hong."$name";usleep(70000);echo $trang."]";usleep(70000);echo $nau."🍭";usleep(70000);echo $trang."[";usleep(70000);echo $lucnhat."$id";usleep(70000);echo $trang."]\n";
}


echo $trang."Đã Backup Xong Với : $stt InFo\n";
echo $lucnhat."Tool By : Lê Văn Bình \n";
echo "File Back Up \"Backup_Friend_Facebook.txt\"\n";
system("rm List_data_backup.txt");
echo ".";
exit();

function accessToken($cookie){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
$head[] = "Connection: keep-alive";
$head[] = "Keep-Alive: 300";
$head[] = "authority: m.facebook.com";
$head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
$head[] = "cache-control: max-age=0";
$head[] = "upgrade-insecure-requests: 1";
$head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
$head[] = "sec-fetch-site: none";
$head[] = "sec-fetch-mode: navigate";
$head[] = "sec-fetch-user: ?1";
$head[] = "sec-fetch-dest: document";
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36');
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
$access = curl_exec($ch);
curl_close($ch);
if (explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access)[1])[0]) {
$access_token = explode('\",\"useLocalFilePreview', explode('accessToken\":\"', $access)[1])[0];}
return $access_token;
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}