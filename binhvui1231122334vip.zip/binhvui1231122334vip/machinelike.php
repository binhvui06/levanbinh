error_reporting(0);
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$ress = "\033[0;32m";
$res = "\033[0;33m";
$red = "\033[0;31m";
$green = "\033[0;37m";
$yellow = "\033[0;33m";
$white = "\033[0;33m";
$xnhac = "\033[1;96m";
$den = "\033[1;90m";
$do = "\033[1;91m";
$luc = "\033[1;92m";
$vang = "\033[1;93m";
$xduong = "\033[1;94m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
$do="\033[1;91m";
$maufulldo= "\e[1;47;31m";
$res="\033[0m";
$red="\e[1;31m";
$pink="\e[1;35m";
$green="\e[1;32m";
$yellow="\e[1;33m";
$y2="\033[0;33m";
$white= "\033[0;37m";
$cyan= "\e[1;36m";
$blue="\e[1;34m";
$ngreen="\033[42m";
$ngblack="\033[40m";
$nen="\033[1;47;1;34m";
date_default_timezone_set("Asia/Ho_Chi_Minh");
$x = date("d");
$y = date("m");
$gt = 2.9;
$key=($x+$y)*($x+$y)+3940*$x*$gt+$x*$y;
//info
$info = [];
$info='TTT Original';
//day
$day = [];
$day= date('d-m-y');
//config
$today = date("d-m-Y");
$d = date("d-m");
$_check = file_exists("keymch3$d.txt");
$checkvip = file_exists("keyvip.txt");
@system('clear');
$checkck = file_exists("ckmch.txt");
if($checkck == '1'){
  echo  $white." ➻❥ ".$green."Bạn Đã Nhập Cookie$cyan Machine Liker$green Trước Đó. Bấm $yellow Enter $green Để Tiếp Tục, Bấm $red No $green Để Nhập Lại Cookie: ";
  $choose = trim(fgets(STDIN));
}
if($choose!='' or $checkck !='1'){
do {
unlink("ckmch.txt");
$khocookie = [];
echo chay(10);
echo $white." ➻❥ ".$yellow."Nhập Cookie Machine Liker Muốn Dừng Thì Bấm Xuống Hàng\n";
for($a = 1; $a < 999999;$a++){
echo $white." ➻❥ ".$green."Nhập Cookie Machine Liker Thứ $a: $white";
$nhapck = (string)trim(fgets(STDIN));
if($nhapck == ''){break;}
array_push($khocookie,$nhapck);
$mf = fopen("ckmch.txt", "a+");
$txt = $nhapck."\n";
fwrite($mf, $txt);
fclose($mf);
}
$demcki=count($khocookie);
echo $white." ➻❥ ".$green."Bạn Đã Nhập ".$vang.$demcki." ".$luc."Cookie Machine Liker\n";
usleep(500000);
} while (count($khocookie)==0);
}else{
  $k = file_get_contents("ckmch.txt");
  $khocookie = explode("\n",$k);
  $s = count($khocookie)-1;
  array_splice($khocookie,$s,1);
}
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO Machine-Liker ĐA LUỒNG \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
$dem = 0;
echo $white." ➻❥ ".$green."Nhập Link Bài Viết: $trang";
$link= trim(fgets(STDIN));
    echo "\r";
    echo "                                                      \r";
    $a =  $white." ➻❥ ".$green."Đang Get ID Từ Link FB";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
      echo $a[$x];
      usleep(5000);
    }
$result = getid($link);
echo "\r";
echo "                                                      \r";
if (strpos($result, 'error') !== false) {
  $js = json_decode($result,true);
  echo $white." ➻❥ ".$red.$js['error']."\n";
  exit;
}
$ui1 = explode('id":',$result)[1];
$uid = explode(',',$ui1)[0];
$ke=intval($uid);
if($ke==0){
  echo $white." ➻❥ ".$red."Lấy Key Lỗi\n";
  echo $white." ➻❥ ".$green."Nhập ID Bài Viết: $trang";
  $uid= trim(fgets(STDIN));
}else{
  echo $white." ➻❥ ".$green."ID Của Bạn Là:$yellow ".$uid."\n";
}
$id = $uid;
echo $white." ➻❥ ".$green."Đăng Kí AnyCaptcha Tại Đây\n";
echo $white." ➻❥ ".$trang."https://bom.to/dangki-anycaptcha\n";
echo $white." ➻❥ ".$green."Nhập API AnyCaptcha: $yellow";
$api= trim(fgets(STDIN));
$koh = getany($api);
if($koh['errorId']=='1'){
  echo $white." ➻❥ ".$red."Api Key AnyCaptcha Không Hợp Lệ\n";
  exit;
}
if($koh['errorId']==0){
  $cost = $koh['balance'];
  echo $white." ➻❥ ".$green."Số Dư:$yellow ".$cost." USD\n";
}
$type = '';
echo $white." ➻❥ ".$green."Bật Like (y/n) ";
$c = trim(fgets(STDIN));
if ($c=='y'){
  $type = $type."1";
}
echo $white." ➻❥ ".$green."Bật Care (y/n) ";
$c = trim(fgets(STDIN));
if ($c=='y'){
  if ($type==''){
    $type = $type."16";
  }else{
    $type = $type.",16";
  }
}
echo $white." ➻❥ ".$green."Bật Haha (y/n) ";
$c = trim(fgets(STDIN));
if ($c=='y'){
  if ($type==''){
    $type = $type."4";
  }else{
    $type = $type.",4";
  }
}
echo $white." ➻❥ ".$green."Bật Tim (y/n) ";
$c = trim(fgets(STDIN));
if ($c=='y'){
  if ($type==''){
    $type = $type."2";
  }else{
    $type = $type.",2";
  }
}
echo $white." ➻❥ ".$green."Bật Wow (y/n) ";
$c = trim(fgets(STDIN));
if ($c=='y'){
  if ($type==''){
    $type = $type."3";
  }else{
    $type = $type.",3";
  }
}
echo $white." ➻❥ ".$green."Bật Sad (y/n) ";
$c = trim(fgets(STDIN));
if ($c=='y'){
  if ($type==''){
    $type = $type."7";
  }else{
    $type = $type.",7";
  }
}
echo $white." ➻❥ ".$green."Bật Angry (y/n) ";
$c = trim(fgets(STDIN));
if ($c=='y'){
  if ($type==''){
    $type = $type."8";
  }else{
    $type = $type.",8";
  }
}
$pi = $type;
for($v=0;$v<= 26;$v++){
    echo "\033[1;37m▂";
    echo "\033[1;36m▂";
}
echo "\033[1;37m▂";
echo"\n\n";
$tai = 1; 
$stt = 0;
$tong = 0;
while($tai==1){
 for($xz=0;$xz<count($khocookie);$xz++){
   $coo = $khocookie[$xz];
    echo "\r";
    echo "                                                      \r";
    $a =  $white." ➻❥ ".$green."Đang Giải Captcha Vui Lòng Đợi";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
      echo $a[$x];
      usleep(5000);
    }
    cap:
    $naoh = giaicaptcha($id,$api);
    if($naoh['errorId']=='5'){
      echo "\r";
    echo "                                                      \r";
    $a =  $white." ➻❥ ".$red."Bạn Không Có Đủ Tiền Để Giải Captcha\n";
    $len = strlen($a);
    for ($x = 0; $x < $len; $x++) {
      echo $a[$x];
      usleep(5000);
    }
    exit;
    }
    if($naoh['errorId']=='0'){
      $task = $naoh['taskId'];
      $trangthai = 'tttoriginal';
      while($trangthai!='ready'){
        sleep(15);
        $kk = gettask($task,$api);
        if($kk['errorId']==61){
          GOTO cap; 
        }
        if($kk['errorId']==16){
          GOTO cap; 
        }
        $trangthai = $kk['status'];
      }
      $rec = $kk['solution']['gRecaptchaResponse'];
      echo "\r";
      echo "                                                      \r";
      $a =  $white." ➻❥ ".$green."Đang Tăng Like";
      for ($x = 0; $x < $len; $x++) {
        echo $a[$x];
        usleep(5000);
      }
    }
    $url = "https://www.machine-liker.com/api/send-reactions/"; 
    $data="post_id=$id&reactions=$pi&limit=150&g-recaptcha-response=$rec"; 
    $curl = curl_init(); 
    curl_setopt_array($curl, array( CURLOPT_PORT => "443", CURLOPT_URL => "$url", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "POST", CURLOPT_POSTFIELDS => $data, CURLOPT_HTTPHEADER => array( "Host:www.machine-liker.com", "user-agent:Mozilla/5.0 (Linux; Android 10; CPH1933) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Mobile Safari/537.36", "content-type:application/x-www-form-urlencoded; charset=UTF-8", "Cookie:$coo", ) )); 
    $result = curl_exec($curl);
    $err = curl_error($curl); 
    curl_close($curl); 
    $js = json_decode($result,true); 
    if($js["status"] == "ok"){
        echo "\r";
        echo "                                                      \r";
        $stt++;
        $mess = $js["info"]["total_reactions"];
        $a = "\033[1;36m[\033[1;36m".$stt."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i")."\033[1;91m 🍬\033[1;32m $id\033[1;91m 🍬\033[1;33m Tổng ".$mess." Likes\n";
        $len = strlen($a);
        for ($x = 0; $x < $len; $x++) {
          echo $a[$x];
          usleep(5000);
        }
    }else{
      echo "lỗi\r";
    }
}
$tim = 600-(count($khocookie)-1)*30;
delay($tim);
}
function delay($delay) {
    $time = $delay; 
    for ( $x = $time; $x--; $x ) {
       echo "                                                      \r";
       echo "\e[1;32m● LVB\e[1;37m〘\e[1;31m▉\e[1;32m■\e[1;33m■\e[1;34m■\e[1;35m■\e[1;37m〙".$x." \e[1;33mgiây";
       usleep(200000);
       echo "\r";
       echo "                                                      \r";
       echo "\e[1;36m● LVB\e[1;37m〘\e[1;33m■\e[1;34m▉\e[1;35m■\e[1;36m■\e[1;31m■\e[1;37m〙".$x."\e[1;34m giây";
       usleep(200000);
       echo "\r";
       echo "                                                      \r";
       echo "\e[1;34m● LVB\e[1;37m〘\e[1;34m■\e[1;35m■\e[1;36m▉\e[1;31m■\e[1;33m■\e[1;37m〙".$x."\e[1;31m giây";
       usleep(200000);
       echo "\r";
       echo "                                                      \r";
       echo "\e[1;33m● LVB\e[1;37m〘\e[1;35m■\e[1;36m■\e[1;31m■\e[1;33m▉\e[1;34m■\e[1;37m〙".$x."\e[1;32m giây";
       usleep(200000);
       echo "\r";
       echo "                                                      \r";
       echo "\e[1;31m● LVB\e[1;37m〘\e[1;33m■\e[1;32m■\e[1;31m■\e[1;35m■\e[1;36m▉\e[1;37m〙".$x."\e[1;36m giây";
       usleep(200000);
       echo "\r";
      
}}
function getid($link) {
  $ch = curl_init('https://id.traodoisub.com/api.php');
$data= ('link=').$link;
$head[] = "Host:id.traodoisub.com";
$head[] = "user-agent:Mozilla/5.0 (Linux; Android 10; CPH1933) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Mobile Safari/537.36";
$head[] = "content-type:application/x-www-form-urlencoded; charset=UTF-8";
curl_setopt($ch, CURLOPT_PORT, "443");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch,CURLOPT_TIMEOUT,0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
function getany($api){
$ch = curl_init('https://api.anycaptcha.com/getBalance');
$data = array("clientKey" => "$api");
$postdata = json_encode($data);
$head[] = "Accept: application/json";
$head[] = "Content-Type: application/json";
curl_setopt($ch, CURLOPT_PORT, "443");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch,CURLOPT_POSTFIELDS,$postdata);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch,CURLOPT_TIMEOUT,0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
$result = curl_exec($ch);
curl_close($ch); 
$js = json_decode($result,true); 
return $js;
}
function giaicaptcha($idpost,$api){
  $ch = curl_init('https://api.anycaptcha.com/createTask');
$data = array("clientKey" => "$api","task" => array ("type" => "RecaptchaV2TaskProxyless" ,"websiteURL" => "https://www.machine-liker.com/send-reactions","websiteKey" => "6Lep9tcbAAAAAM2kEgRg75zhxNJt2mHYabpIIOL2"));
$postdata = json_encode($data);
$head[] = "Accept: application/json";
$head[] = "Content-Type: application/json";
curl_setopt($ch, CURLOPT_PORT, "443");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch,CURLOPT_POSTFIELDS,$postdata);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch,CURLOPT_TIMEOUT,0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
$result = curl_exec($ch);
curl_close($ch);
$js = json_decode($result,true); 
return $js; 
}
function gettask($task,$api){
  $ch = curl_init('https://api.anycaptcha.com/getTaskResult');
$data = array("clientKey" => "$api","taskId" => "$task");
$postdata = json_encode($data);
$head[] = "Accept: application/json";
$head[] = "Content-Type: application/json";
curl_setopt($ch, CURLOPT_PORT, "443");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch,CURLOPT_POSTFIELDS,$postdata);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch,CURLOPT_TIMEOUT,0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
$result = curl_exec($ch);
curl_close($ch); 
$js = json_decode($result,true); 
return $js; 
}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}