error_reporting(1);
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
@system('clear');
$useragent ="Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/97.1.184 Mobile Chrome/91.1.4472.184 Mobile Safari/537.36";
@system('clear');
echo $BYellow."Vui lòng tạo file $BGreen tds.txt $BYellow và lưu nick cần đổi mật khẩu ở file đó định dạng tk:mk  \n";
echo $BGreen."Nhập Mật Khẩu Mới : $BWhite";
$mkm =trim(fgets(STDIN));
echo $BGreen."Nhập Lại Mật Khẩu Mới : $BWhite";
$nmkm =trim(fgets(STDIN));
@system('clear');
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO ĐỔI PASS TDS ĐA LUỒNG \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo $BYellow."Vui lòng tạo file $BGreen tds.txt $BYellow và lưu nick cần đổi mật khẩu ở file đó  \n";
// đổi mk
$in_file = file_get_contents("tds.txt");
$file = explode(PHP_EOL,$in_file);
foreach ($file as $data){
	$tk = explode (":", $data)[0];
	$mk = explode (":", $data)[1];
// login
$mr = curl_init();
$login = 'username='.$tk.'&password='.$mk.'';
curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/scr/login.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEJAR, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $login);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr);
curl_close($mr);

// đổi pass
$header = array( 
"Host:traodoisub.com",
"x-requested-with:XMLHttpRequest",
"user-agent:$useragent",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"origin:https://traodoisub.com",
"referer:https://traodoisub.com/view/setting/",
);
$data = 'oldpass='.$mk.'&newpass='.$mkm.'&renewpass='.$nmkm.'';
$mr = curl_init();
curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/scr/doipass.php');
curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
$mr2 = curl_exec($mr); 
curl_close($mr);
if($mr2 == '0'){
$so++;
echo $BCyan."[$so]$BRed ★$BGreen Đổi MK Thành Công $BRed ★$BGreen $tk:$mk $BRed ★$BGreen MK Mới $BRed ★$BGreen $mkm \n";
$f = fopen("tktds.txt","a+");
$luu = fwrite($f,"$tk:$mkm\n");
fclose($f);
}else{
$so++;
echo $BCyan."[$so]$BRed ★$BRed Đổi MK Thất Bại $BRed ★$BRed $tk:$mk \n";
}}
echo $BYellow."Nick Đã Được Lưu Tại File : $BGreen tktds.txt \n";
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}