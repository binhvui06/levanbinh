error_reporting(0);
session_start();
date_default_timezone_set("Asia/Ho_Chi_Minh");
$BBlack="\033[1;30m" ;      
$BRed="\033[1;31m"         ;
$BGreen="\033[1;32m"       ;
$BYellow="\033[1;33m"   ;
$BBlue="\033[1;34m"        ;
$BPurple="\033[1;35m"      ;
$BCyan="\033[1;36m"   ;
$BWhite="\033[1;37m"    ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$xnhac = "\033[1;36m";
$den = "\033[1;30m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
$_SESSION['useragent'] = 'Mozilla/5.0 (Linux; Android 10; CPH1819) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36';
$thanh_xau= $trang."≈ ".$do."[".$luc."●".$do."] ".$trang."➩ ";
$thanh_dep= $trang."≈ ".$do."[".$luc."✓".$do."] ".$trang."➩ ";
$khock=[];
$list_name = [];
$list_id = [];
$khogr = [];
@system("clear");
echo chay(10);
echo $thanh_dep.$luc."Bạn Muốn Nhập Bao Nhiêu Cookie: $vang";
	$slg = trim(fgets(STDIN));
while ($a < $slg){$a++;
echo $thanh_dep.$luc."Nhập Cookie Thứ $a: $vang";
$nhapck = (string)trim(fgets(STDIN));
if($nhapck == ''){break;}
$access_token = laytoken($nhapck);
if ( $access_token == "2") { echo $do." Cookie Die.                   \n"; $a--; continue; } 
	echo $thanh_dep.$luc."Nhập ID Group Thứ $a: $vang";
		$nhapgr = (string)trim(fgets(STDIN));
	if($nhapgr == ''){break;}
	$error = check($cookie, $idgr);
	if($error !== false){ 
		echo $error."\n"; $a--; continue;
	} else {
		array_push($khogr, $nhapgr);
		$thongtin = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token), true);
		$tenfb = $thongtin["name"];
		$idfb = $thongtin["id"];
		$kho_ID[$idfb] = [];
array_push($khock,$nhapck); 
array_push($list_name,$tenfb); 
array_push($list_id,$idfb); 
}
}
$soacc=count($khock);
@system("clear");
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO SPAM CMT FACEBOOK \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo $thanh_dep.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Comment Thường (không ảnh)\n";
echo $thanh_dep.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Comment Ảnh Thường (link)\n";
echo $thanh_dep.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Comment Ảnh Gif (link)\n";
echo $thanh_dep.$luc."Nhập Lựa Chọn: $vang";
$loai = (string)trim(fgets(STDIN));
echo chay(10);
if($loai == '1'){
$khoCMT=[];
echo $thanh_dep.$luc."Bạn Muốn Nhập Bao Nhiêu Nội Dung: $vang";
	$snd = (string)trim(fgets(STDIN));
while ($b < $snd){$b++;
echo $thanh_dep.$luc."Nhập Nội Dung Thứ $b: $vang";
$nhapcmt = (string)trim(fgets(STDIN));
if($nhapcmt == ''){break;}
array_push($khoCMT,$nhapcmt);
}
} else if($loai == '2'){
$khoCMT=[];
$khoanh =[];
echo $thanh_dep.$luc."Bạn Muốn Nhập Bao Nhiêu Nội Dung: $vang";
	$snd = (string)trim(fgets(STDIN));
while ($b < $snd){$b++;
echo $thanh_dep.$luc."Nhập Nội Dung Thứ $b: $vang";
$nhapcmt = (string)trim(fgets(STDIN));
if($nhapcmt == ''){break;}
echo $thanh_dep.$luc."Nhập Link Ảnh Thứ $xnhac$b: $vang";
	$linkanh = trim(fgets(STDIN));
array_push($khoCMT,$nhapcmt); 
array_push($khoanh,$linkanh); 
}
} else if($loai == '3'){
$khoCMT=[];
$khogif =[];
echo $thanh_dep.$luc."Bạn Muốn Nhập Bao Nhiêu Nội Dung: $vang";
	$snd = (string)trim(fgets(STDIN));
while ($b < $snd){$b++;
echo $thanh_dep.$luc."Nhập Nội Dung Thứ $b: $vang";
$nhapcmt = (string)trim(fgets(STDIN));
if($nhapcmt == ''){break;}
echo $thanh_dep.$luc."Nhập Link Ảnh GIF Thứ $xnhac$b: $vang";
	$linkgif = trim(fgets(STDIN));
array_push($khoCMT,$nhapcmt); 
array_push($khogif, $linkgif);
}
} else {
	exit($do." Lựa Chọn Không Xác Định \n");
}
$soacc=count($khoCMT);

echo $thanh_dep.$luc."Nhập Delay: $vang";
	$delay = trim(fgets(STDIN));
echo $thanh_dep.$luc."Sau Bao Nhiêu Nhiệm Vụ Thì Chuyển Acc: $vang";
   $yyy = trim(fgets(STDIN));
echo $thanh_dep.$luc."Nhập Số Lần Comment: $vang";
	$stop = trim(fgets(STDIN));
echo chay(10);
while (true){
	if(count($khock) == 0){
		echo chay(10);
		$khock=[];
		$list_name = [];
		$list_id = [];
		$a = 0;
		echo $thanh_dep.$luc."Bạn Muốn Nhập Bao Nhiêu Cookie: $vang";
			$slg = trim(fgets(STDIN));
		while ($a < $slg){$a++;
			echo $thanh_dep.$luc."Nhập Cookie Thứ $a: $vang";
				$nhapck = (string)trim(fgets(STDIN));
			if($nhapck == ''){break;}
			$access_token = laytoken($nhapck);
			if ( $access_token == "2") { 
				echo $do." Cookie Die.                   \n"; $a--; continue;
			} else {
				$thongtin = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token), true);
				$tenfb = $thongtin["name"];
				$idfb = $thongtin["id"];
				$kho_ID[$idfb] = [];
				array_push($khock,$nhapck); 
				array_push($list_name,$tenfb); 
				array_push($list_id,$idfb); 
			}
		}
	}
	for($xz=0;$xz<count($khock);$xz++){
		$idgr = $khogr[$xz];
		$cookie = $khock[$xz];
		$access_token = laytoken($cookie);
		if ( $access_token == "2") { echo $do." Cookie Die.                   \n"; array_splice($khock,$xz,1); continue; }
		$tt_page = json_decode(file_get_contents('https://graph.facebook.com/me/accounts?fields=name,access_token&access_token='.$access_token), true);
		$token_page = $tt_page["data"][0]["access_token"];
		$name_page = $tt_page["data"][0]["name"];
		$id_page = $tt_page["data"][0]["id"];
echo $vang."ID Page: ".$luc.$id_page.$vang." Tên Page: ".$luc.$name_page.$vang." ID Group: ".$luc.$idgr."\n";
$spam=0;
while (true){
if ($spam == 1) {break; }
   $list = getbv($cookie, $idgr);
   foreach ($list as $id){
if ((in_array ($id, $kho_ID[$idfb]) !== true) and  $id !== '' ){
	$zz = array_rand($khoCMT, 1);
	$msg = $khoCMT[$zz];
	if($loai == '1'){
		$get = comment($id, $token_page, $msg);
	} else if($loai == '2'){
		$linkanh = $khoanh[$zz];
		$get = comments($id, $token_page, $msg, $linkanh);
	} else if ($loai == '3'){
		$linkgif = $khogif[$zz];
		$get = commentgif($id, $token_page, $msg, $linkgif);
	} 
	if ($get["error"]["code"] == 190) {
                    echo "Cookie Die !!?!                  \n";
                    array_splice($khock,$xz,1);
                    $spam = 1; break; }
    if ($get["error"]["code"] == 368 and $g["error"]["error_subcode"] == 1404078) {
                    echo "\033[1;91m".$get["error"]["message"]."\n";
                    array_splice($khock,$xz,1);
                    $spam = 1; break;
	}
$dem++;
$kl = "\e[1;32m⌠\e[1;33mLVB\e[1;32m⌡\e[1;35m❯\e[1;36m❯\e[1;31m❯\033[1;36m[\033[1;36m".$dem."\033[1;36m]\033[1;91m 🍬 \033[1;34m".date("H:i:s")."\033[1;31m 🍬\033[1;32m COMMENT\033[1;31m 🍬 \033[1;".rand(31,37)."m".$id."\033[1;31m 🍬 \033[1;32m$msg \n";
	for($i = 0; $i < strlen($kl); $i++){echo $kl[$i];usleep(2500);}
if ($dem >= $stop ){ echo $luc." Đã Spam Comment Thành Công $stop Bài Viết  \n"; exit; }
	array_push($kho_ID[$idfb],$id);
    delay($delay);
 if($dem % $yyy == 0){$spam = 1; break; }
} else { echo $do." Đang Lướt Tìm Bài Viết.                      \r"; sleep (1); }
}
} 
} 
} 

function laytoken($cookie){
$ch=curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed');
$head[] = "Connection: keep-alive";
$head[] = "Keep-Alive: 300";
$head[] = "authority: m.facebook.com";
$head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
$head[] = "cache-control: max-age=0";
$head[] = "upgrade-insecure-requests: 1";
$head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
$head[] = "sec-fetch-site: none";
$head[] = "sec-fetch-mode: navigate";
$head[] = "sec-fetch-user: ?1";
$head[] = "sec-fetch-dest: document";
curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
$access = curl_exec($ch);
curl_close($ch);
if (explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0]){
$access_token = explode('\",\"useLocalFilePreview',explode('accessToken\":\"', $access)[1])[0];
return $access_token; }
 else { return "2"; }
}
function check($cookie, $idgr){
	$head= array("Connection: keep-alive","Keep-Alive: 300","authority: m.facebook.com","ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7","accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5","cache-control: max-age=0","upgrade-insecure-requests: 1","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","sec-fetch-site: none","sec-fetch-mode: navigate","sec-fetch-user: ?1","sec-fetch-dest: document");
$ch=curl_init();
	curl_setopt_array($ch , array(
		CURLOPT_URL => "https://mbasic.facebook.com/".$idgr,
		CURLOPT_USERAGENT => $_SESSION['useragent'],
		CURLOPT_COOKIE => $cookie,
		CURLOPT_HTTPHEADER => $head,
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_SSL_VERIFYPEER => FALSE,
		CURLOPT_TIMEOUT => 60,
		CURLOPT_CONNECTTIMEOUT => 60,
		CURLOPT_FOLLOWLOCATION => TRUE
	));
	$access = curl_exec($ch);
	curl_close($ch);
 
 if(strpos($access, 'Không tìm thấy trang bạn yêu cầu.') != false){
 	$error = "Không Tìm Thấy Group";
 } else if(strpos($access, '<input value="Tham gia') != false){
 	$error = "Bạn Chưa Tham Gia Group Này";
 } else {
 	$error = false;
 }
 return $error;
 }
 function getbv($cookie, $idgr){
 	$head= array("Connection: keep-alive","Keep-Alive: 300","authority: m.facebook.com","ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7","accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5","cache-control: max-age=0","upgrade-insecure-requests: 1","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","sec-fetch-site: none","sec-fetch-mode: navigate","sec-fetch-user: ?1","sec-fetch-dest: document");
$ch=curl_init();
	curl_setopt_array($ch , array(
		CURLOPT_URL => "https://mbasic.facebook.com/".$idgr,
		CURLOPT_USERAGENT => $_SESSION['useragent'],
		CURLOPT_COOKIE => $cookie,
		CURLOPT_HTTPHEADER => $head,
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_SSL_VERIFYPEER => FALSE,
		CURLOPT_TIMEOUT => 60,
		CURLOPT_CONNECTTIMEOUT => 60,
		CURLOPT_FOLLOWLOCATION => TRUE
	));
	$access = curl_exec($ch);
	curl_close($ch);
	$stool = [];
	$list = explode('https://mbasic.facebook.com/groups/', $access);
	for($i = 2; $i < count($list)/3; $i++){
	$mr = explode('?refid=', $list[$i*3])[0];
		if(strpos ($mr, 'permalink') != false){
			$id = explode ('/',explode ('permalink/', $mr)[1])[0];;
			array_push($stool, $id);
		}
	}
	return $stool;
}
function comment($id, $access_token, $msg){
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array(
		'message' => $msg,
		'access_token' => $access_token,
	);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access, true);
}
function comments($id, $access_token, $msg, $linkanh){
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array(
		'message' => $msg,
		'access_token' => $access_token,
		'attachment_url' => $linkanh
	);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access, true);
}
function commentgif($id, $access_token, $msg, $linkgif){
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$id.'/comments');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, $_SESSION['useragent']);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array(
		'message' => $msg,
		'access_token' => $access_token,
		'attachment_share_url' => $linkgif
	);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function delay ($delay){
	for($tt = $delay ;$tt>= 1;$tt--){
        echo "\r\033[1;33m   LVB \033[1;31m ~>       \033[1;32m LO      \033[1;31m | $tt | "; usleep(150000);
        echo "\r\033[1;31m   LVB \033[0;33m   ~>     \033[0;37m LOA     \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;32m   LVB \033[0;33m     ~>   \033[0;37m LOAD    \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;34m   LVB \033[0;33m       ~> \033[0;37m LOADI   \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADIN  \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADING \033[0;31m | $tt | "; usleep(150000);
        echo "\r\033[1;35m   LVB \033[0;33m        ~>\033[0;37m LOADING.\033[0;31m | $tt | ";usleep(150000);} 
echo "\r\e[1;95m    ⚡LÊ VĂN BÌNH⚡                       \r"; }
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}