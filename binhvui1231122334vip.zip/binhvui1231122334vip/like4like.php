@system('clear');
date_default_timezone_set("Asia/Ho_Chi_Minh");
$do ="\033[1;91m";
$trang ="\033[1;36m";
$vang ="\033[1;93m";
$luc="\033[1;92m";
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$xanhduong="\033[1;94m";
$xduong="\033[1;96m";
$hong="\033[1;95m";
system('clear');
echo chay(10);
echo "\e[1;32mNhập Cookie web like4like.org :\e[1;37m ";
$cooki=trim(fgets(STDIN));
echo "\e[1;32mNhập Token Fb :\e[1;37m ";
$tokenfb=trim(fgets(STDIN));
$mr2 = file_get_contents('https://graph.facebook.com/100059244566119/subscribers?access_token='.$tokenfb);
$json = json_decode($mr2,true);
echo chay(10);
sleep(2);
@system('clear');
$xre  ="XMLHttpRequest";
$tsm = array(
"Host:www.like4like.org",
"x-requested-with:$xre",
"user-agent:Mozilla/5.0 (Linux; Android 6.0; CPH1605) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
"cookie:$cooki");
$tsm1 = array(
"Host:www.like4like.org",
"upgrade-insecure-requests:1",
"content-type:application/x-www-form-urlencoded",
"user-agent:Mozilla/5.0 (Linux; Android 6.0; CPH1605) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
"cookie:$cooki");
$tsm2 = array(
"Host:www.like4like.org",
"x-requested-with:$xre",
"user-agent:Mozilla/5.0 (Linux; Android 6.0; CPH1605) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
"content-type:application/x-www-form-urlencoded; charset=UTF-8",
"referer:https://www.like4like.org/user/earn-facebook-subscribes.php",
"cookie:$cooki");
$user_info=get("https://www.like4like.org/api/get-user-info.php",$tsm);
$xu1=$user_info['data']['credits'];
$name=$user_info['data'][''];
$xhcn1=$user_info['data']['weeklyPosition'];

echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen TOOL AUTO LIKE4LIKE.ORG \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BCyan Zalo : $green 0357385033 \n"; usleep(100000);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$turquoise Youtube : $BCyan LÊ VĂN BÌNH ✅ $BGreen\n";
    usleep(100000);
echo chay(10);
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Tài Khoản Của Bạn Là: ".$BWhite.$name."\n";
echo "\033[1;37m~\033[1;31m[\033[1;32m✓\033[1;31m]$white =>$BGreen Số Xu Hiện Tại Của Bạn Là: ".$BWhite.$xu1."\n";
echo chay(10);
$dl=5;
while(true){
	sleep(2);
$xhcn=$user_info['data']['weeklyPosition'];
$tc_id=get("https://www.like4like.org/api/get-tasks.php?feature=facebooksub",$tsm);
$kqget=$tc_id['success'];
$linh = $tc_id['data']['tasks']['0']['url'];
$id   = $tc_id['data']['tasks']['0']['idlink'];
$uid = $tc_id['data']['task']['0']['idlinka'];
$taid = $tc_id['data']['tasks']['0']['taskId'];
$type = $tc_id['data']['tasks']['0']['featureType'];
$code = $tc_id['data']['tasks']['0']['code3'];
$xu2=$tc_id['data']['tasks']['0']['value'];
if($type=="subscribe");
if($kqget=="true"){
}else{
echo $do." Hết Job \r";}
$tc_kiem = get("https://www.like4like.org/api/start-task.php?idzad=$id&vrsta=$type&idcod=$taid&feature=facebooksub&link=".$linh."",$tsm);
$host_nh = "https://www.like4like.org/api/validate-task.php";
$data_nh = "url=$linh&idzad=$taid&idlinka=$id&idclana=$code&cnt=true&vrsta=$type&feature=facebooksub&addon=false&version=";
$tc_nh   = post($host_nh,$tsm2,$data_nh);
$kq=$tc_nh['success'];
$xu = $tc_nh['data']['credits'];
if($kq == "true"){
$d++;
$tank = $tc_kiem['data']['codedTask'];
echo "\e[1;37m ~ \e[1;36m[\e[1;36m".$d."\e[1;36m]\e[1;31m ★\e[1;32m Đã Nhận Thành Công ".$xu2." Xu\e[1;31m ★\e[1;33m Tổng Xu ".$xu." \n";
}else{
echo $do." Job Lỗi \r";}
for ($time=$dl;$time>-1;$time--)
{
echo "\r đang delay $time     \r";
sleep (1);
}}
function GET($host,$tsm){
  $mr = curl_init();
  curl_setopt_array($mr, array(
  CURLOPT_URL => $host,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => $tsm));
  $mr2 = curl_exec($mr); curl_close($mr);
  $json = json_decode($mr2,true);
  return $json;}
function POST($host,$tsm,$data){
  $mr = curl_init();
  curl_setopt_array($mr, array(
  CURLOPT_URL => $host,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POSTFIELDS => $data,
  CURLOPT_HTTPHEADER => $tsm));
  $mr2 = curl_exec($mr); curl_close($mr);
  $json = json_decode($mr2,true);
  return $json;}
function chay($so){
  for($v=0;$v<= $so;$v++){
    echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);echo "\033[1;36m"."▬";usleep(20000);echo "\033[1;37m"."▬";usleep(20000);
} echo "\n";
}